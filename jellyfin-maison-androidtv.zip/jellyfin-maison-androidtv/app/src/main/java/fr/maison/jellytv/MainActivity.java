package fr.maison.jellytv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Jellyfin Maison pour Android TV / Google TV (Philips, Google TV Streamer…).
 * Affiche en plein écran la MÊME appli que sur la LG (dossier web/app), avec la télécommande :
 *  • flèches / OK : transmises telles quelles à l'appli ;
 *  • Retour : envoyé à l'appli (touche 461, comme sur webOS) ; c'est elle qui décide de quitter ;
 *  • touches lecture / pause / avance / retour rapide : transmises.
 */
public class MainActivity extends Activity {

    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // l'appli a son propre écran de veille
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        hideSystemUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);          // aperçus vidéo, intro, sons
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);           // l'appli locale parle à ton serveur Jellyfin
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " JellyfinMaisonTV/" + BuildConfig.VERSION_NAME);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Native(), "TVMNative");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        web.loadUrl("file:///android_asset/app/index.html");
    }

    /** Fonctions appelées par l'appli web */
    private class Native {
        @JavascriptInterface
        public void exit() { runOnUiThread(() -> finish()); }

        @JavascriptInterface
        public String version() { return BuildConfig.VERSION_NAME; }
    }

    private void sendKey(int code) {
        web.evaluateJavascript(
            "(function(){var o={keyCode:" + code + ",which:" + code + ",bubbles:true,cancelable:true};" +
            "var e=new KeyboardEvent('keydown',o);try{Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});" +
            "Object.defineProperty(e,'which',{get:function(){return " + code + "}});}catch(x){}" +
            "document.dispatchEvent(e);})()", null);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        int js = 0;
        switch (k) {
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE: js = 461; break;                    // comme la touche Retour de la LG
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK: js = 179; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: js = 415; break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: js = 19; break;
            case KeyEvent.KEYCODE_MEDIA_STOP: js = 413; break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: js = 417; break;
            case KeyEvent.KEYCODE_MEDIA_REWIND: js = 412; break;
            case KeyEvent.KEYCODE_PROG_RED: js = 403; break;
            case KeyEvent.KEYCODE_PROG_GREEN: js = 404; break;
            case KeyEvent.KEYCODE_PROG_YELLOW: js = 405; break;
            case KeyEvent.KEYCODE_PROG_BLUE: js = 406; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER: js = 13; break;
            default: break;
        }
        if (js != 0) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) sendKey(js);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        hideSystemUi();
        // comme sur la LG : on rafraîchit « Continuer à regarder » au retour dans l'appli
        web.evaluateJavascript("try{var v=TVM.app.top();if(v&&v.refreshContinue)v.refreshContinue();}catch(e){}", null);
    }

    @Override
    protected void onPause() {
        // la vidéo s'arrête proprement quand on quitte l'appli (touche Accueil…)
        web.evaluateJavascript("try{var v=TVM.app.top();if(v&&v.video)v.video.pause();if(TVM.preview)TVM.preview.stop();}catch(e){}", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
