package fr.maison.jellytv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Jellyfin Maison pour Android TV / Google TV (Philips, Google TV Streamer…).
 * Affiche en plein écran la MÊME appli que sur la LG (dossier web/app), avec la télécommande :
 *  • flèches / OK : transmises telles quelles à l'appli ;
 *  • Retour : envoyé à l'appli (touche 461, comme sur webOS) ; c'est elle qui décide de quitter ;
 *  • touches lecture / pause / avance / retour rapide : transmises.
 */
public class MainActivity extends Activity {

    private WebView web;
    private long pausedAt = 0;
    private static final String ACTION_INSTALL = "fr.maison.jellytv.INSTALL";
    private BroadcastReceiver installReceiver;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // l'appli a son propre écran de veille
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        hideSystemUi();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);          // aperçus vidéo, intro, sons
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);           // l'appli locale parle à ton serveur Jellyfin
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setUserAgentString(s.getUserAgentString() + " JellyfinMaisonTV/" + BuildConfig.VERSION_NAME);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public Bitmap getDefaultVideoPoster() {
                // Supprime l'icône lecture grise affichée par Android avant chaque vidéo
                return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            }
        });
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setHapticFeedbackEnabled(false);
        web.setOnLongClickListener(v -> true);                 // pas de sélection de texte par appui long
        web.addJavascriptInterface(new Native(), "TVMNative");
        registerInstallReceiver();
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        web.loadUrl("file:///android_asset/app/index.html");
    }

    /** Fonctions appelées par l'appli web */
    private class Native {
        @JavascriptInterface
        public void exit() { runOnUiThread(() -> finish()); }

        @JavascriptInterface
        public String version() { return BuildConfig.VERSION_NAME; }

        /** Réglages → « Mettre à jour l'appli » : télécharge l'APK depuis GitHub et l'installe par-dessus */
        @JavascriptInterface
        public void update(final String url) {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                        say("Active « Jellyfin Maison », puis fais Retour et relance la mise à jour");
                        return;
                    } catch (Exception e) { /* menu absent sur cette télé : Android demandera lui-même */ }
                }
                new Thread(() -> doUpdate(url)).start();
            });
        }
    }

    private void say(String msg) {
        final String code = "try{TVM.updateState(" + JSONObject.quote(msg) + ")}catch(e){}";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void doUpdate(String url) {
        HttpURLConnection c = null;
        PackageInstaller.Session session = null;
        try {
            PackageInstaller pi = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int id = pi.createSession(params);
            session = pi.openSession(id);
            URL u = new URL(url);
            int redirects = 0;
            while (true) {
                c = (HttpURLConnection) u.openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400 && redirects < 6) {
                    redirects++;
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    c = null;
                    u = new URL(u, loc);
                    continue;
                }
                if (code != 200) throw new Exception("erreur " + code);
                break;
            }
            long total = c.getContentLengthLong();
            InputStream in = c.getInputStream();
            OutputStream out = session.openWrite("app.apk", 0, total > 0 ? total : -1);
            byte[] buf = new byte[65536];
            long done = 0;
            int n, last = -1;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    int pct = (int) (done * 100 / total);
                    if (pct / 20 != last) { last = pct / 20; say("Téléchargement… " + pct + " %"); }
                }
            }
            session.fsync(out);
            out.close();
            in.close();
            Intent i = new Intent(ACTION_INSTALL).setPackage(getPackageName());
            int fl = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) fl |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pend = PendingIntent.getBroadcast(this, id, i, fl);
            say("Installation…");
            session.commit(pend.getIntentSender());
            session.close();
            session = null;
        } catch (Exception e) {
            if (session != null) { try { session.abandon(); } catch (Exception x) { } }
            say("Mise à jour impossible : " + e.getMessage());
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private void registerInstallReceiver() {
        installReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                int st = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999);
                if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                    Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
                    if (confirm != null) {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try { startActivity(confirm); } catch (Exception e) { say("Installation impossible"); }
                    }
                } else if (st == PackageInstaller.STATUS_SUCCESS) {
                    say("Mise à jour installée");
                } else {
                    say("Installation annulée");
                }
            }
        };
        IntentFilter f = new IntentFilter(ACTION_INSTALL);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(installReceiver, f);
    }

    private void sendKey(int code) {
        web.evaluateJavascript(
            "(function(){var o={keyCode:" + code + ",which:" + code + ",bubbles:true,cancelable:true};" +
            "var e=new KeyboardEvent('keydown',o);try{Object.defineProperty(e,'keyCode',{get:function(){return " + code + "}});" +
            "Object.defineProperty(e,'which',{get:function(){return " + code + "}});}catch(x){}" +
            "document.dispatchEvent(e);})()", null);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        int js = 0;
        switch (k) {
            case KeyEvent.KEYCODE_BACK:
            case KeyEvent.KEYCODE_ESCAPE: js = 461; break;                    // comme la touche Retour de la LG
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_HEADSETHOOK: js = 179; break;
            case KeyEvent.KEYCODE_MEDIA_PLAY: js = 415; break;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: js = 19; break;
            case KeyEvent.KEYCODE_MEDIA_STOP: js = 413; break;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: js = 417; break;
            case KeyEvent.KEYCODE_MEDIA_REWIND: js = 412; break;
            case KeyEvent.KEYCODE_PROG_RED: js = 403; break;
            case KeyEvent.KEYCODE_PROG_GREEN: js = 404; break;
            case KeyEvent.KEYCODE_PROG_YELLOW: js = 405; break;
            case KeyEvent.KEYCODE_PROG_BLUE: js = 406; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER: js = 13; break;
            default: break;
        }
        if (js != 0) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) sendKey(js);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        hideSystemUi();
        // retour dans l'appli (veille, source HDMI…) : écran de veille fermé, « Continuer » rafraîchi,
        // et après une longue absence l'appli repart à neuf
        long away = pausedAt > 0 ? System.currentTimeMillis() - pausedAt : 0;
        web.evaluateJavascript("try{TVM.onResume(" + away + ")}catch(e){}", null);
    }

    @Override
    protected void onPause() {
        pausedAt = System.currentTimeMillis();
        // la vidéo s'arrête proprement quand on quitte l'appli (touche Accueil…)
        web.evaluateJavascript("try{var v=TVM.app.top();if(v&&v.video)v.video.pause();if(TVM.preview)TVM.preview.stop();}catch(e){}", null);
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        try { if (installReceiver != null) unregisterReceiver(installReceiver); } catch (Exception e) { }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
