/*
 * Jellyfin Maison (webOS) — « Tout le catalogue » d'une catégorie
 * Grille de toutes les affiches, triable (A → Z, ajouts récents, année, note) et filtrable
 * (tout / films / séries / pas vus). Chargement par pages et seules les lignes visibles sont
 * dans la page : reste fluide même avec des milliers de titres.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, C = TVM.config, el = TVM.el, esc = TVM.esc;
  var COLS = 7, PAGE = 84, ROWH = 25.2, CW = 14.8;
  var SORTS = [
    { l: 'A → Z', q: { SortBy: 'SortName', SortOrder: 'Ascending' } },
    { l: 'Ajouts récents', q: { SortBy: 'DateCreated,SortName', SortOrder: 'Descending' } },
    { l: 'Année', q: { SortBy: 'ProductionYear,PremiereDate,SortName', SortOrder: 'Descending' } },
    { l: 'Mieux notés', q: { SortBy: 'CommunityRating,SortName', SortOrder: 'Descending' } },
    { l: 'Au hasard', q: { SortBy: 'Random' } }
  ];

  function typesFor(scope, f) {
    var base = 'Movie,Series';
    if (scope.type === 'lib') { var ct = scope.lib.CollectionType; base = ct === 'tvshows' ? 'Series' : ct === 'movies' ? 'Movie' : ct === 'boxsets' ? 'BoxSet' : 'Movie,Series'; }
    if (f === 'Movie' || f === 'Series') return base.indexOf(f) >= 0 ? f : base;
    return base;
  }

  TVM.CatalogView = function (scope) {
    var v = this;
    v.scope = scope;
    v.sort = 0; v.filter = 'all';
    v.alive = true;
    var title = scope.type === 'lib' ? scope.lib.Name : scope.type === 'kids' ? 'Jeunesse' : 'Accueil';
    v.el = el('div', 'view catalog');
    v.el.innerHTML = '<div class="cth"><h1>' + esc(title) + ' <span>· tout le catalogue</span></h1><div class="ctn"></div></div>' +
      '<div class="ctbar"></div><div class="ctw"><div class="ctg"></div></div>';
    v.grid = v.el.querySelector('.ctg');
    v.zone = 'bar';
    v.i = 0;
    v.buildBar();
    v.reload();
  };
  var P = TVM.CatalogView.prototype;
  P.buildBar = function () {
    var v = this, bar = v.el.querySelector('.ctbar'), items = [];
    bar.innerHTML = '';
    var filters = [['all', 'Tout']];
    var t = typesFor(v.scope, 'all');
    if (t.indexOf(',') > 0) filters.push(['Movie', 'Films'], ['Series', 'Séries']);
    filters.push(['unplayed', 'Pas encore vus']);
    filters.forEach(function (f) {
      var d = el('div', 'ctc' + (v.filter === f[0] ? ' on' : ''), esc(f[1]));
      d.__a = function () { v.filter = f[0]; v.buildBar(); v.reload(); };
      bar.appendChild(d); items.push(d);
    });
    bar.appendChild(el('span', 'ctsep', ''));
    SORTS.forEach(function (so, k) {
      var d = el('div', 'ctc' + (v.sort === k ? ' on' : ''), esc(so.l));
      d.__a = function () { v.sort = k; v.buildBar(); v.reload(); };
      bar.appendChild(d); items.push(d);
    });
    items.forEach(function (d) { d.addEventListener('click', function () { d.__a(); }); });
    var keep = v.bar ? v.bar.i : 0;
    v.bar = new TVM.List(items);
    v.bar.i = Math.min(keep, items.length - 1);
    if (v.zone === 'bar') v.bar.focus();
  };
  P.query = function (start) {
    var v = this, q = { Recursive: true, StartIndex: start, Limit: PAGE, IncludeItemTypes: typesFor(v.scope, v.filter), EnableTotalRecordCount: true,
      Fields: 'PrimaryImageAspectRatio,ProductionYear', EnableImageTypes: 'Primary', ImageTypeLimit: 1, userId: A.userId };
    var so = SORTS[v.sort].q; for (var k in so) q[k] = so[k];
    if (v.filter === 'unplayed') q.Filters = 'IsUnplayed';
    var libs = v.scope.type === 'lib' ? [v.scope.lib] : v.scope.type === 'kids' ? v.scope.libs : null;
    if (libs && libs.length === 1) q.ParentId = libs[0].Id;
    /* plusieurs médiathèques (Jeunesse) : le profil ne voit déjà que ce qui lui est permis */
    return A.both('GET', '/Items', '/Users/' + A.userId + '/Items', q);
  };
  P.reload = function () {
    var v = this, tok = (v.tok = (v.tok || 0) + 1);
    v.items = []; v.total = 0; v.loading = false; v.i = 0; v.rendered = {};
    v.grid.innerHTML = '';
    v.el.querySelector('.ctn').textContent = 'Chargement…';
    v.more(tok);
  };
  P.more = function (tok) {
    var v = this;
    tok = tok || v.tok;
    if (v.loading || (v.total && v.items.length >= v.total)) return;
    v.loading = true;
    v.query(v.items.length).then(function (r) {
      if (!v.alive || tok !== v.tok) return;
      v.loading = false;
      var l = (r && r.Items) || [];
      v.total = (r && r.TotalRecordCount) || v.items.length + l.length;
      v.items = v.items.concat(l);
      if (!l.length) v.total = v.items.length;
      v.el.querySelector('.ctn').textContent = v.total + ' titre' + (v.total > 1 ? 's' : '');
      v.grid.style.height = Math.ceil(v.total / COLS) * TVM.rem(ROWH) + 'px';
      v.paint();
    }).catch(function () { v.loading = false; v.el.querySelector('.ctn').textContent = 'Indisponible'; });
  };
  P.card = function (n) {
    var v = this, it = v.items[n];
    if (!it) return null;
    var src = A.poster(it, C.posterWidth || 300);
    var d = el('div', 'cti', (src ? '<img src="' + src + '">' : '') + '<div class="ctt">' + esc(it.Name) + '</div>');
    TVM.move(d, (n % COLS) * TVM.rem(CW), Math.floor(n / COLS) * TVM.rem(ROWH));
    d.addEventListener('click', function () { v.i = n; v.zone = 'grid'; v.open(); });
    v.grid.appendChild(d);
    return d;
  };
  P.paint = function () {
    var v = this, row = Math.floor(v.i / COLS), r0 = Math.max(0, row - 2), r1 = row + 4;
    for (var k in v.rendered) if (v.rendered.hasOwnProperty(k)) {
      var rr = Math.floor(k / COLS);
      if (rr < r0 || rr > r1) { var e = v.rendered[k]; if (e.parentNode) e.parentNode.removeChild(e); delete v.rendered[k]; }
    }
    for (var n = r0 * COLS; n < Math.min(v.items.length, (r1 + 1) * COLS); n++) if (!v.rendered[n]) { var c = v.card(n); if (c) v.rendered[n] = c; }
    for (var j in v.rendered) if (v.rendered.hasOwnProperty(j)) v.rendered[j].classList.toggle('f', v.zone === 'grid' && +j === v.i);
    TVM.move(v.grid, 0, -Math.max(0, row - 1) * TVM.rem(ROWH));
    if (v.zone === 'bar') v.bar.focus(); else v.bar.blur();
    if ((row + 5) * COLS > v.items.length) v.more();
  };
  P.open = function () { var it = this.items[this.i]; if (it) TVM.app.push(new TVM.DetailsView(it)); };
  P.onShow = function () { this.paint(); };
  P.destroy = function () { this.alive = false; };
  P.onKey = function (k) {
    var v = this, n = v.items.length;
    /* Retour : on quitte le catalogue et on revient sur le menu du haut de la page */
    if (k === 'back') {
      TVM.app.pop();
      var t = TVM.app.top();
      if (t && t.go && t.menu) t.go('menu');
      return true;
    }
    if (v.zone === 'bar') {
      if (k === 'left' || k === 'right') { v.bar.step(k === 'left' ? -1 : 1); return true; }
      if (k === 'ok') { v.bar.current().__a(); return true; }
      if (k === 'down' && n) { v.zone = 'grid'; v.i = 0; v.paint(); return true; }
      return true;
    }
    if (k === 'left' && v.i % COLS) { v.i--; v.paint(); return true; }
    if (k === 'right' && v.i % COLS < COLS - 1 && v.i + 1 < n) { v.i++; v.paint(); return true; }
    if (k === 'down' && v.i + COLS < n) { v.i += COLS; v.paint(); return true; }
    if (k === 'down' && Math.floor(v.i / COLS) < Math.floor((n - 1) / COLS)) { v.i = n - 1; v.paint(); return true; }
    if (k === 'up') { if (v.i >= COLS) v.i -= COLS; else v.zone = 'bar'; v.paint(); return true; }
    if (k === 'ok') { v.open(); return true; }
    if (k === 'play' || k === 'playpause') { var it = v.items[v.i]; if (it) TVM.playItem(it); return true; }
    return true;
  };
})();
