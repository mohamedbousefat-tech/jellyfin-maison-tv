/*
 * Jellyfin Maison (webOS) — goûts de chaque profil, façon Netflix
 *  • questionnaire « Choisissez 3 titres ou plus que vous aimez » (à la première ouverture
 *    d'un profil, puis depuis le menu du profil → « Mes goûts ») ;
 *  • sur chaque fiche : Évaluer → J'aime / J'adore / Je n'aime pas (envoyé aussi au serveur) ;
 *  • rangée « Selon vos goûts » : titres non vus classés selon les genres aimés, ce qu'on a
 *    regardé jusqu'au bout et les titres notés ; les « Je n'aime pas » ne sont plus proposés.
 * Tout est propre à chaque profil.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, C = TVM.config, S = TVM.store, el = TVM.el, esc = TVM.esc;

  function k() { return 'taste.' + A.server + '|' + A.userId; }
  function get() { var t = S.get(k(), null) || {}; t.items = t.items || {}; return t; }
  function save(t) { S.set(k(), t); }
  TVM.taste = {
    get: get,
    rating: function (id) { var r = get().items[id]; return r ? r.r : 0; },
    /* r : 2 = J'adore, 1 = J'aime, -1 = Je n'aime pas, 0 = rien */
    rate: function (it, r) {
      var t = get();
      if (r) t.items[it.Id] = { r: r, g: (it.Genres || []).slice(0, 5), n: it.Name };
      else delete t.items[it.Id];
      save(t);
      var path = '/UserItems/' + it.Id + '/Rating', old = '/Users/' + A.userId + '/Items/' + it.Id + '/Rating';
      var p = r ? A.both('POST', path, old, { userId: A.userId, likes: r > 0 }) : A.both('DELETE', path, old, { userId: A.userId });
      if (p && p.catch) p.catch(function () {});
    },
    done: function () { return !!get().done; },
    /* poids de chaque genre pour ce profil */
    weights: function (history) {
      var w = {}, t = get();
      function add(gs, x) { (gs || []).forEach(function (g) { w[g] = (w[g] || 0) + x; }); }
      for (var id in t.items) if (t.items.hasOwnProperty(id)) { var r = t.items[id]; add(r.g, r.r === 2 ? 3 : r.r === 1 ? 2 : -3); }
      (history || []).forEach(function (it) { add(it.Genres, 1); });
      return w;
    }
  };

  /* rangée « Selon vos goûts » */
  TVM.tasteRow = function (P, T) {
    return {
      title: 'Selon vos goûts', type: 'poster', mix: true, load: function () {
        var row = this;
        var hq = { IncludeItemTypes: 'Movie,Series', Filters: 'IsPlayed', SortBy: 'DatePlayed', SortOrder: 'Descending', Limit: 40, Fields: 'Genres' };
        if (P) hq.ParentId = P;
        return A.items(hq).catch(function () { return []; }).then(function (hist) {
          var w = TVM.taste.weights(hist), t = get();
          if (!Object.keys(w).length) return [];
          var q = { IncludeItemTypes: T === 'BoxSet' ? 'Movie,Series' : T, Filters: 'IsUnplayed', SortBy: 'Random', Limit: 300 };
          if (P) q.ParentId = P;
          return A.items(q).then(function (l) {
            var name = A.user && A.user.Name ? String(A.user.Name).split(/[ .@]/)[0] : '';
            if (name) row.title = 'Recommandé pour ' + name + ', selon vos goûts';
            return l.filter(function (it) { var r = t.items[it.Id]; return !(r && r.r < 0); })
              .map(function (it) {
                var s = 0;
                (it.Genres || []).forEach(function (g) { s += w[g] || 0; });
                s += ((it.CommunityRating || 6) - 6) * 0.6 + Math.random() * 0.8;
                return { it: it, s: s };
              })
              .filter(function (x) { return x.s > 0.5; })
              .sort(function (a, b) { return b.s - a.s; })
              .slice(0, C.rowSize * 2).map(function (x) { return x.it; });
          });
        });
      }
    };
  };

  /* ---------------- questionnaire ---------------- */
  var COLS = 6;
  TVM.TasteQuizView = function (first) {
    var v = this;
    v.first = first;
    v.el = el('div', 'view quiz');
    v.el.innerHTML = '<div class="qhead"><h1>Choisissez 3 titres ou plus que vous aimez</h1>' +
      '<p>Cela nous aidera à vous proposer des séries et des films qui vous plairont.</p></div>' +
      '<div class="qw"><div class="qgrid"></div></div>' +
      '<div class="qfoot"><div class="qbtn later">' + (first ? 'Plus tard' : 'Annuler') + '</div><div class="qbtn go">Continuer <span class="qn">(0)</span></div></div>';
    v.sel = {};
    v.items = [];
    v.zone = 'grid';
    v.i = 0;
    var t = get();
    for (var id in t.items) if (t.items.hasOwnProperty(id) && t.items[id].r > 0) v.sel[id] = 1;
    A.items({ IncludeItemTypes: 'Movie,Series', SortBy: 'CommunityRating,Random', SortOrder: 'Descending', Limit: 120, MinCommunityRating: 6.5, Fields: 'Genres' })
      .then(function (l) {
        /* on mélange les mieux notés pour couvrir un maximum de genres différents */
        var byG = {}, out = [], seen = {};
        l.forEach(function (it) { var g = (it.Genres || ['?'])[0]; (byG[g] = byG[g] || []).push(it); });
        var keys = Object.keys(byG), more = true;
        while (more && out.length < 48) {
          more = false;
          keys.forEach(function (g) { var it = byG[g].shift(); if (it && !seen[it.Id] && out.length < 48) { seen[it.Id] = 1; out.push(it); more = true; } });
        }
        v.items = out;
        v.build();
      }).catch(function () { TVM.toast('Titres indisponibles'); });
    v.btns = new TVM.List([v.el.querySelector('.later'), v.el.querySelector('.go')]);
    v.btns.i = 1;
    v.el.querySelector('.later').addEventListener('click', function () { v.finish(false); });
    v.el.querySelector('.go').addEventListener('click', function () { v.finish(true); });
  };
  var Q = TVM.TasteQuizView.prototype;
  Q.build = function () {
    var v = this, grid = v.el.querySelector('.qgrid');
    grid.innerHTML = '';
    v.cards = v.items.map(function (it, n) {
      var src = A.poster(it, 300), d = el('div', 'qi' + (v.sel[it.Id] ? ' on' : ''),
        (src ? '<img src="' + src + '">' : '<div class="noimg">' + esc(it.Name) + '</div>') +
        '<i class="qck">' + TVM.ICON.check + '</i>');
      d.addEventListener('click', function () { v.i = n; v.toggle(); });
      grid.appendChild(d);
      return d;
    });
    v.paint();
  };
  Q.count = function () { return Object.keys(this.sel).length; };
  Q.toggle = function () {
    var v = this, it = v.items[v.i];
    if (!it) return;
    if (v.sel[it.Id]) delete v.sel[it.Id]; else v.sel[it.Id] = 1;
    v.cards[v.i].classList.toggle('on', !!v.sel[it.Id]);
    v.paint();
  };
  Q.paint = function () {
    var v = this, n = v.count();
    v.el.querySelector('.qn').textContent = '(' + n + ')';
    v.el.querySelector('.go').classList.toggle('ok', n >= 3);
    (v.cards || []).forEach(function (c, j) { c.classList.toggle('f', v.zone === 'grid' && j === v.i); });
    if (v.zone === 'btns') v.btns.focus(); else v.btns.blur();
    var row = Math.floor(v.i / COLS);
    TVM.move(v.el.querySelector('.qgrid'), 0, -Math.max(0, row - 1) * TVM.rem(25.4));
  };
  Q.finish = function (ok) {
    var v = this;
    if (ok && v.count() < 3) { TVM.toast('Choisis au moins 3 titres'); return; }
    var t = get();
    if (ok) {
      v.items.forEach(function (it) {
        if (v.sel[it.Id]) { if (!t.items[it.Id] || t.items[it.Id].r < 1) t.items[it.Id] = { r: 1, g: (it.Genres || []).slice(0, 5), n: it.Name }; }
        else if (t.items[it.Id] && t.items[it.Id].r > 0) delete t.items[it.Id];
      });
    }
    t.done = true;
    save(t);
    TVM.app.pop();
    if (ok) {
      TVM.toast('Merci ! Tes recommandations sont prêtes');
      var top = TVM.app.top();
      if (top && top.scope && TVM.HomeView) TVM.app.reset(new TVM.HomeView(top.scope));
    }
  };
  Q.onShow = function () { this.paint(); };
  Q.onKey = function (k) {
    var v = this, n = v.items.length;
    if (v.zone === 'grid') {
      if (k === 'left' && v.i % COLS) { v.i--; v.paint(); return true; }
      if (k === 'right' && v.i % COLS < COLS - 1 && v.i + 1 < n) { v.i++; v.paint(); return true; }
      if (k === 'up' && v.i >= COLS) { v.i -= COLS; v.paint(); return true; }
      if (k === 'down') { if (v.i + COLS < n) v.i += COLS; else v.zone = 'btns'; v.paint(); return true; }
      if (k === 'ok') { v.toggle(); return true; }
    } else {
      if (k === 'left' || k === 'right') { v.btns.step(k === 'left' ? -1 : 1); return true; }
      if (k === 'up') { v.zone = 'grid'; v.paint(); return true; }
      if (k === 'ok') { v.finish(v.btns.i === 1); return true; }
    }
    if (k === 'back') { v.finish(false); return true; }
    return true;
  };

  /* ---------------- bouton « Évaluer » sur les fiches ---------------- */
  var THUMB = '<svg class="ico" viewBox="0 0 24 24"><path d="M7 10v10H4V10zM7 10l4-7c1.6 0 2.6 1.2 2.2 2.8L12.6 9H19a2 2 0 0 1 2 2.3l-1.2 7A2 2 0 0 1 17.8 20H7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>';
  var THUMB2 = '<svg class="ico" viewBox="0 0 24 24"><path d="M5 11v9H2v-9zM5 11l3.5-6c1.4 0 2.2 1 1.9 2.4L10 10h5.4a1.7 1.7 0 0 1 1.7 2l-1 6a1.7 1.7 0 0 1-1.7 2H5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M14 6.5l2.8-4.5c1.2 0 2 1 1.7 2.1L18 7h3.3a1.5 1.5 0 0 1 1.4 1.8l-.4 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>';
  var THUMBD = '<svg class="ico" viewBox="0 0 24 24" style="-webkit-transform:scaleY(-1);transform:scaleY(-1)"><path d="M7 10v10H4V10zM7 10l4-7c1.6 0 2.6 1.2 2.2 2.8L12.6 9H19a2 2 0 0 1 2 2.3l-1.2 7A2 2 0 0 1 17.8 20H7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>';
  var LABEL = { 0: 'Évaluer', 1: 'J’aime', 2: 'J’adore', '-1': 'Je n’aime pas' };
  var ICO = { 0: THUMB, 1: THUMB, 2: THUMB2, '-1': THUMBD };
  var NEXT = { 0: 1, 1: 2, 2: -1, '-1': 0 };
  TVM.on('detailButtons', function (list, it, v) {
    if (!it || it.Type === 'BoxSet' || it.Type === 'Episode') return;
    var r = TVM.taste.rating(it.Id);
    var b = { i: ICO[r], t: LABEL[r] + (r ? '' : ' (j’aime / je n’aime pas)'), a: function () {
      var nr = NEXT[TVM.taste.rating(it.Id)];
      TVM.taste.rate(it, nr);
      TVM.toast(nr === 0 ? 'Évaluation retirée' : LABEL[nr] + ' : c’est noté pour tes recommandations');
      v.makeMenu();
    } };
    var at = 0;
    for (var j = 0; j < list.length; j++) if (/Ma liste/.test(list[j].t || '')) at = j + 1;
    list.splice(at || list.length, 0, b);
  });
})();
