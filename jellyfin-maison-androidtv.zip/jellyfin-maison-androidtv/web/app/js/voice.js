/*
 * Jellyfin Maison — commandes vocales
 *  • Android TV / Google TV (Philips, Streamer) : l'appli écoute elle-même (reconnaissance vocale Google, en français).
 *  • LG webOS : la télé ne prête pas son micro aux applis ; on ouvre une case de texte, le micro de la
 *    Magic Remote y dicte la phrase, et la commande part toute seule.
 * Ouverture : icône micro du menu (à droite de la loupe), touche verte, ou icône micro du lecteur.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc;
  var MIC = '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm5.3-3a5.3 5.3 0 01-10.6 0H5a7 7 0 006 6.9V21h2v-3.1a7 7 0 006-6.9h-1.7z"/></svg>';
  function native() { return window.TVMNative && window.TVMNative.listen ? window.TVMNative : null; }

  /* ---------- texte : minuscules, sans accents, nombres écrits en chiffres ---------- */
  var NUM = { un: 1, une: 1, deux: 2, trois: 3, quatre: 4, cinq: 5, six: 6, sept: 7, huit: 8, neuf: 9, dix: 10, onze: 11, douze: 12,
    treize: 13, quatorze: 14, quinze: 15, seize: 16, vingt: 20, trente: 30, quarante: 40, cinquante: 50, soixante: 60, cent: 100,
    premier: 1, premiere: 1, deuxieme: 2, second: 2, seconde: 2, troisieme: 3, quatrieme: 4, cinquieme: 5, sixieme: 6, septieme: 7, huitieme: 8, neuvieme: 9, dixieme: 10 };
  function plain(s) {
    s = String(s || '').toLowerCase();
    try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (e) {}
    return s.replace(/[’`]/g, "'").replace(/[!?.,;:«»"]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function digits(s) {
    return s.replace(/\b(une? demi[- ]heure)\b/g, '30 minutes').replace(/\bdemi[- ]heure\b/g, '30 minutes')
      .replace(/\b([a-z]+)\b/g, function (w) { return NUM.hasOwnProperty(w) && !/^(une?|seconde)$/.test(w) ? String(NUM[w]) : w; });
  }
  /* « 1 heure 20 », « 12 minutes », « 2 min 30 », « 45 secondes » → secondes */
  function duration(s) {
    var t = 0, hit = false, m;
    s = s.replace(/\bune? (heure|minute|seconde)/g, '1 $1');
    if ((m = /(\d+)\s*(h\b|heures?)\s*(\d+)?/.exec(s))) { t += +m[1] * 3600 + (m[3] ? +m[3] * 60 : 0); hit = true; s = s.replace(m[0], ' '); }
    if ((m = /(\d+)\s*(min\b|minutes?|mn\b)\s*(\d+)?/.exec(s))) { t += +m[1] * 60 + (m[3] ? +m[3] : 0); hit = true; s = s.replace(m[0], ' '); }
    if ((m = /(\d+)\s*(s\b|sec\b|secondes?)/.exec(s))) { t += +m[1]; hit = true; }
    return hit ? t : null;
  }
  function stripArticles(s) {
    return s.replace(/^(moi |nous )/, '').replace(/^(le film |la serie |le dessin anime |l'episode |le documentaire |l'anime )/, '')
      .replace(/^(les |le |la |l'|un |une |des |du |de la |de l'|de )/, '').trim();
  }
  function sim(a, b) {                 /* proximité de deux titres (0 à 1) */
    a = plain(a); b = plain(b);
    if (a === b) return 1;
    if (a.indexOf(b) === 0 || b.indexOf(a) === 0) return .85;
    if (a.indexOf(b) >= 0 || b.indexOf(a) >= 0) return .7;
    var wa = a.split(' '), wb = b.split(' '), n = 0;
    wb.forEach(function (w) { if (w.length > 1 && wa.indexOf(w) >= 0) n++; });
    return n / Math.max(wa.length, wb.length) * .6;
  }

  /* ---------- langues (audio et sous-titres) ---------- */
  var LANG = [
    [/francais|french|vf\b/, ['fre', 'fra', 'fr', 'français', 'french']],
    [/anglais|english/, ['eng', 'en', 'anglais', 'english']],
    [/japonais/, ['jpn', 'ja', 'japonais', 'japanese']],
    [/espagnol/, ['spa', 'es', 'espagnol', 'spanish']],
    [/arabe/, ['ara', 'ar', 'arabe', 'arabic']],
    [/allemand/, ['ger', 'deu', 'de', 'allemand', 'german']],
    [/italien/, ['ita', 'it', 'italien', 'italian']],
    [/portugais/, ['por', 'pt', 'portugais', 'portuguese']],
    [/coreen/, ['kor', 'ko', 'coréen', 'korean']],
    [/turc/, ['tur', 'tr', 'turc', 'turkish']]
  ];
  function langOf(s) { for (var i = 0; i < LANG.length; i++) if (LANG[i][0].test(s)) return LANG[i][1]; return null; }
  function streamLang(st, codes) {
    var l = String(st.Language || '').toLowerCase(), t = plain(st.DisplayTitle || st.Title || '');
    for (var i = 0; i < codes.length; i++) if (l === codes[i] || t.indexOf(plain(codes[i])) >= 0) return true;
    return false;
  }

  /* ---------- l'écran d'écoute ---------- */
  function VoiceView(opts) {
    var v = this;
    v.overlay = true;
    v.lg = !native();
    v.el = el('div', 'view voice-ov');
    v.el.innerHTML = '<div class="vbox"><div class="vmic"><i></i><i></i>' + MIC + '</div><div class="vtxt dim"></div><div class="vhint"></div></div>';
    v.txt = v.el.querySelector('.vtxt');
    v.hint = v.el.querySelector('.vhint');
    v.hint.innerHTML = 'Dis par exemple : <b>« Mets Bluey »</b> · <b>« Pause »</b> · <b>« Avance de 2 minutes »</b> · <b>« Sous-titres en français »</b> · <b>« Profil Lina »</b> · <b>« Aide »</b>';
    if (v.lg) {
      v.inp = el('input', 'vin');
      v.inp.setAttribute('autocomplete', 'off');
      v.inp.placeholder = 'Appuie sur le micro de la télécommande et parle…';
      v.el.querySelector('.vbox').appendChild(v.inp);
      v.inp.addEventListener('input', function () {
        clearTimeout(v.t);
        if (v.inp.value.trim()) v.t = setTimeout(function () { v.finish(v.inp.value); }, 1600);
      });
      v.set('listening', 'Je t\'écoute…');
    }
    v.duck();
  }
  VoiceView.prototype.set = function (state, text, dim) {
    this.el.className = 'view voice-ov ' + (state || '');
    this.txt.textContent = text || '';
    this.txt.classList.toggle('dim', dim !== false && state !== 'heard');
  };
  /* baisse le son de la vidéo pendant l'écoute */
  VoiceView.prototype.duck = function () {
    var p = this.under();
    if (p && p.video && !p.video.paused) { this.duckVol = p.video.volume; p.video.volume = Math.min(p.video.volume, .15); }
  };
  VoiceView.prototype.unduck = function () {
    var p = this.under();
    if (p && p.video && this.duckVol != null) p.video.volume = this.duckVol;
    this.duckVol = null;
  };
  VoiceView.prototype.under = function () { var s = TVM.app.stack; return s[s.length - 2] || null; };
  VoiceView.prototype.listen = function () {
    var n = native();
    if (this.lg) { this.inp.value = ''; this.inp.focus(); return; }
    this.set('thinking', 'Un instant…');
    try { n.listen(); } catch (e) { this.fail('Micro indisponible'); }
  };
  VoiceView.prototype.onShow = function () {
    var v = this;
    if (v.lg) setTimeout(function () { v.inp.focus(); }, 150);
  };
  VoiceView.prototype.fail = function (msg) {
    var v = this;
    v.set('', msg + ' — OK pour réessayer');
    clearTimeout(v.closeT);
    v.closeT = setTimeout(function () { if (TVM.app.top() === v) v.close(); }, 6000);
  };
  VoiceView.prototype.close = function () {
    clearTimeout(this.t); clearTimeout(this.closeT);
    if (!this.lg) { try { native().stopListen(); } catch (e) {} }
    this.unduck();
    if (TVM.app.top() === this) TVM.app.pop();
    if (V.cur === this) V.cur = null;
  };
  VoiceView.prototype.finish = function (text) {
    var v = this;
    if (v.done) return;
    v.done = true;
    clearTimeout(v.t);
    v.set('heard', '« ' + text + ' »');
    setTimeout(function () { v.close(); V.run(text); }, 450);
  };
  VoiceView.prototype.onKey = function (k) {
    var v = this;
    if (k === 'back') { v.close(); return true; }
    if (k === 'ok') {
      if (v.lg && v.inp.value.trim()) { v.finish(v.inp.value); return true; }
      v.done = false; clearTimeout(v.closeT); v.listen(); return true;
    }
    if (v.lg && (k === 'left' || k === 'right')) return false;
    return true;
  };
  VoiceView.prototype.destroy = function () { clearTimeout(this.t); clearTimeout(this.closeT); };

  /* ---------- aide : tout ce qu'on peut dire ---------- */
  function HelpView() {
    this.overlay = true;
    this.el = el('div', 'view voice-ov');
    var droid = !!native();
    var H = [
      ['Regarder', ['« Mets Bluey » · « Lance Avatar »', '« Regarde la saison 2 épisode 3 de Lupin »', '« Reprends ma série » · « Continue »', '« Mets une comédie » · « Un dessin animé »', '« Surprends-moi » (au hasard)', '« Ouvre la fiche de Dune » · « Cherche Marvel »']],
      ['Pendant la vidéo', ['« Pause » · « Reprends » · « Stop »', '« Avance de 2 minutes » · « Recule de 30 secondes »', '« Va à 1 heure 20 » · « Recommence »', '« Passe l\'intro » · « Passe le générique »', '« Épisode suivant » · « Épisode précédent »', '« Sous-titres en français » · « Enlève les sous-titres »', '« En anglais » · « Version originale » · « En français »', '« C\'est quoi ? » (titre et infos)']],
      ['Minuterie', ['« Arrête dans 30 minutes » · « Minuterie 1 heure »', '« Arrête à la fin de l\'épisode » · « Annule la minuterie »']],
      ['Navigation', ['« Accueil » · « Séries » · « Films » · « Animé »', '« Nouveautés » · « Ma liste » · « Catégories »', '« Profil Lina » · « Changer de profil »', '« Réglages » · « Écran de veille »', '« Quitte l\'application »']],
      ['Mes goûts', ['« J\'aime » · « J\'adore » · « Je n\'aime pas »', '« Ajoute à ma liste » · « Retire de ma liste »']]
    ];
    if (droid) H.push(['Son', ['« Monte le son » · « Baisse le son »', '« Coupe le son » · « Remets le son »', '« Volume à 30 »']]);
    var h = '<div class="vhelp"><h2>Ce que tu peux me dire</h2>';
    H.forEach(function (g) { h += '<h3>' + esc(g[0]) + '</h3>' + g[1].map(function (l) { return '<p>' + esc(l) + '</p>'; }).join(''); });
    this.el.innerHTML = h + '</div>';
  }
  HelpView.prototype.onKey = function (k) { if (k === 'back' || k === 'ok') { TVM.app.pop(); return true; } return true; };

  /* ---------- actions ---------- */
  function top() { return TVM.app.top(); }
  function player() { var t = top(); return t && t.video && t.item ? t : null; }
  function say(m) { TVM.toast(m); }
  function home(scope) { TVM.app.reset(new TVM.HomeView(scope || TVM.homeScope || { type: 'home' })); }
  function isKids() { return TVM.homeScope && TVM.homeScope.type === 'kids'; }

  function findTitle(q, types) {
    return A.items({ SearchTerm: q, IncludeItemTypes: types || 'Movie,Series,BoxSet', Limit: 20, Fields: 'Genres' }).then(function (l) {
      if (!l.length) return null;
      l.sort(function (a, b) { return sim(b.Name, q) - sim(a.Name, q); });
      return l[0];
    });
  }
  function genreMatch(q) {
    q = plain(q).replace(/s$/, '');
    if (/dessins? animes?|cartoon/.test(q)) q = 'animation';
    return A.genres({ IncludeItemTypes: 'Movie,Series' }).then(function (gs) {
      var best = null;
      gs.forEach(function (g) {
        var a = plain((TVM.genreFr || String)(g.Name)).replace(/s$/, ''), b = plain(g.Name).replace(/s$/, '');
        if (a === q || b === q || (q.length > 3 && (a.indexOf(q) === 0 || b.indexOf(q) === 0))) best = best || g;
      });
      return best;
    }).catch(function () { return null; });
  }
  function randomIn(q) {
    var p = { SortBy: 'Random', Limit: 1, IncludeItemTypes: q.types || 'Movie,Series' };
    if (q.genre) p.Genres = q.genre;
    if (isKids() && TVM.homeScope.libs && TVM.homeScope.libs.length) {
      p.ParentId = TVM.homeScope.libs[Math.floor(Math.random() * TVM.homeScope.libs.length)].Id;
    }
    return A.items(p).then(function (l) { return l[0] || null; });
  }
  function play(it, label) {
    if (!it) { say('Je n\'ai rien trouvé'); return; }
    var p = player(); if (p) p.quit();
    say('▶ ' + (label || it.Name));
    TVM.playItem(it);
  }
  function playEpisode(series, season, ep) {
    return A.episodes(series.Id, {}).then(function (eps) {
      var hit = eps.filter(function (e) { return (season == null || (e.ParentIndexNumber || 1) === season) && (ep == null || e.IndexNumber === ep); })[0];
      if (!hit) { say('Épisode introuvable dans ' + series.Name); return; }
      var p = player(); if (p) p.quit();
      say('▶ ' + series.Name + ' · S' + (hit.ParentIndexNumber || 1) + ' E' + hit.IndexNumber);
      TVM.app.push(new TVM.PlayerView(hit));
    });
  }
  function details(it) {
    if (!it) { say('Je n\'ai rien trouvé'); return; }
    TVM.app.push(new TVM.DetailsView(it));
  }
  function search(q) {
    var s = new TVM.SearchView();
    s.q = q; s.paintQ(); clearTimeout(s.t); s.load();
    TVM.app.push(s);
    say('Recherche : ' + q);
  }
  function goTab(word) {
    var kids = isKids();
    return TVM.getViews().then(function (vs) {
      var tabs = TVM.homeTabs(vs, kids), w = plain(word), hit = null;
      if (/ma liste|mes favoris|favoris/.test(w)) w = 'mon jellyfin';
      if (/^anime/.test(w)) w = 'anime';
      tabs.forEach(function (t) { if (!t.html && plain(t.label).replace(/s$/, '') === w.replace(/s$/, '')) hit = hit || t; });
      if (!hit) { say('Pas de rubrique « ' + word + ' »'); return; }
      var p = player(); if (p) p.quit();
      if (hit.scope.type === 'cats') { TVM.app.push(new TVM.CategoriesView(vs)); return; }
      home(hit.scope);
    });
  }
  function switchProfile(name) {
    var n = plain(name);
    var pv = new TVM.ProfilesView();
    TVM.app.reset(pv);
    var tries = 0;
    (function wait() {
      if (!pv.list || !pv.list.items.length) { if (++tries < 40) setTimeout(wait, 150); return; }
      var best = null, bs = 0;
      pv.list.items.forEach(function (c) {
        var u = c.__u; if (!u || !u.Id) return;
        var s = sim(u.Name || '', n); if (s > bs) { bs = s; best = c; }
      });
      if (best && bs >= .5) { pv.list.set(pv.list.items.indexOf(best)); pv.open(best.__u); }
      else say('Je ne trouve pas le profil « ' + name + ' »');
    })();
  }
  function itemHere() {                 /* le titre à l'écran : vidéo en cours ou fiche ouverte */
    var p = player(); if (p) return p.item.SeriesId ? { Id: p.item.SeriesId, Name: p.item.SeriesName, Genres: (p.full && p.full.Genres) || [] } : (p.full || p.item);
    var t = top(); if (t && t.item && t.el && /details/.test(t.el.className)) return t.item;
    if (t && t.hero && t.hero.items && t.hero.items[t.hero.i]) return t.hero.items[t.hero.i];
    return null;
  }
  function volume(what) {
    var n = native();
    if (!n || !n.volume) { say('Utilise la télécommande pour le volume'); return; }
    try { n.volume(what); } catch (e) {}
  }

  /* commandes du lecteur ; renvoie true si la phrase a été comprise */
  function playerCmd(p, s) {
    var d;
    if (/^(pause|mets? (en )?pause|stop pause|arrete une seconde|attends)/.test(s) || s === 'pause') { p.video.pause(); return true; }
    if (/^(reprends?|reprendre|lecture|play|continue|relance|vas y|c'?est reparti)$/.test(s)) { p.play(); p.show(); return true; }
    if (/(passe|saute|zappe|skip|passer).*(intro|generique|recap|resume|debut)|^(passe|saute|skip)$/.test(s)) {
      if (p.skipL && p.skipK) { var b = p.skipL.items[p.skipL.items.length - 1]; if (b && b.__a) b.__a(); return true; }
      if (/generique/.test(s) && p.nextEp) { p.playNext(); return true; }
      if (/intro|debut/.test(s)) { p.seekBy(85, true); say('Intro passée (+85 s)'); return true; }
      say('Rien à passer pour l\'instant'); return true;
    }
    if (/(episode )?suivant|prochain episode|^suite$/.test(s)) { if (p.nextEp) p.playNext(); else say('Pas d\'épisode suivant'); return true; }
    if (/(episode )?precedent|episode d'?avant/.test(s)) {
      var it = p.item; if (!it.SeriesId) { say('Ce n\'est pas une série'); return true; }
      A.episodes(it.SeriesId, {}).then(function (eps) {
        var i = -1; eps.forEach(function (e, k) { if (e.Id === it.Id) i = k; });
        if (i > 0) { p.quit(); TVM.app.push(new TVM.PlayerView(eps[i - 1])); } else say('C\'est le premier épisode');
      });
      return true;
    }
    if (/recommence|depuis le debut|au debut|du debut|reprendre a zero/.test(s)) { p.seekTo(0); p.play(); return true; }
    if (/^(recule|retour en arriere|reviens|en arriere|rembobine)/.test(s)) { d = duration(s); p.seekBy(-(d || 30), true); return true; }
    if (/^(avance|en avant|plus loin)/.test(s)) { d = duration(s); p.seekBy(d || 30, true); return true; }
    if (/^(va|aller|vas|saute|mets?|positionne|reprends?)( toi)? (a|au|vers) /.test(s) && (d = duration(s)) != null) { p.seekTo(d); p.play(); p.show(); return true; }
    if (/sous[- ]?titres?|sous[- ]?titrage/.test(s)) {
      var subs = (p.streams || []).filter(function (x) { return x.Type === 'Subtitle'; });
      if (/(enleve|desactive|coupe|sans|retire|pas de|aucun|stop|arrete|cache|vire)/.test(s)) { p.setTracks(null, -1); say('Sous-titres désactivés'); return true; }
      var codes = langOf(s) || ['fre', 'fra', 'fr', 'français'];
      var st = subs.filter(function (x) { return streamLang(x, codes) && !/forc|forced/i.test(x.DisplayTitle || ''); })[0] || subs.filter(function (x) { return streamLang(x, codes); })[0];
      if (!st) { say('Pas de sous-titres dans cette langue'); return true; }
      p.setTracks(null, st.Index); say('Sous-titres : ' + (st.DisplayTitle || st.Language)); return true;
    }
    if (/version originale|^vo$|en vo\b|(audio|langue|son|version|mets?|passe|en) .*(francais|anglais|japonais|espagnol|arabe|allemand|italien|portugais|coreen|turc)|^(en )?(francais|anglais|japonais|espagnol|arabe|allemand|italien)$/.test(s)) {
      var auds = (p.streams || []).filter(function (x) { return x.Type === 'Audio'; }), a;
      if (/version originale|\bvo\b/.test(s)) a = auds.filter(function (x) { return !streamLang(x, LANG[0][1]); })[0];
      else { var c = langOf(s); a = c && auds.filter(function (x) { return streamLang(x, c); })[0]; }
      if (!a) { say('Langue non disponible'); return true; }
      p.setTracks(a.Index, p.subIdx == null ? -1 : p.subIdx); say('Audio : ' + (a.DisplayTitle || a.Language)); return true;
    }
    if (/^(stop|arrete|quitte|quitter|sors|ferme|retour|termine)( la video| la lecture| le film| l'episode)?$/.test(s)) { p.quit(); return true; }
    if (/c'?est quoi|qu'?est-ce que (je|on) regarde|^infos?$|^titre$|il reste combien|combien de temps/.test(s)) {
      var left = Math.max(0, (p.dur() || 0) - (p.video.currentTime || 0)), m = Math.round(left / 60);
      say(p.item.SeriesName ? p.item.SeriesName + ' · S' + (p.item.ParentIndexNumber || 1) + ' E' + p.item.IndexNumber + ' · ' + p.item.Name + ' — encore ' + m + ' min' : p.item.Name + ' — encore ' + m + ' min');
      p.show(); return true;
    }
    return false;
  }

  var V = TVM.voice = {
    available: function () { return true; },
    start: function () {
      if (V.cur && TVM.app.top() === V.cur) return;
      var t = TVM.app.top();
      if (t && t.overlay && t.el && /voice-ov/.test(t.el.className)) TVM.app.pop();
      V.cur = new VoiceView();
      TVM.app.push(V.cur);
      if (!V.cur.lg) V.cur.listen();
    },
    /* appelé par l'appli Android : listening | partial | thinking | result | error */
    native: function (type, text) {
      var v = V.cur; if (!v || TVM.app.top() !== v) return;
      if (type === 'listening') v.set('listening', 'Je t\'écoute…');
      else if (type === 'partial') v.set('listening', text, false);
      else if (type === 'thinking') v.set('thinking', v.txt.textContent || 'Un instant…');
      else if (type === 'result') { if (text) v.finish(text); else v.fail('Je n\'ai rien entendu'); }
      else if (type === 'error') v.fail(text || 'Je n\'ai pas compris');
    },
    run: function (raw) {
      try { V.handle(raw); } catch (e) { console.error(e); say('Je n\'ai pas compris'); }
    },
    handle: function (raw) {
      var s = plain(raw), m, q, sd;
      if (!s) return;
      s = s.replace(/^(ok |dis |hey |eh )?(jellyfin|google)\b ?/, '').replace(/^(s'?il te plait|stp) |( s'?il te plait| stp)$/g, '').trim();
      sd = digits(s);                    /* « deux minutes » → « 2 minutes » (pour les durées, saisons, volume) */

      /* aide */
      if (/^(aide|help|que (puis|peux)[- ]je dire|quelles? (sont les )?commandes|qu'?est-ce que je peux dire|commandes vocales)/.test(s)) { TVM.app.push(new HelpView()); return; }
      /* application */
      if (/(quitte|ferme|quitter|fermer|sors? de) (l'?appli|l'?application|jellyfin)/.test(s)) { TVM.exit(); return; }
      /* son de la télé */
      if (/(monte|augmente|hausse|plus fort|met plus fort|mets plus fort).*|^plus fort$/.test(s) && /(son|volume|fort)/.test(s)) { volume('up'); return; }
      if (/(baisse|diminue|moins fort)/.test(s) && /(son|volume|fort)/.test(s)) { volume('down'); return; }
      if (/^(coupe|couper|mute|silence|chut)|coupe le son/.test(s)) { volume('mute'); return; }
      if (/(remets?|reactive|rallume|retablis) (le )?son/.test(s)) { volume('unmute'); return; }
      if ((m = /volume (a |au )?(\d+)/.exec(sd))) { volume('set:' + Math.min(100, +m[2])); return; }

      /* minuterie de sommeil */
      if (/(annule|enleve|desactive|arrete|supprime) (la )?minuterie/.test(s)) { TVM.setSleep(0); return; }
      if (/minuterie|(arrete|eteins|coupe|stoppe|ferme)(-toi| tout| la tele| l'?appli)? (dans|a la fin|apres)|^dans \d+ (min|minutes|heure)/.test(sd)) {
        if (/fin (de l'?episode|du film|de la video)|apres (cet|l'?)episode/.test(sd)) { TVM.setSleep('ep'); return; }
        var dm = duration(sd);
        if (dm) { TVM.setSleep(Math.max(1, Math.round(dm / 60))); return; }
        TVM.openSleep(); return;
      }

      /* pendant une vidéo */
      var p = player();
      if (p && playerCmd(p, sd)) return;

      /* mes goûts et ma liste (titre à l'écran) */
      if (/^(j'?adore|je l'?adore|coup de coeur)/.test(s) || /^(j'?aime pas|je n'?aime pas|j'?aime vraiment pas|pas pour moi|bof)/.test(s) || /^(j'?aime|j'?aime bien|c'?est bien|top)$/.test(s)) {
        var it = itemHere(); if (!it) { say('Quel titre ? Ouvre d\'abord sa fiche'); return; }
        var r = /pas|bof/.test(s) ? -1 : /adore|coeur/.test(s) ? 2 : 1;
        if (TVM.taste) TVM.taste.rate(it, r);
        say((r === 2 ? '❤ J\'adore' : r === 1 ? '👍 J\'aime' : '👎 Je n\'aime pas') + ' : ' + it.Name); return;
      }
      if (/(ajoute|mets?|met) .*(ma liste|mes favoris|favoris)|^ajoute a ma liste/.test(s) || /(retire|enleve|supprime) .*(ma liste|favoris)/.test(s)) {
        var it2 = itemHere(), on = !/retire|enleve|supprime/.test(s);
        if (!it2) { say('Quel titre ? Ouvre d\'abord sa fiche'); return; }
        A.setFavorite(it2.Id, on).then(function () { say((on ? '✓ Ajouté à Ma liste : ' : 'Retiré de Ma liste : ') + it2.Name); }, function () { say('Impossible pour l\'instant'); });
        return;
      }

      /* navigation */
      if (/^(retour (a l'?)?accueil|accueil|page d'?accueil|menu principal|maison|reviens a l'?accueil|va a l'?accueil)$/.test(s)) { var pp = player(); if (pp) pp.quit(); home(); return; }
      if ((m = /^(?:va |vas |aller |ouvre |affiche |montre(?:-moi)? |mets |passe )?(?:sur |dans |aux? |les |la |l'|mes |ma )*(series|serie|films|film|animes?|anime|nouveautes|mon jellyfin|ma liste|mes favoris|categories|genres)$/.exec(s))) {
        goTab(m[1] === 'genres' ? 'categories' : m[1] === 'serie' ? 'series' : m[1] === 'film' ? 'films' : m[1]); return;
      }
      if (/^(reglages|parametres|ouvre les (reglages|parametres)|options)$/.test(s)) { TVM.app.push(new TVM.SettingsView()); return; }
      if (/^(change(r)? de profil|changer d'?utilisateur|qui est-ce|profils|autre profil)$/.test(s)) { var p3 = player(); if (p3) p3.quit(); TVM.app.reset(new TVM.ProfilesView()); return; }
      if ((m = /^(?:profil(?: de)?|passe sur(?: le profil(?: de)?)?|va sur(?: le profil(?: de)?)?|ouvre le profil(?: de)?|c'?est|je suis|connecte(?:-moi)?(?: a| sur)?(?: le profil(?: de)?)?) (.+)$/.exec(s)) && !/^(un|une|le|la|les|quoi)\b/.test(m[1])) {
        var p4 = player(); if (p4) p4.quit(); switchProfile(m[1]); return;
      }
      if (/ecran de veille|economiseur/.test(s)) { if (TVM.saverShow) TVM.saverShow(); return; }
      if (/^(reprends?|continue|reprendre)( (ma|mon|la|le) (serie|film|lecture|video|episode))?$/.test(s) || /^(ou j'?en etais|la suite)$/.test(s)) {
        A.resumeItems({ Limit: 1 }).then(function (l) { if (l && l[0]) { say('▶ ' + (l[0].SeriesName || l[0].Name)); TVM.app.push(new TVM.PlayerView(l[0])); } else say('Rien à reprendre'); });
        return;
      }

      /* « au hasard » */
      if (/surprends?[- ]moi|au hasard|n'?importe quoi|choisis pour moi|un truc a regarder/.test(s)) {
        var types = /serie/.test(s) ? 'Series' : /film/.test(s) ? 'Movie' : 'Movie,Series';
        randomIn({ types: types }).then(function (it) { play(it, it && 'Au hasard : ' + it.Name); }); return;
      }

      /* fiche d'un titre */
      if ((m = /^(?:ouvre|montre(?:-moi)?|affiche|fiche(?: de)?|infos?(?: sur| de)?|parle(?:-moi)? de|c'?est quoi|details?(?: de)?)(?: la fiche(?: de| du)?)? (.+)$/.exec(s))) {
        q = stripArticles(m[1]);
        findTitle(q).then(details); return;
      }
      /* chercher */
      if ((m = /^(?:cherche|recherche|trouve|trouve-moi|chercher) (.+)$/.exec(s))) { search(stripArticles(m[1])); return; }

      /* regarder un titre (avec saison / épisode éventuels) */
      m = /^(?:mets?|met|lance|regarde|regarder|joue|je veux (?:voir|regarder)|on regarde|j'?ai envie de (?:voir|regarder)|demarre|passe|play|montre|ecouter|on mate|mate)(?:-moi| moi| nous)? (.+)$/.exec(s);
      q = m ? m[1] : s;
      var qd = digits(q), se = /saison (\d+)/.exec(qd), ep = /episode (\d+)/.exec(qd);
      if (se || ep) q = qd.replace(/(la |le |l')?(saison \d+|episode \d+)( de| du| des)?/g, ' ').replace(/\s+/g, ' ').trim();
      q = stripArticles(q);
      if (!q) { say('Je n\'ai pas compris'); return; }
      var wantGenre = /^(une?|des) /.test(m ? m[1] : '') || /^(comedie|action|horreur|drame|aventure|animation|dessins? animes?|documentaire|policier|thriller|romance|science-fiction|fantastique|famille|guerre|western|musique|histoire)s?$/.test(q);
      var tryGenre = function () {
        return genreMatch(q).then(function (g) {
          if (!g) return false;
          var types = /serie/.test(s) ? 'Series' : /film/.test(s) ? 'Movie' : 'Movie,Series';
          return randomIn({ genre: g.Name, types: types }).then(function (it) { play(it, it && ((TVM.genreFr || String)(g.Name) + ' : ' + it.Name)); return true; });
        });
      };
      var tryTitle = function () {
        return findTitle(q, se || ep ? 'Series' : null).then(function (it) {
          if (!it || sim(it.Name, q) < .3) return false;
          if ((se || ep) && it.Type === 'Series') { playEpisode(it, se ? +se[1] : (ep ? 1 : null), ep ? +ep[1] : 1); return true; }
          play(it); return true;
        });
      };
      (wantGenre ? tryGenre().then(function (ok) { return ok || tryTitle(); }) : tryTitle().then(function (ok) { return ok || tryGenre(); }))
        .then(function (ok) { if (!ok) { if (m) say('Je ne trouve pas « ' + q + ' »'); search(q); } })
        .catch(function () { search(q); });
    }
  };
  TVM.VoiceHelpView = HelpView;
})();
