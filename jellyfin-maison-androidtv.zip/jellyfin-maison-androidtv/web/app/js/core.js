/*
 * Jellyfin Maison (webOS) — noyau
 * Écrit en JavaScript ES5 : le navigateur de la LG C9 (webOS 4) est un Chromium 53.
 * Tout est exposé dans window.TVM pour tes extensions (voir README).
 */
(function () {
  'use strict';
  var TVM = window.TVM = window.TVM || {};
  TVM.version = '3.0.0';
  /* même appli sur LG webOS et sur Android TV / Google TV (Philips…) : l'APK fournit window.TVMNative */
  TVM.android = !!window.TVMNative;
  TVM.deviceName = TVM.android ? 'Android TV' : 'LG webOS';
  document.documentElement.className += ' tvm';     /* pour cibler l'appli dans le CSS du serveur : .tvm … */

  /* ======== Réglages (modifiables par une extension : TVM.config.xxx = …) ======== */
  TVM.config = {
    heroInterval: 10000,      // ms entre deux titres du bandeau
    heroCount: 6,             // titres qui défilent dans le bandeau
    genreRows: 24,            // rangées de genres sur une page
    rowSize: 30,              // titres par rangée
    minRow: 6,                // une rangée avec moins de titres n'est pas affichée (pas de « trous »)
    dedupe: true,             // « une affiche à la fois » : un titre n'apparaît qu'une fois par page
    imgQuality: 80,           // qualité des images demandées au serveur
    posterWidth: 240,         // largeur des jaquettes demandées (px)
    landWidth: 420,           // largeur des vignettes paysage
    backdropWidth: 1280,      // largeur des grands fonds
    seekStep: 10,             // secondes pour ← → dans le lecteur
    hideAfter: 4000,          // ms avant de cacher les commandes pendant la lecture
    pauseScreenAfter: 8000,   // ms de pause avant l'écran « Vous regardez » (0 = jamais)
    nextCountdown: 10,        // secondes du compte à rebours « Épisode suivant »
    creditsFallback: 30,      // sans segment « générique » : proposer l'épisode suivant X s avant la fin
    progressEvery: 10000,     // ms entre deux enregistrements de la position de lecture
    tabDelay: 2000,           // ms sur un onglet du menu avant de l'ouvrir tout seul
    keyRepeatMs: 85,          // cadence mini d'une flèche maintenue (elle accélère si on garde le doigt appuyé)
    imgWebp: true,            // images en WebP (plus légères, chargent plus vite)
    stillThere: 3,            // « Vous regardez toujours ? » après N épisodes enchaînés sans toucher la télécommande (0 = jamais)
    audioLang: ['fre', 'fra', 'fr', 'french', 'français', 'francais'],
    subtitleLang: [],         // ex. ['fre'] pour activer des sous-titres français par défaut
    kidsLibs: /jeunesse|junior|anim|kids|enfant/i,  // médiathèques de l'espace Jeunesse
    tabs: null                // null = automatique ; sinon liste [{label:'Séries', match:/s[ée]rie/i}, …]
  };

  /* ======== Ton logo (repris de ton « tout en un ») ======== */
  var LOGO_SVG = '<svg class="lm" viewBox="0 0 34 52" aria-hidden="true"><defs><linearGradient id="tvmG" x1="0" y1="0" x2="1" y2="0">' +
    '<stop offset="0" stop-color="#6dff6d"/><stop offset="1" stop-color="#1fb81f"/></linearGradient></defs>' +
    '<path fill="url(#tvmG)" d="M18 6L32 2V34A15 15 0 0 1 2 34V26H14V34A4 4 0 0 0 18 34Z"/><path d="M25 4V37" stroke="#0e8a1c" stroke-width="1.2"/></svg>';
  /* chaque logo a son propre dégradé : un dégradé partagé disparaît quand la page qui le contient est cachée */
  var logoN = 0;
  TVM.logoMark = function () { var id = 'tvmG' + (++logoN); return LOGO_SVG.replace(/tvmG/g, id); };
  TVM.LOGO_MARK = LOGO_SVG;
  /* petites icônes dessinées (les symboles du type ⚙ ☰ n'existent pas dans la police de la télé) */
  TVM.ICON = {
    gear: '<svg class="ico" viewBox="0 0 24 24"><path d="M21.80 10.01 L21.80 13.99 L19.19 14.46 L18.83 15.34 L20.33 17.53 L17.53 20.33 L15.34 18.83 L14.47 19.19 L13.99 21.80 L10.01 21.80 L9.54 19.19 L8.66 18.83 L6.47 20.33 L3.67 17.53 L5.17 15.34 L4.81 14.47 L2.20 13.99 L2.20 10.01 L4.81 9.54 L5.17 8.66 L3.67 6.47 L6.47 3.67 L8.66 5.17 L9.53 4.81 L10.01 2.20 L13.99 2.20 L14.46 4.81 L15.34 5.17 L17.53 3.67 L20.33 6.47 L18.83 8.66 L19.19 9.53Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="12" cy="12" r="3.9" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>',
    chevron: '<svg class="ico" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    play: '<svg class="ico" viewBox="0 0 24 24"><path fill="currentColor" d="M7 4.5v15l12.5-7.5z"/></svg>',
    restart: '<svg class="ico" viewBox="0 0 24 24"><path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3M4 3.5V8h4.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    episodes: '<svg class="ico" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="1.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10 7.5v5l4-2.5z" fill="currentColor"/><path d="M5 20h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    plus: '<svg class="ico" viewBox="0 0 24 24"><path d="M12 4v16M4 12h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
    check: '<svg class="ico" viewBox="0 0 24 24"><path d="M4.5 12.5l5 5 10-11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    similar: '<svg class="ico" viewBox="0 0 24 24"><rect x="3" y="3" width="7.5" height="7.5" rx="1" fill="none" stroke="currentColor" stroke-width="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1" fill="none" stroke="currentColor" stroke-width="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1" fill="none" stroke="currentColor" stroke-width="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
    collection: '<svg class="ico" viewBox="0 0 24 24"><path d="M4 7h16M6 4h12M3 10h18v10H3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>'
  };
  TVM.logoHtml = function () { return '<div class="logo">' + TVM.logoMark() + '<span class="lt">JELLYFIN</span></div>'; };

  /* ======== Événements pour les extensions ======== */
  var evs = {};
  TVM.on = function (name, fn) { (evs[name] = evs[name] || []).push(fn); };
  TVM.emit = function (name) {
    var args = Array.prototype.slice.call(arguments, 1), l = evs[name] || [];
    for (var i = 0; i < l.length; i++) {
      try { l[i].apply(null, args); } catch (e) { console.error('[TVM] extension « ' + name + ' »', e); }
    }
  };

  /* ======== Stockage local ======== */
  TVM.store = {
    get: function (k, d) {
      try { var v = localStorage.getItem('tvm.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; }
    },
    set: function (k, v) { try { localStorage.setItem('tvm.' + k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ======== Outils ======== */
  TVM.el = function (tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  };
  TVM.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  TVM.fmt = function (sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (s < 10 ? '0' : '') + s;
  };
  TVM.duration = function (ticks) {
    var m = Math.round((ticks || 0) / 6e8);
    if (!m) return '';
    return m >= 60 ? Math.floor(m / 60) + ' h' + (m % 60 ? ' ' + (m % 60) + ' min' : '') : m + ' min';
  };
  TVM.move = function (el, x, y) {
    var v = 'translate3d(' + Math.round(x) + 'px,' + Math.round(y) + 'px,0)';
    el.style.webkitTransform = v;
    el.style.transform = v;
  };
  TVM.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };

  /* tailles : 1 rem = 1/120 de la largeur d'écran (16 px en 1920×1080) */
  function scale() {
    TVM.remPx = (window.innerWidth || 1920) / 120;
    document.documentElement.style.fontSize = TVM.remPx + 'px';
  }
  TVM.rem = function (n) { return n * TVM.remPx; };
  scale();
  window.addEventListener('resize', scale);

  var toastT = 0;
  TVM.toast = function (msg, ms) {
    var t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'show';
    clearTimeout(toastT);
    toastT = setTimeout(function () { t.className = ''; }, ms || 2600);
  };

  /* ======== Gestion des écrans (pile : accueil → fiche → lecteur…) ======== */
  var root = null, stack = [];
  TVM.app = {
    stack: stack,
    top: function () { return stack[stack.length - 1] || null; },
    push: function (view) {
      root = root || document.getElementById('root');
      var prev = TVM.app.top();
      if (prev) { if (prev.onHide) prev.onHide(); if (!view.overlay) prev.el.style.display = 'none'; }
      stack.push(view);
      root.appendChild(view.el);
      TVM.emit('view', view);
      if (view.onShow) view.onShow();
    },
    pop: function () {
      var v = stack.pop();
      if (v) { if (v.destroy) v.destroy(); if (v.el.parentNode) v.el.parentNode.removeChild(v.el); }
      var t = TVM.app.top();
      if (t) { t.el.style.display = ''; TVM.emit('view', t); if (t.onShow) t.onShow(); }
      return v;
    },
    /* remplace toute la pile (changement d'onglet, de profil…) */
    reset: function (view) {
      while (stack.length) TVM.app.pop();
      TVM.app.push(view);
    }
  };

  /* ======== Quitter l'appli ======== */
  TVM.exit = function () {
    try { if (window.TVMNative && window.TVMNative.exit) { window.TVMNative.exit(); return; } } catch (e) {}
    try { if (window.PalmSystem && window.PalmSystem.platformBack) { window.PalmSystem.platformBack(); return; } } catch (e) {}
    try { window.close(); } catch (e) {}
  };

  /* ======== Touches de la télécommande ======== */
  var KEYS = {
    37: 'left', 38: 'up', 39: 'right', 40: 'down', 13: 'ok',
    461: 'back', 27: 'back', 10009: 'back',
    415: 'play', 19: 'pause', 179: 'playpause', 10252: 'playpause', 413: 'stop',
    417: 'ffwd', 412: 'rew', 403: 'red', 404: 'green', 405: 'yellow', 406: 'blue', 1001: 'voice'
  };
  TVM.keyName = function (e) { return KEYS[e.keyCode] || null; };
  var lastKey = 0, holdStart = 0;
  document.addEventListener('keyup', function () { if (holdStart) { holdStart = 0; document.body.classList.remove('held'); } }, true);
  document.addEventListener('keydown', function (e) {
    var k = TVM.keyName(e);
    if (!k) return;
    var t = e.target, typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA');
    if (typing && (k === 'left' || k === 'right')) return;          // curseur dans le texte
    if (typing && e.keyCode === 8) return;
    var now = Date.now();
    TVM.lastInput = now; TVM.autoChain = 0;
    /* flèche maintenue : ça accélère au bout d'un moment */
    if (e.repeat && /left|right|up|down/.test(k)) {
      if (!holdStart) { holdStart = now; document.body.classList.add('held'); }
      var held = now - holdStart, gap = TVM.config.keyRepeatMs * (held > 2500 ? .4 : held > 900 ? .65 : 1);
      if (now - lastKey < gap) { e.preventDefault(); return; }
    } else { holdStart = 0; document.body.classList.remove('held'); }
    lastKey = now;
    var v = TVM.app.top();
    var done = false;
    /* micro : touche verte ou touche micro/recherche de la télécommande, même pendant une vidéo */
    if ((k === 'green' || k === 'voice') && TVM.voice && TVM.api && TVM.api.userId && !(v instanceof (TVM.ProfilesView || Object))) { TVM.voice.start(); e.preventDefault(); return; }
    try { done = !!(v && v.onKey && v.onKey(k, e)); } catch (err) { console.error(err); }
    if (!done && TVM.colorKey && /red|green|yellow|blue/.test(k)) { try { done = TVM.colorKey(k); } catch (err) {} }
    /* ⏩ ⏪ hors vidéo : saute 3 rangées vers le bas / le haut */
    if (!done && (k === 'ffwd' || k === 'rew') && v && v.onKey && !v.video) {
      try { for (var j = 0; j < 3; j++) v.onKey(k === 'ffwd' ? 'down' : 'up'); done = true; } catch (err) {}
    }
    if (!done && k === 'back') {
      if (stack.length > 1) { TVM.app.pop(); done = true; }
    }
    if (done || /left|right|up|down|back/.test(k)) e.preventDefault();
  }, true);

  /* ======== Petite liste focalisable (menus, boutons, réglages) ======== */
  TVM.List = function (items, opts) {
    this.items = items || [];
    this.i = 0;
    this.opts = opts || {};
  };
  TVM.List.prototype.set = function (i) {
    if (!this.items.length) return;
    i = TVM.clamp(i, 0, this.items.length - 1);
    if (this.items[this.i]) this.items[this.i].classList.remove('f');
    this.i = i;
    this.items[i].classList.add('f');
    if (this.opts.onMove) this.opts.onMove(i);
  };
  TVM.List.prototype.blur = function () { if (this.items[this.i]) this.items[this.i].classList.remove('f'); };
  TVM.List.prototype.focus = function () { this.set(this.i); };
  TVM.List.prototype.step = function (d) {
    var n = this.i + d;
    if (n < 0 || n >= this.items.length) return false;
    this.set(n);
    return true;
  };
  TVM.List.prototype.current = function () { return this.items[this.i]; };
})();

/* ======== Touches de couleur (raccourcis) et retour dans l'appli ======== */
(function () {
  /* 🔴 Accueil · 🟢 Commande vocale · 🟡 Réglages · 🔵 Changer de profil */
  TVM.colorKey = function (k) {
    var A = TVM.api, top = TVM.app.top();
    if (!A || !A.userId || !top || top instanceof (TVM.ProfilesView || Object)) return false;
    if (k === 'green' && TVM.voice) { TVM.voice.start(); return true; }          /* 🟢 commande vocale, partout */
    if (top.video) return false;
    if (k === 'red' && TVM.HomeView) { TVM.app.reset(new TVM.HomeView(TVM.homeScope || { type: 'home' })); return true; }
    if (k === 'green' && TVM.SearchView) { TVM.app.push(new TVM.SearchView()); return true; }
    if (k === 'yellow' && TVM.SettingsView) { TVM.app.push(new TVM.SettingsView()); return true; }
    if (k === 'blue' && TVM.ProfilesView) { TVM.app.reset(new TVM.ProfilesView()); return true; }
    return false;
  };
  /* appelé par l'appli Android quand on revient (veille, changement de source HDMI…) */
  TVM.onResume = function (awayMs) {
    try { if (TVM.saverHide) TVM.saverHide(); } catch (e) {}
    var top = TVM.app.top();
    if (awayMs > 4 * 3600 * 1000 && !(top && top.video)) { location.reload(); return; }
    try { if (top && top.refreshContinue) top.refreshContinue(); } catch (e) {}
  };
})();

/* messages de la mise à jour Android (téléchargement, installation) */
TVM.config.updateUrl = TVM.config.updateUrl || 'https://github.com/mohamedbousefat-tech/jellyfin-maison-tv/releases/download/derniere-version/jellyfin-maison-tv.apk';
TVM.updateState = function (msg) { try { TVM.toast(msg); } catch (e) {} };
