/*
 * Jellyfin Maison (webOS) — fiche d'un titre, façon Netflix sur télé
 *
 *  1. Présentation : grand fond, logo, infos, résumé et un menu vertical
 *     (Lecture / Épisodes / Depuis le début / Ma liste / Titres similaires).
 *  2. « Épisodes » : saisons en colonne à gauche, épisodes en ligne à droite,
 *     résumé de l'épisode choisi en dessous.
 *  3. « Titres similaires » / « Dans cette collection » : une rangée d'affiches.
 *  Retour : revient d'un cran (épisodes → présentation → page précédente).
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config;

  /* lancer un titre : film / épisode directement ; série → prochain épisode à voir */
  TVM.playItem = function (it, opts) {
    if (it.Type === 'Series' || it.Type === 'Season') {
      var sid = it.Type === 'Series' ? it.Id : it.SeriesId;
      return A.nextUp({ SeriesId: sid, Limit: 1 }).then(function (l) {
        if (l[0]) return l[0];
        return A.episodes(sid, { Limit: 1 }).then(function (e) { return e[0]; });
      }).then(function (ep) {
        if (ep) TVM.app.push(new TVM.PlayerView(ep, opts)); else TVM.toast('Aucun épisode disponible');
      }).catch(function () { TVM.toast('Lecture impossible'); });
    }
    if (it.Type === 'BoxSet') { TVM.app.push(new TVM.DetailsView(it)); return Promise.resolve(); }
    TVM.app.push(new TVM.PlayerView(it, opts));
    return Promise.resolve();
  };

  TVM.DetailsView = function (item) {
    var v = this;
    v.item = item;
    v.alive = true;
    v.mode = 'info';            /* info | eps | sim */
    v.el = el('div', 'view details');
    v.el.innerHTML =
      '<div class="dbg"></div><div class="dshade"></div>' +
      '<div class="dinfo"><div class="dlogo"></div><div class="dmeta"></div><div class="dbadges"></div><div class="dover"></div>' +
      '  <div class="dmenu"></div><div class="dextra"></div></div>' +
      '<div class="dpanel deps"><div class="dtitle"></div>' +
      '  <div class="dseas"></div>' +
      '  <div class="deplist"><div class="dtrack"></div></div></div>' +
      '<div class="dpanel dsim"><h2 class="dsimt"></h2><div class="dstrip"><div class="dtrack"></div></div></div>';
    v.menu = new TVM.List([]);
    v.seasons = new TVM.List([]);
    v.eps = []; v.ei = 0; v.epZone = 'eps';
    v.sims = []; v.si = 0;
    v.paint(item);
    A.item(item.Id).then(function (full) {
      if (!v.alive) return;
      v.item = full;
      v.paint(full);
      if (full.Type === 'Series') v.loadNext();
      TVM.emit('details', v, full);
    }).catch(function () {});
  };
  var D = TVM.DetailsView.prototype;

  function badges(src) {
    var st = (src && (src.MediaStreams || (src.MediaSources && src.MediaSources[0] && src.MediaSources[0].MediaStreams))) || [], out = [];
    var vid = st.filter(function (x) { return x.Type === 'Video'; })[0], aud = st.filter(function (x) { return x.Type === 'Audio'; });
    if (vid) {
      if (vid.Width >= 3800) out.push('4K'); else if (vid.Width >= 1900) out.push('HD');
      var vr = String(vid.VideoRangeType || vid.VideoRange || '');
      if (/DOVI/i.test(vr)) out.push('Dolby Vision'); else if (/HDR/i.test(vr)) out.push('HDR');
    }
    var ch = 0, atmos = false;
    aud.forEach(function (a) { ch = Math.max(ch, a.Channels || 0); if (/atmos/i.test(a.DisplayTitle || '')) atmos = true; });
    if (atmos) out.push('Atmos'); else if (ch >= 8) out.push('7.1'); else if (ch >= 6) out.push('5.1');
    return out;
  }

  /* ---------------- 1. présentation ---------------- */
  D.paint = function (it) {
    var v = this;
    var bg = A.backdrop(it, C.backdropWidth);
    if (bg) v.el.querySelector('.dbg').style.backgroundImage = 'url("' + bg + '")';
    var logo = A.logo(it, 600);
    v.el.querySelector('.dlogo').innerHTML = logo ? '<img src="' + logo + '">' : '<h1>' + esc(it.Name) + '</h1>';
    var meta = [];
    if (it.ProductionYear) meta.push(it.ProductionYear);
    if (it.Genres && it.Genres[0]) meta.push(esc((TVM.genreFr || String)(it.Genres[0])));
    if (it.Type === 'Series' && it.ChildCount) meta.push(it.ChildCount + ' saison' + (it.ChildCount > 1 ? 's' : ''));
    else if (it.RunTimeTicks) meta.push(TVM.duration(it.RunTimeTicks));
    var bd = badges(it.Type === 'Series' ? v.nextFull : it).map(function (b) { return '<span class="bdg">' + b + '</span>'; }).join('');
    v.el.querySelector('.dmeta').innerHTML = meta.join(' &nbsp;•&nbsp; ') + (bd ? ' &nbsp;' + bd : '');
    v.el.querySelector('.dbadges').innerHTML = (it.OfficialRating ? '<span class="rate">' + esc(it.OfficialRating) + '</span>' : '') +
      (it.CommunityRating ? ' <span class="match">&#9733; ' + it.CommunityRating.toFixed(1) + '</span>' : '');
    /* série : l'épisode à reprendre (titre + résumé), comme Netflix */
    var ov = v.el.querySelector('.dover'), ep = it.Type === 'Series' ? v.next : null;
    ov.innerHTML = ep ? '<b>' + esc(ep.Name) + '</b><br>' + esc(ep.Overview || it.Overview || '') : esc(it.Overview || '');
    var extra = [];
    if (it.People && it.People.length) {
      var actors = it.People.filter(function (p) { return p.Type === 'Actor'; }).slice(0, 4).map(function (p) { return p.Name; });
      if (actors.length) extra.push('<b>Distribution :</b> ' + esc(actors.join(', ')));
    }
    if (it.Genres && it.Genres.length) extra.push('<b>Genres :</b> ' + esc(it.Genres.slice(0, 4).map(TVM.genreFr || String).join(', ')));
    v.el.querySelector('.dextra').innerHTML = extra.join('<br>');
    v.makeMenu();
  };

  D.loadNext = function () {
    var v = this;
    A.nextUp({ SeriesId: v.item.Id, Limit: 1 }).then(function (l) {
      return l[0] || A.episodes(v.item.Id, { Limit: 1 }).then(function (e) { return e[0]; });
    }).then(function (ep) {
      if (!v.alive || !ep) return;
      v.next = ep;
      v.paint(v.item);
      v.startBg();
      return A.item(ep.Id).then(function (full) { if (!v.alive) return; v.nextFull = full; v.next = full; v.paint(v.item); });
    }).catch(function () {});
  };
  /* vidéo en fond de la fiche (l'épisode à reprendre / la bande-annonce / un passage du film) */
  D.startBg = function () {
    var v = this;
    if (v.mode !== 'info') return;
    var target = v.item.Type === 'Series' ? v.next : v.item;
    if (target) TVM.preview.start(v.el.querySelector('.dbg'), target, 2200);
  };

  D.makeMenu = function () {
    var v = this, it = v.item, ud = it.UserData || {}, wrap = v.el.querySelector('.dmenu');
    var series = it.Type === 'Series', box = it.Type === 'BoxSet';
    var resume = !series && !box && ud.PlaybackPositionTicks > 0;
    var list = [];
    var label = 'Lecture', target = series ? v.next : it, tud = (target && target.UserData) || {}, pct = 0;
    var started = !box && target && tud.PlaybackPositionTicks > 0;
    if (series && v.next) label = (started ? 'Reprendre' : 'Lecture') + ' S' + (v.next.ParentIndexNumber || 1) + ' : Ép. ' + (v.next.IndexNumber || 1);
    else if (started) label = 'Reprendre';
    if (started && target.RunTimeTicks) pct = Math.round(tud.PlaybackPositionTicks / target.RunTimeTicks * 100);
    if (!box) list.push({ i: TVM.ICON.play, t: label, p: pct, a: function () { if (series && v.next) TVM.app.push(new TVM.PlayerView(v.next)); else TVM.playItem(it); } });
    if (started) list.push({ i: TVM.ICON.restart, t: 'Reprendre depuis le début', a: function () { TVM.app.push(new TVM.PlayerView(target, { fromStart: true })); } });
    if (series) list.push({ i: TVM.ICON.episodes, t: 'Épisodes', a: function () { v.openEpisodes(); } });
    if (box) list.push({ i: TVM.ICON.collection, t: 'Dans cette collection', a: function () { v.openSimilar(true); } });
    list.push({ i: ud.IsFavorite ? TVM.ICON.check : TVM.ICON.plus, t: ud.IsFavorite ? 'Dans Ma liste' : 'Ajouter à Ma liste', a: function () { v.toggleFav(); } });
    if (!box) list.push({ i: TVM.ICON.similar, t: 'Titres similaires', a: function () { v.openSimilar(false); } });
    TVM.emit('detailButtons', list, it, v);
    wrap.innerHTML = '';
    var els = list.map(function (b) {
      var d = el('div', 'dm', '<span class="dmi">' + (b.i || b.h || '') + '</span><span class="dmt">' + esc(b.t || '') + '</span>' +
        (b.p ? '<span class="dmp"><i style="width:' + b.p + '%"></i></span>' : ''));
      if (b.h && !b.t) d.innerHTML = b.h;              /* ancien format { h, a } des extensions */
      d.__a = b.a; d.addEventListener('click', b.a); wrap.appendChild(d); return d;
    });
    var keep = v.menu.i;
    v.menu = new TVM.List(els);
    v.menu.i = Math.min(keep, els.length - 1);
    if (v.mode === 'info') v.menu.focus();
  };

  D.toggleFav = function () {
    var v = this, it = v.item, on = !(it.UserData && it.UserData.IsFavorite);
    A.setFavorite(it.Id, on).then(function () {
      it.UserData = it.UserData || {}; it.UserData.IsFavorite = on;
      TVM.toast(on ? 'Ajouté à Ma liste' : 'Retiré de Ma liste');
      v.makeMenu();
    }).catch(function () { TVM.toast('Impossible de modifier Ma liste'); });
  };

  D.setMode = function (m) {
    var v = this;
    v.mode = m;
    v.el.classList.toggle('m-eps', m === 'eps');
    v.el.classList.toggle('m-sim', m === 'sim');
    if (m === 'info') { v.seasons.blur(); v.menu.focus(); v.startBg(); }
    else { v.menu.blur(); TVM.preview.stop(); }
  };

  /* ---------------- 2. épisodes ---------------- */
  D.openEpisodes = function () {
    var v = this;
    v.setMode('eps');
    v.el.querySelector('.deps .dtitle').textContent = v.item.Name;
    if (v.seasonData) { v.paintEps(); return; }
    A.seasons(v.item.Id).then(function (seasons) {
      if (!v.alive) return;
      v.seasonData = seasons;
      var wrap = v.el.querySelector('.dseas');
      wrap.innerHTML = '';
      var els = seasons.map(function (se, i) {
        var d = el('div', 'ds', esc(se.Name || ('Saison ' + (i + 1))));
        d.addEventListener('click', function () { v.pickSeason(i); v.epZone = 'eps'; v.paintEps(); });
        wrap.appendChild(d); return d;
      });
      v.seasons = new TVM.List(els);
      var si = 0;
      if (v.next) seasons.forEach(function (se, i) { if (se.Id === v.next.SeasonId) si = i; });
      v.pickSeason(si, v.next && v.next.Id);
    }).catch(function () { TVM.toast('Épisodes indisponibles'); });
  };
  D.pickSeason = function (i, focusId) {
    var v = this;
    v.seasons.i = i;
    var tabs = v.el.querySelectorAll('.ds');
    for (var k = 0; k < tabs.length; k++) tabs[k].classList.toggle('on', k === i);
    var season = v.seasonData[i];
    if (!season) return;
    A.episodes(v.item.Id, { SeasonId: season.Id }).then(function (eps) {
      if (!v.alive || v.seasons.i !== i) return;
      v.buildStrip(v.el.querySelector('.deps .dtrack'), eps, 'ep');
      v.eps = eps;
      v.ei = 0;
      if (focusId) eps.forEach(function (e, n) { if (e.Id === focusId) v.ei = n; });
      v.paintEps();
    });
  };
  D.buildStrip = function (track, items, kind) {
    track.innerHTML = '';
    var cards = items.map(function (it, n) {
      var ud = it.UserData || {}, pct = ud.PlayedPercentage || (ud.Played ? 100 : 0);
      var d = el('div', kind === 'ep' ? 'dep' : 'dsc');
      var src = kind === 'ep' ? A.land(it, C.landWidth) : A.poster(it, C.posterWidth);
      if (kind === 'ep') {
        /* rangée d'épisode façon Netflix : image à gauche, numéro + titre + durée + résumé à droite */
        var left = ud.PlaybackPositionTicks && it.RunTimeTicks ? 'Encore ' + TVM.duration(it.RunTimeTicks - ud.PlaybackPositionTicks) : TVM.duration(it.RunTimeTicks);
        d.innerHTML = '<div class="dimg"><img data-src="' + src + '">' +
          (pct ? '<div class="prog"><i style="width:' + Math.round(pct) + '%"></i></div>' : '') + '</div>' +
          '<div class="dtx"><div class="dlab"><span class="dnum">' + (it.IndexNumber || n + 1) + '.</span> ' + esc(it.Name) + '</div>' +
          '<div class="dem">' + esc(left || '') + (ud.Played ? ' · vu' : '') + '</div><div class="deo">' + esc(it.Overview || '') + '</div></div>';
      } else d.innerHTML = '<div class="dimg"><img data-src="' + src + '"></div>';
      track.appendChild(d);
      return d;
    });
    track.__cards = cards;
    return cards;
  };
  D.lazy = function (cards, at) {
    for (var i = Math.max(0, at - 3); i < Math.min(cards.length, at + 8); i++) {
      var im = cards[i].querySelector('img[data-src]');
      if (im) { im.src = im.getAttribute('data-src'); im.removeAttribute('data-src'); }
    }
  };
  D.paintEps = function () {
    var v = this, track = v.el.querySelector('.deps .dtrack'), cards = track.__cards || [];
    for (var i = 0; i < cards.length; i++) cards[i].classList.toggle('f', v.epZone === 'eps' && i === v.ei);
    if (v.epZone === 'seasons') v.seasons.focus(); else v.seasons.blur();
    v.lazy(cards, v.ei);
    TVM.move(track, 0, -Math.max(0, v.ei - 1) * TVM.rem(17.4));      /* liste verticale, l'épisode choisi reste en 2e position */
  };

  /* ---------------- 3. titres similaires / collection ---------------- */
  D.openSimilar = function (collection) {
    var v = this;
    v.setMode('sim');
    v.el.querySelector('.dsimt').textContent = collection ? 'Dans cette collection' : 'Titres similaires';
    var p = collection ? A.items({ ParentId: v.item.Id, SortBy: 'ProductionYear,SortName', Recursive: false }) : A.similar(v.item.Id);
    p.then(function (items) {
      if (!v.alive) return;
      v.sims = items; v.si = 0;
      v.buildStrip(v.el.querySelector('.dsim .dtrack'), items, 'sim');
      if (!items.length) { TVM.toast('Aucun titre trouvé'); v.setMode('info'); return; }
      v.paintSim();
    }).catch(function () { TVM.toast('Indisponible'); v.setMode('info'); });
  };
  D.paintSim = function () {
    var v = this, track = v.el.querySelector('.dsim .dtrack'), cards = track.__cards || [];
    for (var i = 0; i < cards.length; i++) cards[i].classList.toggle('f', i === v.si);
    v.lazy(cards, v.si);
    TVM.move(track, -v.si * TVM.rem(12.6), 0);
  };

  /* ---------------- touches ---------------- */
  D.onKey = function (k) {
    var v = this;
    if (v.mode === 'info') {
      if (k === 'up' || k === 'down') { v.menu.step(k === 'up' ? -1 : 1); return true; }
      if (k === 'ok') { var b = v.menu.current(); if (b) b.__a(); return true; }
      if (k === 'play' || k === 'playpause') { var f = v.menu.items[0]; if (f) f.__a(); return true; }
      return k !== 'back';                    /* Retour : page précédente */
    }
    if (v.mode === 'sim') {
      if (k === 'left' || k === 'right') { v.si = TVM.clamp(v.si + (k === 'left' ? -1 : 1), 0, v.sims.length - 1); v.paintSim(); return true; }
      if (k === 'ok') { var s = v.sims[v.si]; if (s) TVM.app.push(new TVM.DetailsView(s)); return true; }
      if (k === 'back' || k === 'up') { v.setMode('info'); return true; }
      return true;
    }
    /* épisodes */
    if (v.epZone === 'seasons') {
      if (k === 'up' || k === 'down') { if (v.seasons.step(k === 'up' ? -1 : 1)) v.pickSeason(v.seasons.i); return true; }
      if (k === 'right' || k === 'ok') { v.epZone = 'eps'; v.paintEps(); return true; }
      if (k === 'back') { v.setMode('info'); return true; }
      return true;
    }
    if (k === 'up') { if (v.ei > 0) { v.ei--; v.paintEps(); } return true; }
    if (k === 'down') { if (v.ei < v.eps.length - 1) { v.ei++; v.paintEps(); } return true; }
    if (k === 'left') { v.epZone = 'seasons'; v.paintEps(); return true; }
    if (k === 'ok' || k === 'play' || k === 'playpause') { var ep = v.eps[v.ei]; if (ep) TVM.app.push(new TVM.PlayerView(ep)); return true; }
    if (k === 'back') { v.setMode('info'); return true; }
    return true;
  };

  D.onShow = function () {
    var v = this;
    if (v.refresh) {           /* retour du lecteur : progression à jour */
      v.refresh = false;
      A.item(v.item.Id).then(function (f) {
        if (!v.alive) return;
        v.item = f; v.makeMenu();
        if (f.Type === 'Series') {
          v.loadNext();
          if (v.seasonData) v.pickSeason(v.seasons.i, v.eps[v.ei] && v.eps[v.ei].Id);
        }
      }).catch(function () {});
    }
    if (v.mode === 'info') { v.menu.focus(); v.startBg(); }
  };
  D.onHide = function () { this.refresh = true; TVM.preview.stop(); };
  D.destroy = function () { this.alive = false; TVM.preview.stop(); };
})();
