/*
 * Jellyfin Maison (webOS) — classement des contenus par âge + contrôle parental des profils
 * (réservé aux profils administrateurs, depuis ⚙ Réglages)
 *
 * 1. « Classement des contenus par âge » : vérifie chaque film et chaque série de tes
 *    médiathèques et range tout dans les classes françaises : Tous publics, 10, 12, 16, 18 ans.
 *      • les titres qui ont déjà une classification étrangère (TV-14, PG-13, R…) sont convertis ;
 *      • ceux qui n'en ont pas reçoivent une classification proposée d'après leurs genres, leurs
 *        mots-clés et leur médiathèque (jeunesse, animé…) ;
 *      • tu peux tout vérifier et corriger un par un avant d'enregistrer ;
 *      • le classement est écrit sur le serveur Jellyfin et verrouillé (une mise à jour des
 *        métadonnées ne l'écrasera pas). Les épisodes héritent du classement de leur série.
 * 2. « Contrôle parental des profils » : pour chaque profil, l'âge maximum autorisé.
 *    Jellyfin cache alors tout ce qui est classé au-dessus, et les titres non classés.
 *    Un profil limité à 12 ans ou moins a automatiquement l'interface Jeunesse.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc;

  var CLASSES = [0, 10, 12, 16, 18];
  var NAME = { 0: 'Tous publics', 10: '10 ans et +', 12: '12 ans et +', 16: '16 ans et +', 18: '18 ans et +' };
  var CODE = { 0: 'FR-TP', 10: 'FR-10', 12: 'FR-12', 16: 'FR-16', 18: 'FR-18' };
  var MAP = { 'TV-Y': 0, 'G': 0, 'TV-G': 0, 'U': 0, 'TP': 0, 'ALL': 0, 'APPROVED': 0, 'TOUS PUBLICS': 0, 'FR-TP': 0, 'FR-U': 0,
    'TV-Y7': 10, 'TV-Y7-FV': 10, 'PG': 10, 'TV-PG': 10, 'PG-13': 12, 'TV-14': 12, 'R': 16, 'TV-MA': 16, 'NC-17': 18, 'X': 18, 'XXX': 18, 'NR': null, 'UNRATED': null };
  function toClass(n) { return n == null ? null : n <= 0 ? 0 : n <= 10 ? 10 : n <= 14 ? 12 : n <= 16 ? 16 : 18; }
  /* classification existante → classe française (null = pas de classement exploitable) */
  function current(r) {
    if (!r) return null;
    var s = String(r).toUpperCase().trim();
    if (MAP.hasOwnProperty(s)) return MAP[s];
    var m = s.match(/(\d+)/);
    return m ? toClass(+m[1]) : null;
  }
  /* proposition d'après les genres, les mots-clés et la médiathèque */
  function guess(it, libName) {
    var g = [].concat(it.Genres || []).join('|').toLowerCase(), t = [].concat(it.Tags || []).join('|').toLowerCase(), lib = String(libName || '').toLowerCase();
    var age;
    if (/adult|erot|érot|porn|sexe/.test(g + t)) return 18;
    if (/horror|horreur|épouvante|epouvante|gore|slasher/.test(g + t)) age = 16;
    else if (/jeunesse|junior|enfant|kids/.test(lib)) age = 0;
    else if (/anim/.test(lib) && !/family|famille|children|enfant|kids/.test(g)) age = 12;
    else if (/war|guerre|crime|thriller|policier|mystery|mystère/.test(g)) age = 12;
    else if (/family|famille|children|enfant|kids|jeunesse/.test(g)) age = 0;
    else if (/animation/.test(g)) age = 0;
    else if (/documentary|documentaire|music|musique|nature|reality|téléréalité|game show/.test(g)) age = 0;
    else if (/comedy|comédie|romance|adventure|aventure|fantasy|fantastique|science|drama|drame|western|history|histoire|sport/.test(g)) age = 10;
    else age = 12;
    if (/violen|sex|drug|drogue|meurtre|murder|serial killer|tueur/.test(t) && age < 16) age = 16;
    return age;
  }
  TVM.ageGuess = guess;

  /* écriture sur le serveur (même méthode que l'éditeur de métadonnées de Jellyfin) */
  function writeRating(id, age) {
    return A.item(id).then(function (full) {
      full.OfficialRating = CODE[age];
      full.LockedFields = full.LockedFields || [];
      if (full.LockedFields.indexOf('OfficialRating') < 0) full.LockedFields.push('OfficialRating');
      return A.post('/Items/' + id, full);
    });
  }

  /* ================= écran 1 : classement des contenus ================= */
  TVM.AgesView = function () {
    var v = this;
    v.el = el('div', 'view ages');
    v.el.innerHTML = '<div class="agl"><h1>Classement des contenus par âge</h1><p class="agsub">Vérification de tes films et séries…</p>' +
      '<div class="agstats"></div><div class="aglist"></div></div><div class="agr"></div>';
    v.items = [];
    v.list = new TVM.List([]);
    v.mode = 'menu';
    v.scan();
  };
  var G = TVM.AgesView.prototype;
  G.scan = function () {
    var v = this;
    A.views().then(function (views) {
      views = views.filter(function (x) { return /movies|tvshows|mixed|boxsets|^$/.test(x.CollectionType || '') && x.CollectionType !== 'boxsets'; });
      return Promise.all(views.map(function (lib) {
        return A.items({ ParentId: lib.Id, IncludeItemTypes: 'Movie,Series', Limit: 5000, Fields: 'Genres,Tags,OfficialRating,ProductionYear', EnableImageTypes: 'Primary', ImageTypeLimit: 1, EnableUserData: false })
          .then(function (l) { return l.map(function (it) { return { it: it, lib: lib.Name }; }); }).catch(function () { return []; });
      }));
    }).then(function (rs) {
      var seen = {};
      rs.forEach(function (r) { r.forEach(function (x) {
        if (seen[x.it.Id]) return; seen[x.it.Id] = 1;
        x.cur = current(x.it.OfficialRating);
        x.prop = x.cur != null ? x.cur : guess(x.it, x.lib);
        x.needs = x.cur == null || x.it.OfficialRating !== CODE[x.cur];
        v.items.push(x);
      }); });
      v.items.sort(function (a, b) { return (a.cur == null ? 0 : 1) - (b.cur == null ? 0 : 1) || String(a.it.SortName || a.it.Name).localeCompare(String(b.it.SortName || b.it.Name)); });
      v.menu();
    }).catch(function () { v.el.querySelector('.agsub').textContent = 'Impossible de lire les médiathèques.'; });
  };
  G.menu = function () {
    var v = this, none = 0, conv = 0, by = {};
    CLASSES.forEach(function (c) { by[c] = 0; });
    v.items.forEach(function (x) { if (x.cur == null) none++; else { by[x.cur]++; if (x.needs) conv++; } });
    v.el.querySelector('.agsub').textContent = v.items.length + ' films et séries vérifiés.';
    v.el.querySelector('.agstats').innerHTML = CLASSES.map(function (c) {
      return '<div class="ags"><b class="agc c' + c + '">' + (c ? c : 'TP') + '</b><span>' + NAME[c] + '</span><em>' + by[c] + '</em></div>';
    }).join('') + '<div class="ags"><b class="agc cn">?</b><span>Sans classement</span><em>' + none + '</em></div>';
    var rows = [
      { t: 'Classer automatiquement les ' + none + ' titres sans classement', a: function () { v.apply(v.items.filter(function (x) { return x.cur == null; })); } },
      { t: 'Harmoniser en classification française (' + conv + ' titres : TV-14, PG-13…)', a: function () { v.apply(v.items.filter(function (x) { return x.cur != null && x.needs; })); } },
      { t: 'Vérifier et corriger les titres un par un', a: function () { v.openList(); } },
      { t: 'Retour', a: function () { TVM.app.pop(); } }
    ];
    var box = v.el.querySelector('.aglist');
    box.innerHTML = '';
    var els = rows.map(function (r) { var d = el('div', 'agrow', esc(r.t)); d.__a = r.a; d.addEventListener('click', r.a); box.appendChild(d); return d; });
    v.mode = 'menu';
    v.list = new TVM.List(els);
    v.list.focus();
    v.el.querySelector('.agr').innerHTML = '<h3>Comment ça marche</h3><p>Les titres déjà classés gardent leur âge (converti en classification française). ' +
      'Les autres reçoivent une proposition d’après leurs genres, leurs mots-clés et leur médiathèque.</p>' +
      '<p>Ensuite, dans ⚙ Réglages → « Contrôle parental des profils », choisis l’âge maximum de chaque profil : Jellyfin cachera le reste.</p>';
  };
  G.apply = function (list) {
    var v = this;
    if (!list.length) { TVM.toast('Rien à faire'); return; }
    var n = 0, ko = 0, sub = v.el.querySelector('.agsub');
    v.mode = 'busy';
    (function step() {
      if (n >= list.length) {
        sub.textContent = 'Terminé : ' + (list.length - ko) + ' titres classés' + (ko ? ', ' + ko + ' en échec' : '') + '.';
        v.menu();
        TVM.toast('Classement enregistré sur le serveur');
        return;
      }
      var x = list[n++];
      sub.textContent = 'Enregistrement ' + n + ' / ' + list.length + ' : ' + x.it.Name;
      writeRating(x.it.Id, x.prop).then(function () { x.cur = x.prop; x.needs = false; x.it.OfficialRating = CODE[x.prop]; }, function () { ko++; }).then(step);
    })();
  };
  G.openList = function () {
    var v = this, box = v.el.querySelector('.aglist');
    v.mode = 'list';
    box.innerHTML = '<div class="agtrack"></div>';
    var track = box.firstChild;
    var els = v.items.map(function (x) {
      var d = el('div', 'agit');
      d.__x = x;
      v.paintItem(d);
      track.appendChild(d);
      return d;
    });
    v.list = new TVM.List(els, { onMove: function (i) {
      TVM.move(track, 0, -Math.max(0, i - 3) * TVM.rem(5.6));
      var x = els[i].__x, img = A.poster(x.it, 300);
      v.el.querySelector('.agr').innerHTML = (img ? '<img src="' + img + '">' : '') + '<h3>' + esc(x.it.Name) + '</h3><p>' + esc(x.lib) + ' · ' +
        esc((x.it.Genres || []).map(TVM.genreFr || String).join(', ')) + '</p><p>Classement actuel : <b>' + esc(x.it.OfficialRating || 'aucun') + '</b></p>' +
        '<p class="aghelp">← → changer l’âge · OK enregistrer · Retour revenir</p>';
    } });
    v.list.set(0);
  };
  G.paintItem = function (d) {
    var x = d.__x, c = x.prop;
    d.innerHTML = '<span class="agn">' + esc(x.it.Name) + (x.it.ProductionYear ? ' <i>(' + x.it.ProductionYear + ')</i>' : '') + '</span>' +
      '<b class="agc c' + c + '">' + (c ? c : 'TP') + '</b>' + (x.cur == null ? '<em class="agnew">proposé</em>' : x.prop !== x.cur ? '<em class="agnew">modifié</em>' : x.needs ? '<em class="agnew">à convertir</em>' : '<em class="agok">✓ enregistré</em>');
  };
  G.onKey = function (k) {
    var v = this;
    if (v.mode === 'busy') return true;
    if (v.mode === 'list') {
      var d = v.list.current();
      if (k === 'up' || k === 'down') { v.list.step(k === 'up' ? -1 : 1); return true; }
      if ((k === 'left' || k === 'right') && d) {
        var x = d.__x, i = CLASSES.indexOf(x.prop);
        x.prop = CLASSES[Math.max(0, Math.min(CLASSES.length - 1, i + (k === 'left' ? -1 : 1)))];
        v.paintItem(d); return true;
      }
      if (k === 'ok' && d) {
        var it = d.__x;
        writeRating(it.it.Id, it.prop).then(function () { it.cur = it.prop; it.needs = false; it.it.OfficialRating = CODE[it.prop]; v.paintItem(d); TVM.toast(it.it.Name + ' : ' + NAME[it.prop]); v.list.set(v.list.i); },
          function () { TVM.toast('Échec : il faut un profil administrateur'); });
        return true;
      }
      if (k === 'back') { v.menu(); return true; }
      return true;
    }
    if (k === 'up' || k === 'down') { v.list.step(k === 'up' ? -1 : 1); return true; }
    if (k === 'ok') { var c = v.list.current(); if (c) c.__a(); return true; }
    return k !== 'back';
  };

  /* ================= écran 2 : contrôle parental des profils ================= */
  var LIMITS = [0, 10, 12, 16, null];   /* ← plus strict, → plus permissif */
  TVM.ParentalView = function () {
    var v = this;
    v.el = el('div', 'view ages');
    v.el.innerHTML = '<div class="agl"><h1>Contrôle parental des profils</h1><p class="agsub">← → pour choisir l’âge maximum de chaque profil, enregistré tout de suite.</p><div class="aglist"></div></div>' +
      '<div class="agr"><h3>Ce que ça change</h3><p>Le profil ne voit plus les titres classés au-dessus de son âge, ni les titres sans classement (pense à lancer « Classement des contenus par âge »).</p>' +
      '<p>Un profil limité à 12 ans ou moins s’ouvre sur l’interface Jeunesse.</p></div>';
    v.list = new TVM.List([]);
    Promise.all([A.get('/Users'), A.get('/Localization/ParentalRatings').catch(function () { return []; })]).then(function (r) {
      v.users = r[0] || [];
      /* valeur interne de Jellyfin pour chaque âge (selon ta version du serveur) */
      v.val = {};
      (r[1] || []).forEach(function (pr) { var c = current(pr.Name); if (c != null && v.val[c] == null && /^FR-/i.test(pr.Name)) v.val[c] = pr.Value; });
      CLASSES.forEach(function (c) { if (v.val[c] == null) v.val[c] = c; });
      v.build();
    }).catch(function () { v.el.querySelector('.agsub').textContent = 'Réservé aux profils administrateurs.'; });
  };
  var PV = TVM.ParentalView.prototype;
  PV.limitOf = function (u) {
    var m = u.Policy && u.Policy.MaxParentalRating;
    if (m == null) return null;
    var best = null;
    for (var c in this.val) if (this.val.hasOwnProperty(c) && this.val[c] <= m) best = +c > (best == null ? -1 : best) ? +c : best;
    return best == null ? 0 : best;
  };
  PV.build = function () {
    var v = this, box = v.el.querySelector('.aglist');
    box.innerHTML = '';
    var els = v.users.map(function (u) {
      var d = el('div', 'agit'); d.__u = u; d.__l = v.limitOf(u); v.paint(d); box.appendChild(d); return d;
    });
    v.list = new TVM.List(els);
    v.list.focus();
  };
  PV.paint = function (d) {
    var u = d.__u, l = d.__l, adm = u.Policy && u.Policy.IsAdministrator;
    d.innerHTML = '<span class="agn">' + esc(u.Name) + (adm ? ' <i>(administrateur)</i>' : '') + '</span>' +
      '<b class="agc ' + (l == null ? 'cn' : 'c' + l) + '">' + (l == null ? '∞' : l ? l : 'TP') + '</b><em class="agok">' + (l == null ? 'aucune limite' : 'jusqu’à ' + NAME[l].toLowerCase()) + '</em>';
  };
  PV.save = function (d) {
    var v = this, u = d.__u, l = d.__l, pol = JSON.parse(JSON.stringify(u.Policy || {}));
    pol.MaxParentalRating = l == null ? null : v.val[l];
    pol.BlockUnratedItems = l == null ? [] : ['Movie', 'Series', 'Trailer', 'Other'];
    A.post('/Users/' + u.Id + '/Policy', pol).then(function () { u.Policy = pol; TVM.toast(u.Name + ' : ' + (l == null ? 'aucune limite' : NAME[l])); },
      function () { TVM.toast('Échec : il faut un profil administrateur'); });
  };
  PV.onKey = function (k) {
    var v = this, d = v.list.current();
    if (k === 'up' || k === 'down') { v.list.step(k === 'up' ? -1 : 1); return true; }
    if ((k === 'left' || k === 'right') && d) {
      var i = LIMITS.indexOf(d.__l);
      d.__l = LIMITS[Math.max(0, Math.min(LIMITS.length - 1, i + (k === 'left' ? -1 : 1)))];
      v.paint(d);
      clearTimeout(v.saveT);
      v.saveT = setTimeout(function () { v.save(d); }, 700);
      return true;
    }
    return k !== 'back';
  };
})();
