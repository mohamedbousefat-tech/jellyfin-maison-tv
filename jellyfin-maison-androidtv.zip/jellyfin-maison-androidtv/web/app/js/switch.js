/*
 * Jellyfin Maison (webOS) — ouverture d'un profil façon Netflix
 * L'icône du profil choisi s'affiche en grand au centre, avec un cercle de chargement
 * et une petite musique : joyeuse (xylophone) pour un profil Jeunesse, plus sobre pour les autres.
 * Sons originaux fabriqués pour l'appli (snd/kids.mp3, snd/profil.mp3).
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc;
  var box = null, t0 = 0, snd = null;
  function sound(kids) {
    try {
      snd = new Audio(kids ? 'snd/kids.mp3' : 'snd/profil.mp3');
      snd.volume = 0.85;
      var p = snd.play(); if (p && p.catch) p.catch(function () {});
    } catch (e) {}
  }
  TVM.profileSwitch = {
    start: function (u) {
      TVM.profileSwitch.cancel();
      var img = TVM.avatarFor ? TVM.avatarFor(u, 400) : '';
      box = el('div', '', '<div class="swav">' + (img ? '<img src="' + img + '">' : '<i>' + esc((u.Name || '?').charAt(0)) + '</i>') + '</div><div class="swspin"></div>');
      box.id = 'pswitch';
      document.body.appendChild(box);
      setTimeout(function () { if (box) box.className = 'on'; }, 20);
      t0 = Date.now();
      /* un profil déjà connu comme Jeunesse : la musique part tout de suite */
      var pref = TVM.profPrefs ? TVM.profPrefs(u.Id) : {};
      box.__played = false;
      if (pref.kids === 'on') { sound(true); box.__played = true; }
    },
    /* l'accueil est prêt : on joue le son s'il n'est pas parti, puis on s'efface (au moins 1,8 s d'animation) */
    ready: function (kids) {
      if (!box) return;
      var b = box;
      if (!b.__played) { sound(kids); b.__played = true; }
      setTimeout(function () {
        b.className = 'on out';
        setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); if (box === b) box = null; }, 500);
      }, Math.max(0, 1800 - (Date.now() - t0)));
    },
    cancel: function () {
      if (box && box.parentNode) box.parentNode.removeChild(box);
      box = null;
    }
  };
})();
