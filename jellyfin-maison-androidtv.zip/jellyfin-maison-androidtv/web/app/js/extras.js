/*
 * Jellyfin Maison — confort et contrôle parental
 *  • mode « performance » sur la LG (animations allégées)
 *  • badges sur les jaquettes : « Nouvel épisode », « Nouveau », « TOP 10 »
 *  • « Vous regardez toujours ? » après plusieurs épisodes enchaînés
 *  • minuterie de sommeil (15 min … fin de l'épisode)
 *  • code PIN par profil
 *  • temps d'écran des enfants (limite par jour + heure du coucher)
 *  • bandes-annonces dans les fiches
 *  • taille et style des sous-titres
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config, S = TVM.store;
  var MOON = '<svg viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 019.5 4a8.5 8.5 0 1010.5 10.5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>';
  var FILM = '<svg class="ico" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M7 5v14M17 5v14M3 9.5h4M3 14.5h4M17 9.5h4M17 14.5h4" stroke="currentColor" stroke-width="1.6"/></svg>';
  var keep = [];
  function luna(uri, params) {
    if (!window.PalmServiceBridge) return false;
    try { var b = new window.PalmServiceBridge(); b.onservicecallback = function () {}; b.call(uri, JSON.stringify(params)); keep.push(b); if (keep.length > 10) keep.shift(); return true; } catch (e) { return false; }
  }
  function top() { return TVM.app.top(); }
  function player() { var t = top(); return t && t.video && t.item ? t : null; }
  function today() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function nowMin() { var d = new Date(); return d.getHours() * 60 + d.getMinutes(); }
  function hm(s) { var m = /^(\d+):(\d+)$/.exec(s || ''); return m ? +m[1] * 60 + +m[2] : null; }
  function hmText(s) { var m = hm(s); return m == null ? '' : Math.floor(m / 60) + ' h ' + (m % 60 < 10 ? '0' : '') + (m % 60); }
  function durText(min) { return min >= 60 ? Math.floor(min / 60) + ' h' + (min % 60 ? ' ' + (min % 60) : '') : min + ' min'; }

  /* ================= mode performance sur la LG ================= */
  if (window.PalmSystem || /Web0S|webOS/i.test(navigator.userAgent)) document.documentElement.classList.add('lite');

  /* ================= badges sur les jaquettes ================= */
  var top10 = {}, cut = null, cutLoading = false, DAY = 864e5;
  function ts(d) { var t = d ? Date.parse(d) : 0; return isNaN(t) ? 0 : t; }
  function loadCut() {
    if (cutLoading || !A.userId) return;
    cutLoading = true;
    /* « Nouveau » seulement pour les ~40 derniers ajouts (sinon tout serait « nouveau » sur un serveur récent) */
    var two = Date.now() - 14 * DAY;
    Promise.all([
      A.items({ SortBy: 'DateCreated', SortOrder: 'Descending', Limit: 1, StartIndex: 40, IncludeItemTypes: 'Movie,Series' }).catch(function () { return []; }),
      A.items({ SortBy: 'DateCreated', SortOrder: 'Descending', Limit: 1, StartIndex: 80, IncludeItemTypes: 'Episode' }).catch(function () { return []; })
    ]).then(function (r) {
      cut = { item: Math.max(two, r[0][0] ? ts(r[0][0].DateCreated) : 0), ep: Math.max(two, r[1][0] ? ts(r[1][0].DateCreated) : 0), user: A.userId };
    }).then(function () { cutLoading = false; }, function () { cutLoading = false; });
  }
  TVM.on('card', function (d, it, def) {
    if (!it || !it.Id || !d) return;
    if (def && def.type === 'top') { top10[it.Id] = 1; return; }
    if (cut && cut.user !== A.userId) { cut = null; cutLoading = false; }
    if (!cut) loadCut();                 /* une seule requête à la fois (cutLoading) */
    var ud = it.UserData || {}, b = '';
    if (cut) {
      if (it.Type === 'Series' && ts(it.DateLastMediaAdded) > cut.ep && ts(it.DateCreated) < cut.item && ud.UnplayedItemCount > 0) b = 'Nouvel épisode';
      else if ((it.Type === 'Movie' || it.Type === 'Series') && ts(it.DateCreated) > cut.item && !ud.Played) b = 'Nouveau';
    }
    if (def && def.type !== 'land' && (top10[it.Id] || (it.SeriesId && top10[it.SeriesId]))) d.insertAdjacentHTML('beforeend', '<span class="btop"><small>TOP</small>10</span>');
    if (b && def && def.type !== 'land') d.insertAdjacentHTML('beforeend', '<span class="bnew">' + b + '</span>');
  });

  /* ================= petite liste de choix en surimpression ================= */
  function ChoiceView(title, items, sub) {
    var v = this;
    v.overlay = true;
    v.el = el('div', 'view xov');
    var box = el('div', 'xbox', '<h2>' + esc(title) + '</h2>' + (sub ? '<p>' + esc(sub) + '</p>' : ''));
    v.els = items.map(function (c) {
      var d = el('div', 'xbtn', esc(c.t)); d.__a = c.a; d.addEventListener('click', function () { c.a(); }); box.appendChild(d); return d;
    });
    v.el.appendChild(box);
    v.list = new TVM.List(v.els);
    v.list.i = items.reduce(function (a, c, i) { return c.cur ? i : a; }, 0);
  }
  ChoiceView.prototype.onShow = function () { this.list.focus(); };
  ChoiceView.prototype.onKey = function (k) {
    if (k === 'up' || k === 'down' || k === 'left' || k === 'right') { this.list.step(k === 'up' || k === 'left' ? -1 : 1); return true; }
    if (k === 'ok') { var c = this.list.current(); if (c) c.__a(); return true; }
    if (k === 'back') { if (this.onBack) this.onBack(); else TVM.app.pop(); return true; }
    return true;
  };
  TVM.ChoiceView = ChoiceView;

  /* ================= « Vous regardez toujours ? » + fin d'épisode de la minuterie ================= */
  var PP = TVM.PlayerView.prototype, origNext = PP.playNext, origQuit = PP.quit;
  PP.playNext = function () {
    var v = this;
    if (TVM.sleep && TVM.sleep.ep) { goodnight(); return; }
    TVM.autoChain = (TVM.autoChain || 0) + 1;
    if (C.stillThere && TVM.autoChain >= C.stillThere && !v.asking) {
      v.asking = true;
      try { v.video.pause(); } catch (e) {}
      clearInterval(v.countT);
      var name = v.item.SeriesName || v.item.Name;
      var cv = new ChoiceView('Vous regardez toujours « ' + name + ' » ?', [
        { t: 'Continuer à regarder', a: function () { TVM.autoChain = 0; v.asking = false; TVM.app.pop(); origNext.call(v); } },
        { t: 'Regarder plus tard', a: function () { v.asking = false; TVM.app.pop(); v.quit(); } }
      ]);
      cv.onBack = function () { v.asking = false; TVM.app.pop(); v.quit(); };
      TVM.app.push(cv);
      return;
    }
    return origNext.apply(v, arguments);
  };
  PP.quit = function () {
    var ended = this.video && this.video.ended;
    var r = origQuit.apply(this, arguments);
    if (ended && TVM.sleep && TVM.sleep.ep) goodnight();
    return r;
  };

  /* ================= minuterie de sommeil ================= */
  TVM.sleep = null;
  TVM.setSleep = function (m) {
    if (!m) { TVM.sleep = null; TVM.toast('Minuterie désactivée'); return; }
    if (m === 'ep') { TVM.sleep = { ep: true }; TVM.toast('🌙 Arrêt à la fin de l\'épisode'); return; }
    TVM.sleep = { at: Date.now() + m * 60000, min: m };
    TVM.toast('🌙 Arrêt dans ' + durText(m));
  };
  function sleepLeft() { return TVM.sleep && TVM.sleep.at ? Math.max(1, Math.round((TVM.sleep.at - Date.now()) / 60000)) : 0; }
  TVM.openSleep = function () {
    var cur = TVM.sleep, opts = [[0, 'Désactivée'], [15, '15 minutes'], [30, '30 minutes'], [45, '45 minutes'], [60, '1 heure'], [90, '1 h 30'], ['ep', 'Fin de l\'épisode']];
    TVM.app.push(new ChoiceView('Minuterie de sommeil', opts.map(function (o) {
      return { t: o[1], cur: cur ? (o[0] === 'ep' ? cur.ep : o[0] === cur.min) : o[0] === 0, a: function () { TVM.app.pop(); TVM.setSleep(o[0]); var p = player(); if (p) p.buttons(); } };
    }), cur ? (cur.ep ? 'Arrêt prévu à la fin de l\'épisode' : 'Arrêt dans ' + durText(sleepLeft())) : 'L\'appli s\'arrête toute seule et la télé peut se mettre en veille.'));
  };
  TVM.on('playerButtons', function (list) {
    list.push({ h: MOON, l: TVM.sleep ? (TVM.sleep.ep ? 'Fin d\'épisode' : sleepLeft() + ' min') : 'Minuterie', a: TVM.openSleep });
  });
  function NightView() {
    var v = this;
    v.el = el('div', 'view night', '<div class="nbox">' + MOON + '<h1>Bonne nuit</h1><p>L\'appli va se fermer dans <b>60</b> secondes.</p><small>OK pour continuer à regarder</small></div>');
    v.left = 60;
    v.t = setInterval(function () {
      v.left--; v.el.querySelector('b').textContent = v.left;
      if (v.left <= 0) { clearInterval(v.t); TVM.exit(); }
    }, 1000);
  }
  NightView.prototype.onKey = function (k) { if (k === 'ok' || k === 'back') { clearInterval(this.t); TVM.app.pop(); return true; } return true; };
  NightView.prototype.destroy = function () { clearInterval(this.t); };
  function goodnight() {
    TVM.sleep = null;
    var p = player(); if (p) { try { p.video.pause(); } catch (e) {} }
    if (!(top() instanceof NightView)) TVM.app.push(new NightView());
  }

  /* ================= code PIN ================= */
  function pkey(uid) { return 'prof.' + A.server + '|' + uid; }
  function PinView(o) {
    var v = this;
    v.o = o; v.code = ''; v.first = null;
    v.overlay = true;
    v.el = el('div', 'view xov pinv');
    var keys = '1234567890'.split('').concat(['⌫']);
    v.el.innerHTML = '<div class="xbox"><div class="pinlock">' + '<svg viewBox="0 0 24 24"><rect x="5" y="10.5" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M8 10.5V8a4 4 0 018 0v2.5" fill="none" stroke="currentColor" stroke-width="1.7"/></svg></div>' +
      '<h2></h2><div class="pdots"><i></i><i></i><i></i><i></i></div><div class="pkeys"></div><p class="pmsg">Chiffres de la télécommande ou ← → puis OK</p></div>';
    v.h = v.el.querySelector('h2'); v.h.textContent = o.title || 'Code PIN';
    var wrap = v.el.querySelector('.pkeys');
    v.list = new TVM.List(keys.map(function (k) {
      var d = el('div', 'pk', k); d.__k = k; d.addEventListener('click', function () { v.press(k); }); wrap.appendChild(d); return d;
    }));
    v.kd = function (e) {
      if (TVM.app.top() !== v) return;
      var c = e.keyCode, n = c >= 48 && c <= 57 ? c - 48 : c >= 96 && c <= 105 ? c - 96 : -1;
      if (n >= 0) { v.press(String(n)); e.preventDefault(); }
      else if (c === 8) { v.press('⌫'); e.preventDefault(); }
    };
    document.addEventListener('keydown', v.kd);
  }
  PinView.prototype.paint = function () {
    var dots = this.el.querySelectorAll('.pdots i'), n = this.code.length;
    for (var i = 0; i < dots.length; i++) dots[i].className = i < n ? 'on' : '';
  };
  PinView.prototype.press = function (k) {
    var v = this;
    if (k === '⌫') v.code = v.code.slice(0, -1);
    else if (v.code.length < 4) v.code += k;
    v.paint();
    if (v.code.length < 4) return;
    var code = v.code;
    setTimeout(function () {
      if (v.o.check != null) {
        if (code === String(v.o.check)) { TVM.app.pop(); v.o.done(code); }
        else v.wrong('Code incorrect');
      } else if (v.o.confirm && v.first == null) {
        v.first = code; v.code = ''; v.paint(); v.h.textContent = 'Confirme le code';
      } else if (v.o.confirm && code !== v.first) {
        v.first = null; v.wrong('Les deux codes sont différents'); v.h.textContent = v.o.title;
      } else { TVM.app.pop(); v.o.done(code); }
    }, 180);
  };
  PinView.prototype.wrong = function (m) {
    var v = this, b = v.el.querySelector('.xbox');
    v.code = ''; v.paint();
    v.el.querySelector('.pmsg').textContent = m;
    b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake');
  };
  PinView.prototype.onShow = function () { this.list.focus(); };
  PinView.prototype.onKey = function (k) {
    if (k === 'left' || k === 'right') { this.list.step(k === 'left' ? -1 : 1); return true; }
    if (k === 'ok') { var c = this.list.current(); if (c) this.press(c.__k); return true; }
    if (k === 'back') { TVM.app.pop(); if (this.o.cancel) this.o.cancel(); return true; }
    return true;
  };
  PinView.prototype.destroy = function () { document.removeEventListener('keydown', this.kd); };
  TVM.PinView = PinView;
  /* renvoie true si un code est demandé (ok() sera appelé une fois le bon code tapé) */
  TVM.askPin = function (u, ok) {
    if (!u || !u.Id || u.Id === A.userId) return false;
    var pin = (S.get(pkey(u.Id), {}) || {}).pin;
    if (!pin) return false;
    if (TVM.profileSwitch) try { TVM.profileSwitch.cancel(); } catch (e) {}
    TVM.app.push(new PinView({ title: 'Code PIN de ' + (u.Name || 'ce profil'), check: pin, done: ok }));
    return true;
  };

  /* ================= temps d'écran des enfants ================= */
  /* réglé par un administrateur ; enregistré sur le serveur Jellyfin (préférences du profil) → valable sur toutes les télés */
  var DP = 'jellyfinmaison';
  function lkey(uid) { return 'limits.' + A.server + '|' + uid; }
  function readLimits(uid) {
    return A.get('/DisplayPreferences/' + DP, { userId: uid, client: DP }).then(function (r) {
      var c = (r && r.CustomPrefs) || {};
      if (c.daily == null && c.bed == null) return S.get(lkey(uid), null);      /* rien sur le serveur : on garde le réglage de cette télé */
      var l = { daily: +c.daily || 0, bed: c.bed || '' };
      S.set(lkey(uid), l); return l;
    }, function () { return S.get(lkey(uid), null); });
  }
  function writeLimits(uid, l) {
    S.set(lkey(uid), l);
    return A.get('/DisplayPreferences/' + DP, { userId: uid, client: DP }).catch(function () { return {}; }).then(function (r) {
      r = r || {};
      var body = { Id: DP, Client: DP, SortBy: r.SortBy || 'SortName', SortOrder: r.SortOrder || 'Ascending', RememberIndexing: false, RememberSorting: false,
        ScrollDirection: 'Horizontal', ShowBackdrop: true, ShowSidebar: false, PrimaryImageHeight: 0, PrimaryImageWidth: 0, IndexBy: r.IndexBy || null,
        ViewType: r.ViewType || '', CustomPrefs: r.CustomPrefs || {} };
      body.CustomPrefs.daily = String(l.daily || 0); body.CustomPrefs.bed = l.bed || '';
      return A.post('/DisplayPreferences/' + DP, body, { userId: uid, client: DP });
    });
  }
  var lim = null, limFor = null, limAt = 0, lastTick = 0, warned = {};
  function usageKey() { return 'usage.' + A.server + '|' + A.userId; }
  function used() { var u = S.get(usageKey(), null); return u && u.d === today() ? u.s : 0; }
  function addUsage(sec) { S.set(usageKey(), { d: today(), s: used() + sec }); }
  function blockedReason() {
    if (!lim) return '';
    if (lim.daily && used() >= lim.daily * 60) return 'time';
    var b = hm(lim.bed), n = nowMin();
    if (b != null && (n >= b || n < 7 * 60)) return 'bed';
    return '';
  }
  function BedView(reason) {
    var v = this;
    v.el = el('div', 'view night bed', '<div class="nbox">' + MOON + '<h1>' + (reason === 'bed' ? 'C\'est l\'heure de dormir' : 'C\'est fini pour aujourd\'hui') + '</h1>' +
      '<p>' + (reason === 'bed' ? 'On se retrouve demain matin !' : 'Ton temps d\'écran de la journée est terminé. À demain !') + '</p>' +
      '<div class="xbtn f">Changer de profil</div></div>');
    v.el.querySelector('.xbtn').addEventListener('click', function () { TVM.app.reset(new TVM.ProfilesView()); });
  }
  BedView.prototype.onKey = function (k) { if (k === 'ok') TVM.app.reset(new TVM.ProfilesView()); return true; };
  function tick() {
    var uid = A.userId, now = Date.now();
    /* minuterie de sommeil */
    if (TVM.sleep && TVM.sleep.at && now >= TVM.sleep.at) goodnight();
    if (!uid) { lastTick = now; return; }
    lim = S.get(lkey(uid), null);
    if (limFor !== uid || now - limAt > 5 * 60000) { limFor = uid; limAt = now; readLimits(uid).then(function (l) { if (limFor === uid && l) lim = l; }); }
    if (!lim || (!lim.daily && !lim.bed)) { lastTick = now; return; }
    var p = player();
    if (p && !p.video.paused && lastTick) addUsage(Math.min(15, (now - lastTick) / 1000));
    lastTick = now;
    var r = blockedReason(), t = top();
    if (r) {
      if (t instanceof BedView || t instanceof PinView || (t && /profiles|login/.test(t.el.className))) return;
      if (p) { try { p.video.pause(); p.report('progress'); } catch (e) {} }
      TVM.app.reset(new BedView(r));
      return;
    }
    /* prévenir 5 minutes avant */
    var left = Infinity, b = hm(lim.bed);
    if (lim.daily) left = Math.min(left, lim.daily - used() / 60);
    if (b != null) left = Math.min(left, b - nowMin() - new Date().getSeconds() / 60);
    var wk = today() + uid;
    if (left <= 5 && left > 0 && !warned[wk]) { warned[wk] = 1; TVM.toast('⏰ Encore 5 minutes d\'écran'); }
  }
  setInterval(tick, 5000);
  TVM.ScreenTimeView = function () {
    var v = this;
    v.el = el('div', 'view settings');
    var box = el('div', 'set-box', TVM.logoHtml() + '<h1>Temps d\'écran des enfants</h1>');
    v.el.appendChild(box);
    v.list = new TVM.List([]);
    var DAILY = [0, 30, 45, 60, 90, 120, 150, 180, 240], BED = ['', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00'];
    A.get('/Users').then(function (users) {
      users = (users || []).filter(function (u) { return !(u.Policy && u.Policy.IsAdministrator); });
      if (!users.length) { box.appendChild(el('p', 'note', 'Aucun profil non administrateur.')); return; }
      var items = [];
      users.forEach(function (u) {
        var l = { daily: 0, bed: '' };
        var r1 = el('div', 'set-row'), r2 = el('div', 'set-row');
        function paint() {
          r1.textContent = u.Name + ' — temps par jour : ' + (l.daily ? durText(l.daily) : 'illimité');
          r2.textContent = u.Name + ' — heure du coucher : ' + (l.bed ? hmText(l.bed) : 'aucune');
        }
        function save() { paint(); writeLimits(u.Id, l).then(function () {}, function () { TVM.toast('Enregistré sur cette télé seulement'); }); if (u.Id === A.userId) lim = l; }
        r1.__a = function () { l.daily = DAILY[(DAILY.indexOf(l.daily) + 1) % DAILY.length]; save(); };
        r2.__a = function () { l.bed = BED[(BED.indexOf(l.bed) + 1) % BED.length]; save(); };
        readLimits(u.Id).then(function (x) { if (x) { l.daily = x.daily || 0; l.bed = x.bed || ''; } paint(); });
        paint();
        [r1, r2].forEach(function (r) { r.addEventListener('click', function () { r.__a(); }); box.appendChild(r); items.push(r); });
      });
      box.appendChild(el('p', 'note', 'OK pour changer. Le temps compte quand une vidéo est en lecture ; à l\'heure du coucher (jusqu\'à 7 h) l\'appli affiche « C\'est l\'heure de dormir ». ' +
        'Pense à mettre un code PIN sur ton profil pour qu\'ils ne puissent pas passer par le tien.'));
      v.list = new TVM.List(items); v.list.focus();
    }).catch(function () { box.appendChild(el('p', 'note', 'Liste des profils indisponible (compte administrateur nécessaire).')); });
  };
  TVM.ScreenTimeView.prototype.onShow = function () { this.list.focus(); };
  TVM.ScreenTimeView.prototype.onKey = function (k) {
    if (k === 'up' || k === 'down') {
      this.list.step(k === 'up' ? -1 : 1);
      var c = this.list.current(), box = this.el.querySelector('.set-box');
      if (c && box) { box.style.transition = 'transform .2s ease-out'; box.style.transform = 'translateY(' + (-Math.max(0, c.offsetTop - this.el.offsetHeight * .55)) + 'px)'; }
      return true;
    }
    if (k === 'ok') { var c = this.list.current(); if (c) c.__a(); return true; }
    return k !== 'back';
  };

  /* ================= bandes-annonces ================= */
  TVM.playTrailer = function (it) {
    if (it.LocalTrailerCount > 0) {
      A.get('/Items/' + it.Id + '/LocalTrailers', { userId: A.userId }).then(function (l) {
        l = (l && l.Items) || l || [];
        if (l[0]) TVM.app.push(new TVM.PlayerView(l[0])); else TVM.toast('Bande-annonce introuvable');
      }).catch(function () { TVM.toast('Bande-annonce introuvable'); });
      return;
    }
    var url = ((it.RemoteTrailers || [])[0] || {}).Url || '', m = /(?:v=|youtu\.be\/|embed\/)([\w-]{11})/.exec(url);
    if (!m) { TVM.toast('Pas de bande-annonce'); return; }
    if (window.TVMNative && window.TVMNative.openUrl) { window.TVMNative.openUrl('https://www.youtube.com/watch?v=' + m[1]); return; }
    if (luna('luna://com.webos.applicationManager/launch', { id: 'youtube.leanback.v4', params: { contentTarget: 'v=' + m[1] } })) { TVM.toast('Ouverture dans YouTube…'); return; }
    TVM.toast('YouTube n\'est pas disponible');
  };
  TVM.on('detailButtons', function (list, it) {
    if (!(it.LocalTrailerCount > 0 || (it.RemoteTrailers && it.RemoteTrailers.length))) return;
    var at = 1; while (list[at] && /Reprendre depuis|Épisodes/.test(list[at].t || '')) at++;
    list.splice(at, 0, { i: FILM, t: 'Bande-annonce', a: function () { TVM.playTrailer(it); } });
  });

  /* ================= sous-titres : taille et style ================= */
  var SIZES = [['Petits', '3.4vh'], ['Moyens', '4.4vh'], ['Grands', '5.5vh'], ['Très grands', '6.8vh']];
  var STYLES = [['Blancs avec contour', '#fff', 'transparent'], ['Jaunes avec contour', '#ffe14d', 'transparent'], ['Blancs sur fond noir', '#fff', 'rgba(0,0,0,.78)']];
  C.subSize = S.get('subSize', 1); C.subStyle = S.get('subStyle', 0);
  function applySubs() {
    var st = document.getElementById('tvmcue');
    if (!st) { st = document.createElement('style'); st.id = 'tvmcue'; document.head.appendChild(st); }
    var z = SIZES[C.subSize] || SIZES[1], y = STYLES[C.subStyle] || STYLES[0];
    st.textContent = 'video::cue { font-size: ' + z[1] + '; line-height: 1.25; color: ' + y[1] + '; background-color: ' + y[2] + '; font-family: inherit;' +
      (y[2] === 'transparent' ? ' text-shadow: 0 0 .12em #000, 0 0 .12em #000, .06em .06em .1em #000;' : '') + ' }';
  }
  applySubs();
  TVM.subRows = function (refresh) {
    return [
      { t: 'Taille des sous-titres : ' + SIZES[C.subSize][0].toLowerCase(), a: function () { C.subSize = (C.subSize + 1) % SIZES.length; S.set('subSize', C.subSize); applySubs(); refresh(); } },
      { t: 'Style des sous-titres : ' + STYLES[C.subStyle][0].toLowerCase(), a: function () { C.subStyle = (C.subStyle + 1) % STYLES.length; S.set('subStyle', C.subStyle); applySubs(); refresh(); } }
    ];
  };
})();
