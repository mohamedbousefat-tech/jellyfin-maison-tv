/*
 * Jellyfin Maison (webOS) — recherche façon Netflix télé
 *  • à gauche : clavier à l'écran (lettres, chiffres, espace, effacer) et genres suggérés ;
 *  • à droite : les résultats en grille, mis à jour pendant la frappe ;
 *  • sans rien tapé : « Suggestions pour vous » (titres au hasard de ta bibliothèque).
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config;
  var KEYS = ['␣', '⌫'].concat('abcdefghijklmnopqrstuvwxyz1234567890'.split(''));
  var COLS = 6, RCOLS = 5;

  TVM.SearchView = function () {
    var v = this;
    v.el = el('div', 'view search');
    v.el.innerHTML =
      '<div class="sleft"><div class="sq"><svg class="sqi" viewBox="0 0 24 24"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg><span class="sqt"></span><span class="sqc"></span></div>' +
      '  <div class="skb"></div><div class="ssug"></div></div>' +
      '<div class="sright"><h2 class="stitle"></h2><div class="sgridw"><div class="sgrid"></div></div></div>';
    v.q = '';
    v.zone = 'kb';
    v.ki = 2;           /* sur la lettre « a » */
    v.res = []; v.ri = 0;
    v.sug = new TVM.List([]);
    v.alive = true;
    var kb = v.el.querySelector('.skb');
    v.keys = KEYS.map(function (k, i) {
      var d = el('div', 'sk' + (i < 2 ? ' wide' : ''), k === '␣' ? 'espace' : k === '⌫' ? '<svg class="ico" viewBox="0 0 24 24"><path d="M8 5h12v14H8l-6-7z M11 9l6 6M17 9l-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>' : k);
      d.addEventListener('click', function () { v.ki = i; v.press(); });
      kb.appendChild(d);
      return d;
    });
    /* genres suggérés */
    A.genres({ IncludeItemTypes: 'Movie,Series', Fields: 'ItemCounts' }).then(function (gs) {
      if (!v.alive) return;
      gs.sort(function (a, b) { return ((b.MovieCount || 0) + (b.SeriesCount || 0)) - ((a.MovieCount || 0) + (a.SeriesCount || 0)); });
      var wrap = v.el.querySelector('.ssug'), seen = {};
      var items = gs.filter(function (g) { var l = (TVM.genreFr || String)(g.Name); if (seen[l]) return false; seen[l] = 1; return true; }).slice(0, 7).map(function (g) {
        var d = el('div', 'sg', esc((TVM.genreFr || String)(g.Name)));
        d.__g = g;
        d.addEventListener('click', function () { v.genre(g); });
        wrap.appendChild(d);
        return d;
      });
      v.sug = new TVM.List(items);
    }).catch(function () {});
    v.paintQ();
    v.load();
  };
  var S = TVM.SearchView.prototype;

  S.paintQ = function () {
    this.el.querySelector('.sqt').textContent = this.q || 'Titres, genres…';
    this.el.querySelector('.sq').classList.toggle('empty', !this.q);
  };
  S.press = function () {
    var k = KEYS[this.ki];
    if (k === '⌫') this.q = this.q.slice(0, -1);
    else if (k === '␣') { if (this.q && this.q.slice(-1) !== ' ') this.q += ' '; }
    else this.q += k;
    this.paintQ();
    var v = this;
    clearTimeout(v.t);
    v.t = setTimeout(function () { v.load(); }, 350);
  };
  S.load = function () {
    var v = this, q = v.q.trim(), my = ++v.tok;
    var p = q ? A.items({ SearchTerm: q, IncludeItemTypes: 'Movie,Series,BoxSet', Limit: 60, SortBy: 'SortName' })
      : A.items({ IncludeItemTypes: 'Movie,Series', SortBy: 'Random', Limit: 30 });
    v.el.querySelector('.stitle').textContent = q ? 'Résultats pour « ' + q + ' »' : 'Suggestions pour vous';
    p.then(function (items) { if (v.alive && my === v.tok) v.show(items, q); }).catch(function () {});
  };
  S.tok = 0;
  S.genre = function (g) {
    var v = this, my = ++v.tok;
    v.el.querySelector('.stitle').textContent = (TVM.genreFr || String)(g.Name);
    A.items({ Genres: g.Name, IncludeItemTypes: 'Movie,Series', SortBy: 'Random', Limit: 60 }).then(function (items) {
      if (v.alive && my === v.tok) { v.show(items); v.setZone('res'); }
    });
  };
  S.show = function (items, q) {
    var v = this, grid = v.el.querySelector('.sgrid');
    grid.innerHTML = '';
    v.res = items; v.ri = 0;
    v.cards = items.map(function (it) {
      var src = A.poster(it, C.posterWidth), d = el('div', 'sr');
      d.innerHTML = src ? '<img data-src="' + src + '">' : '<div class="noimg">' + esc(it.Name) + '</div>';
      d.addEventListener('click', function () { TVM.app.push(new TVM.DetailsView(it)); });
      grid.appendChild(d);
      return d;
    });
    if (!items.length) grid.innerHTML = '<p class="snone">Aucun titre trouvé' + (q ? ' pour « ' + esc(q) + ' »' : '') + '.</p>';
    v.paintRes();
  };
  S.paintRes = function () {
    var v = this, cards = v.cards || [];
    for (var i = 0; i < cards.length; i++) {
      cards[i].classList.toggle('f', v.zone === 'res' && i === v.ri);
      if (i < v.ri + RCOLS * 3 + RCOLS) { var im = cards[i].querySelector('img[data-src]'); if (im) { im.src = im.getAttribute('data-src'); im.removeAttribute('data-src'); } }
    }
    var row = Math.floor(v.ri / RCOLS);
    TVM.move(v.el.querySelector('.sgrid'), 0, -Math.max(0, row - 1) * TVM.rem(19.2));
  };
  S.setZone = function (z) {
    var v = this;
    v.zone = z;
    for (var i = 0; i < v.keys.length; i++) v.keys[i].classList.toggle('f', z === 'kb' && i === v.ki);
    if (z === 'sug') v.sug.focus(); else v.sug.blur();
    v.paintRes();
  };
  S.onShow = function () { this.setZone(this.zone); };
  S.destroy = function () { this.alive = false; clearTimeout(this.t); };

  /* position dans le clavier : 2 grandes touches en haut, puis des lignes de 6 */
  function kpos(i) { return i < 2 ? { r: 0, c: i * 3 } : { r: 1 + Math.floor((i - 2) / COLS), c: (i - 2) % COLS }; }
  function kidx(r, c) { if (r === 0) return c < 3 ? 0 : 1; return 2 + (r - 1) * COLS + c; }
  var KROWS = 1 + Math.ceil((KEYS.length - 2) / COLS);

  S.onKey = function (k) {
    var v = this;
    if (k === 'back') {
      if (v.zone !== 'kb') { v.setZone('kb'); return true; }
      if (v.q) { v.q = ''; v.paintQ(); v.load(); return true; }
      return false;
    }
    if (v.zone === 'kb') {
      var p = kpos(v.ki);
      if (k === 'ok') { v.press(); return true; }
      if (k === 'left') { if (p.c > 0) { v.ki = kidx(p.r, p.r === 0 ? 0 : p.c - 1); v.setZone('kb'); } return true; }
      if (k === 'right') {
        var lastC = p.r === 0 ? 3 : COLS - 1;
        if (p.c < lastC && !(p.r === 0 && v.ki === 1)) { var n = kidx(p.r, p.r === 0 ? 3 : p.c + 1); if (n < KEYS.length) { v.ki = n; v.setZone('kb'); return true; } }
        if (v.res.length) { v.ri = 0; v.setZone('res'); }
        return true;
      }
      if (k === 'up') { if (p.r > 0) { v.ki = kidx(p.r - 1, p.r - 1 === 0 ? (p.c < 3 ? 0 : 3) : p.c); v.setZone('kb'); } return true; }
      if (k === 'down') {
        if (p.r < KROWS - 1) { var d = kidx(p.r + 1, p.r === 0 ? (v.ki === 0 ? 0 : 3) : p.c); if (d < KEYS.length) { v.ki = d; v.setZone('kb'); return true; } }
        if (v.sug.items.length) { v.sug.i = 0; v.setZone('sug'); }
        return true;
      }
      return true;
    }
    if (v.zone === 'sug') {
      if (k === 'up') { if (!v.sug.step(-1)) { v.ki = kidx(KROWS - 1, 0); v.setZone('kb'); } return true; }
      if (k === 'down') { v.sug.step(1); return true; }
      if (k === 'ok') { var g = v.sug.current(); if (g) v.genre(g.__g); return true; }
      if (k === 'right') { if (v.res.length) { v.ri = 0; v.setZone('res'); } return true; }
      return true;
    }
    /* résultats */
    var col = v.ri % RCOLS;
    if (k === 'left') { if (col > 0) { v.ri--; v.paintRes(); } else v.setZone('kb'); return true; }
    if (k === 'right') { if (col < RCOLS - 1 && v.ri < v.res.length - 1) { v.ri++; v.paintRes(); } return true; }
    if (k === 'up') { if (v.ri >= RCOLS) { v.ri -= RCOLS; v.paintRes(); } return true; }
    if (k === 'down') { if (v.ri + RCOLS < v.res.length) { v.ri += RCOLS; v.paintRes(); } else if (Math.floor(v.ri / RCOLS) < Math.floor((v.res.length - 1) / RCOLS)) { v.ri = v.res.length - 1; v.paintRes(); } return true; }
    if (k === 'ok') { var it = v.res[v.ri]; if (it) TVM.app.push(new TVM.DetailsView(it)); return true; }
    return true;
  };
})();
