/*
 * Jellyfin Maison (webOS) — lecteur façon Netflix
 *  • lecture directe quand la télé sait lire le fichier (le plus fluide, zéro charge serveur),
 *    sinon conversion HLS par le serveur ; en cas d'échec de la lecture directe, bascule auto ;
 *  • audio français choisi par défaut ;
 *  • OK = pause, ← → = -10 s / +10 s (appuis cumulés, un seul saut), ↑ ↓ = commandes ;
 *  • Retour = quitter et revenir à la page d'avant la vidéo ;
 *  • position enregistrée sur le serveur (reprise au bon endroit sur tous les appareils).
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config;

  /* Ce que sait lire la LG C9 (webOS 4) sans conversion */
  function profile() {
    if (TVM.android) return androidProfile();
    var AC = 'aac,mp3,ac3,eac3,flac,opus,mp2';
    return {
      MaxStreamingBitrate: 120000000, MaxStaticBitrate: 120000000, MusicStreamingTranscodingBitrate: 384000,
      DirectPlayProfiles: [
        { Container: 'mp4,m4v,mov', Type: 'Video', VideoCodec: 'h264,hevc,mpeg4', AudioCodec: AC },
        { Container: 'mkv', Type: 'Video', VideoCodec: 'h264,hevc,mpeg4,vp9', AudioCodec: AC },
        { Container: 'ts,mpegts,m2ts', Type: 'Video', VideoCodec: 'h264,hevc,mpeg2video', AudioCodec: 'aac,mp3,ac3,eac3,mp2' },
        { Container: 'webm', Type: 'Video', VideoCodec: 'vp8,vp9', AudioCodec: 'vorbis,opus' }
      ],
      TranscodingProfiles: [
        { Container: 'ts', Type: 'Video', AudioCodec: 'aac,ac3,eac3,mp3', VideoCodec: 'h264,hevc', Context: 'Streaming', Protocol: 'hls',
          MaxAudioChannels: '6', MinSegments: '1', BreakOnNonKeyFrames: true }
      ],
      ContainerProfiles: [],
      CodecProfiles: [
        { Type: 'Video', Codec: 'h264', Conditions: [{ Condition: 'LessThanEqual', Property: 'VideoLevel', Value: '52', IsRequired: false }] }
      ],
      /* sous-titres texte : récupérés en WebVTT par l'appli ; sous-titres image : incrustés par le serveur */
      SubtitleProfiles: [
        { Format: 'vtt', Method: 'External' }, { Format: 'srt', Method: 'External' }, { Format: 'subrip', Method: 'External' },
        { Format: 'ass', Method: 'External' }, { Format: 'ssa', Method: 'External' },
        { Format: 'pgssub', Method: 'Encode' }, { Format: 'dvdsub', Method: 'Encode' }, { Format: 'dvbsub', Method: 'Encode' }
      ]
    };
  }
  /* Android TV / Google TV : on demande à la télé ce qu'elle sait lire */
  function androidProfile() {
    var t = document.createElement('video');
    function can(x) { try { return !!t.canPlayType(x); } catch (e) { return false; } }
    var vc = ['h264'];
    if (can('video/mp4; codecs="hvc1.1.6.L120.90"') || can('video/mp4; codecs="hev1.1.6.L120.90"')) vc.push('hevc');
    if (can('video/webm; codecs="vp9"')) vc.push('vp9');
    if (can('video/mp4; codecs="av01.0.08M.08"')) vc.push('av1');
    var ac = ['aac', 'mp3', 'opus', 'flac'];
    if (can('audio/mp4; codecs="ac-3"')) ac.push('ac3');
    if (can('audio/mp4; codecs="ec-3"')) ac.push('eac3');
    var hls = can('application/vnd.apple.mpegurl') || can('application/x-mpegURL');
    return {
      MaxStreamingBitrate: 120000000, MaxStaticBitrate: 120000000, MusicStreamingTranscodingBitrate: 384000,
      DirectPlayProfiles: [
        { Container: 'mp4,m4v,mov', Type: 'Video', VideoCodec: vc.join(','), AudioCodec: ac.join(',') },
        { Container: 'mkv,webm', Type: 'Video', VideoCodec: vc.join(','), AudioCodec: ac.join(',') }
      ],
      TranscodingProfiles: [hls
        ? { Container: 'ts', Type: 'Video', AudioCodec: 'aac,mp3', VideoCodec: 'h264' + (vc.indexOf('hevc') >= 0 ? ',hevc' : ''), Context: 'Streaming', Protocol: 'hls', MaxAudioChannels: '6', MinSegments: '1', BreakOnNonKeyFrames: true }
        : { Container: 'mp4', Type: 'Video', AudioCodec: 'aac,mp3', VideoCodec: 'h264', Context: 'Streaming', Protocol: 'http', MaxAudioChannels: '2' }],
      ContainerProfiles: [], CodecProfiles: [],
      SubtitleProfiles: [
        { Format: 'vtt', Method: 'External' }, { Format: 'srt', Method: 'External' }, { Format: 'subrip', Method: 'External' },
        { Format: 'ass', Method: 'External' }, { Format: 'ssa', Method: 'External' },
        { Format: 'pgssub', Method: 'Encode' }, { Format: 'dvdsub', Method: 'Encode' }, { Format: 'dvbsub', Method: 'Encode' }
      ]
    };
  }
  TVM.deviceProfile = profile;     /* une extension peut le remplacer */

  function isFrench(st, list) {
    var l = String(st.Language || '').toLowerCase(), t = String(st.DisplayTitle || st.Title || '').toLowerCase();
    for (var i = 0; i < list.length; i++) if (l === list[i] || t.indexOf(list[i]) === 0) return true;
    return false;
  }

  /* ---------- petits outils du lecteur ---------- */
  var LANGS = { fre: 'français', fra: 'français', fr: 'français', jpn: 'japonais', ja: 'japonais', eng: 'anglais', en: 'anglais',
    ger: 'allemand', deu: 'allemand', de: 'allemand', spa: 'espagnol', es: 'espagnol', ita: 'italien', it: 'italien',
    kor: 'coréen', ko: 'coréen', chi: 'chinois', zho: 'chinois', zh: 'chinois', por: 'portugais', pt: 'portugais',
    rus: 'russe', ru: 'russe', ara: 'arabe', ar: 'arabe', dut: 'néerlandais', nld: 'néerlandais', hin: 'hindi', tur: 'turc', pol: 'polonais' };
  function langName(s) {
    var l = String(s.Language || '').toLowerCase();
    return LANGS[l] || (s.Language ? s.Language : '') || s.DisplayTitle || ('piste ' + s.Index);
  }
  function trackLabel(s, kind) {
    var n = langName(s);
    if (kind === 'a' && !isFrench(s, C.audioLang)) n += ' [VO]';
    if (s.IsForced) n += ' (forcés)';
    if (s.Title && String(s.Title).toLowerCase() !== n.toLowerCase() && String(s.Title).length < 28 && !/^(stereo|mono|5\.1|surround)/i.test(s.Title)) n += ' – ' + s.Title;
    return n;
  }
  function t2(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    return (h ? h + ':' : '') + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }
  /* classification façon Netflix France : « CLASSÉ 13+ » */
  var RATES = { 'TV-Y': 0, 'G': 0, 'TV-G': 0, 'U': 0, 'TP': 0, 'ALL': 0, 'APPROVED': 0, 'TV-Y7': 7, 'PG': 10, 'TV-PG': 10,
    'PG-13': 13, 'TV-14': 13, 'R': 16, 'TV-MA': 16, 'NC-17': 18, 'X': 18, 'XXX': 18 };
  function rateText(r) {
    if (!r) return '';
    var s = String(r).toUpperCase().trim();
    if (!RATES.hasOwnProperty(s)) s = s.replace(/^[A-Z]{2}-(?=\d)/, '');
    var n = RATES.hasOwnProperty(s) ? RATES[s] : null;
    if (n == null) { var m = s.match(/(\d+)/); if (m) n = +m[1]; }
    if (n === 0) return 'TOUS PUBLICS';
    return n != null ? 'CLASSÉ ' + n + '+' : 'CLASSÉ ' + s;
  }
  var DESC = [[/violen/, 'violence'], [/langage|language|grossi/, 'langage'], [/nudit|nudity/, 'nudité'], [/sex/, 'sexe'],
    [/drog|drug|substance/, 'drogues'], [/peur|horr|fear|epouv|épouv/, 'peur'], [/suicid/, 'suicide'], [/tabac|smok/, 'tabac']];
  function descriptors(it) {
    var src = [].concat(it.Tags || [], it.Genres || []).join('|').toLowerCase(), out = [];
    DESC.forEach(function (d) { if (d[0].test(src) && out.indexOf(d[1]) < 0) out.push(d[1]); });
    return out.slice(0, 3).join(', ');
  }
  var SVG = {
    back: '<svg viewBox="0 0 24 24"><path d="M20 12H5M11 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    restart: '<svg viewBox="0 0 24 24"><path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M4 3.5V8h4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.2 9v6l4.8-3z" fill="currentColor"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path d="M5.5 5l10 7-10 7z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M18.5 5v14" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10.5-6.5z" fill="currentColor"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="6.5" y="5.5" width="3.6" height="13" rx=".6" fill="currentColor"/><rect x="13.9" y="5.5" width="3.6" height="13" rx=".6" fill="currentColor"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M4.5 12.5l5 5 10-11" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };
  TVM.playerIcons = SVG;

  TVM.PlayerView = function (item, opts) {
    var v = this;
    opts = opts || {};
    v.item = item;
    v.opts = opts;
    v.alive = true;
    v.el = el('div', 'view player');
    v.el.innerHTML =
      '<video preload="auto"></video>' +
      '<div class="pload"><div class="spin"></div></div>' +
      '<div class="prate"><i></i><div><b></b><span></span></div></div>' +
      '<div class="posd">' +
      '  <div class="pshade"></div>' +
      '  <div class="ptop"><div class="picons"></div><div class="pright"><div class="ptitle"></div><div class="psub"></div></div></div>' +
      '  <div class="pmid"><div class="plogo"></div><div class="pep"></div></div>' +
      '  <div class="pbottom">' +
      '    <div class="prow"><div class="ppbtn"></div><span class="pcur">00:00</span>' +
      '      <div class="pbar"><div class="pbuf"></div><div class="pfill"></div><div class="pknob"></div><div class="ptip"></div></div>' +
      '      <span class="prem">00:00</span></div>' +
      '    <div class="pchips"></div>' +
      '  </div>' +
      '</div>' +
      '<div class="pskip"></div>' +
      '<div class="ppause"><div class="ppin"><div class="pplab">Vous regardez</div><div class="pplogo"></div><div class="ppep"></div><div class="ppov"></div></div></div>' +
      '<div class="ppanel"><div class="ppin"></div></div>';
    v.video = v.el.querySelector('video');
    /* aucun aperçu ne doit rester derrière (sur webOS, la vidéo garderait sa petite taille / sa position) */
    if (TVM.preview) TVM.preview.stop();
    var old = document.querySelectorAll('video.pvid');
    for (var oi = 0; oi < old.length; oi++) if (old[oi].parentNode) old[oi].parentNode.removeChild(old[oi]);
    v.fitVideo();
    v.osd = v.el.querySelector('.posd');
    v.zone = 'none';        /* none | top | bar | chips | panel */
    v.pending = null;       /* saut en cours d'accumulation (secondes) */
    v.audioIdx = null;
    v.subIdx = null;        /* null = automatique, -1 = désactivés */
    v.retried = false;
    v.title();
    v.wire();
    v.start(opts.fromStart ? 0 : null);
  };
  var P = TVM.PlayerView.prototype;

  /* webOS place l'image vidéo d'après la position de la balise : on la fixe en pixels sur tout l'écran,
     et on la recale après le chargement (sinon l'image peut rester décalée / réduite) */
  P.fitVideo = function () {
    var vs = this.video.style;
    if (this.el.classList.contains('panel')) { vs.left = vs.top = vs.width = vs.height = ''; return; }
    vs.left = '0px'; vs.top = '0px';
    vs.width = (window.innerWidth || 1920) + 'px'; vs.height = (window.innerHeight || 1080) + 'px';
  };
  P.refit = function () {
    var v = this, vid = v.video;
    v.fitVideo();
    vid.style.display = 'none'; void vid.offsetWidth; vid.style.display = '';
  };
  P.title = function () {
    var v = this, it = v.item, ep = it.Type === 'Episode';
    var epTxt = ep ? 'S' + (it.ParentIndexNumber || 0) + ' : E' + (it.IndexNumber || 0) + ' « ' + it.Name + ' »' : '';
    v.el.querySelector('.ptitle').textContent = ep ? (it.SeriesName || '') : it.Name;
    v.el.querySelector('.psub').textContent = epTxt;
    v.el.querySelector('.pep').textContent = epTxt;
    v.el.querySelector('.ppep').textContent = epTxt;
    v.el.querySelector('.ppov').textContent = it.Overview || '';
    v.meta = { rate: rateText(it.OfficialRating), desc: descriptors(it), logo: A.logo(it, 700) };
    v.paintMeta();
    var id = it.Id;
    A.item(id).then(function (full) {
      if (!v.alive || v.item.Id !== id) return null;
      v.full = full;
      v.el.querySelector('.ppov').textContent = full.Overview || '';
      v.meta = { rate: rateText(full.OfficialRating), desc: descriptors(full), logo: A.logo(full, 700) || v.meta.logo };
      v.paintMeta();
      if (ep && full.SeriesId && (!full.OfficialRating || !v.meta.logo)) {
        return A.item(full.SeriesId).then(function (s) {
          if (!v.alive || v.item.Id !== id) return;
          if (!v.meta.rate) v.meta.rate = rateText(s.OfficialRating);
          if (!v.meta.desc) v.meta.desc = descriptors(s);
          if (!v.meta.logo) v.meta.logo = A.logo(s, 700);
          v.paintMeta();
        });
      }
    }).catch(function () {});
  };
  P.paintMeta = function () {
    var v = this, m = v.meta, it = v.item, name = it.Type === 'Episode' ? (it.SeriesName || it.Name) : it.Name;
    var logo = m.logo ? '<img src="' + m.logo + '" alt="">' : '<div class="ptxt">' + esc(name) + '</div>';
    if (v.logoSrc !== logo) {
      v.logoSrc = logo;
      v.el.querySelector('.plogo').innerHTML = logo;
      v.el.querySelector('.pplogo').innerHTML = logo;
    }
    v.el.querySelector('.prate b').textContent = m.rate;
    v.el.querySelector('.prate span').textContent = m.desc;
    v.el.classList.toggle('hasrate', !!m.rate);
    if (v.rateWant && m.rate) v.flashRate();
  };
  /* le classement s'affiche quelques secondes au lancement, comme sur Netflix */
  P.flashRate = function () {
    var v = this;
    if (!v.meta || !v.meta.rate) { v.rateWant = true; return; }
    v.rateWant = false;
    v.el.classList.add('rateon');
    clearTimeout(v.rateT);
    v.rateT = setTimeout(function () { v.el.classList.remove('rateon'); }, 7000);
  };

  /* icônes du haut : retour, recommencer, épisode suivant */
  P.buttons = function () {
    var v = this, wrap = v.el.querySelector('.picons');
    wrap.innerHTML = '';
    var list = [
      { h: SVG.back, l: 'Retour', a: function () { v.quit(); } },
      { h: SVG.restart, l: 'Recommencer', a: function () { v.seekTo(0); v.play(); } }
    ];
    if (TVM.voice) list.push({ h: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm5.3-3a5.3 5.3 0 01-10.6 0H5a7 7 0 006 6.9V21h2v-3.1a7 7 0 006-6.9h-1.7z"/></svg>', l: 'Commande vocale', a: function () { TVM.voice.start(); } });
    TVM.emit('playerButtons', list, v);
    var els = list.map(function (b) {
      var d = el('div', 'pi', b.h + '<span>' + esc(b.l || '') + '</span>');
      d.__a = b.a; d.addEventListener('click', b.a); wrap.appendChild(d); return d;
    });
    var old = v.btns && v.btns.i;
    v.btns = new TVM.List(els);
    if (old) v.btns.i = Math.min(old, els.length - 1);
    if (v.zone === 'top') v.btns.focus();
  };

  /* pastilles de langue sous la barre : « français », « japonais [VO] avec sous-titres »… */
  P.chips = function () {
    var v = this, wrap = v.el.querySelector('.pchips');
    if (!v.streams) return;
    var auds = v.streams.filter(function (s) { return s.Type === 'Audio'; });
    var subs = v.streams.filter(function (s) { return s.Type === 'Subtitle'; });
    var frSubs = subs.filter(function (s) { return isFrench(s, ['fre', 'fra', 'fr', 'french', 'français']); });
    var frSub = frSubs.filter(function (s) { return !s.IsForced; })[0] || frSubs[0];
    var combos = [], seen = {};
    function add(a, s, label) { if (seen[label] || combos.length >= 4) return; seen[label] = 1; combos.push({ a: a, s: s, l: label }); }
    var frA = auds.filter(function (s) { return isFrench(s, C.audioLang); });
    var others = auds.filter(function (s) { return !isFrench(s, C.audioLang); });
    frA.slice(0, 1).forEach(function (a) { add(a.Index, -1, langName(a)); });
    others.forEach(function (a) { add(a.Index, frSub ? frSub.Index : -1, langName(a) + ' [VO]' + (frSub ? ' avec sous-titres' : '')); });
    if (frSub) frA.slice(0, 1).forEach(function (a) { add(a.Index, frSub.Index, langName(a) + ' avec sous-titres'); });
    var cur = v.subIdx == null ? -1 : v.subIdx;
    wrap.innerHTML = '';
    var els = combos.map(function (c) {
      var on = c.a === v.audioIdx && c.s === cur;
      var d = el('div', 'chip' + (on ? ' on' : ''), (on ? SVG.check : '') + esc(c.l));
      d.__a = function () { v.setTracks(c.a, c.s); };
      return d;
    });
    var other = el('div', 'chip', 'Autre…'); other.__a = function () { v.openPanel(); }; els.push(other);
    var gear = el('div', 'chip ico', TVM.ICON.gear); gear.__a = function () { v.openPanel(); }; els.push(gear);
    /* « Épisode suivant » en bas, au bout de la ligne (comme Netflix) */
    if (v.nextEp) { var nx = el('div', 'chip nexte', SVG.next + 'Épisode suivant'); nx.__a = function () { v.playNext(); }; els.push(nx); }
    els.forEach(function (d) { d.addEventListener('click', function () { d.__a(); }); wrap.appendChild(d); });
    var old = v.chipL ? v.chipL.i : 0;
    v.chipL = new TVM.List(els);
    v.chipL.i = Math.min(old, els.length - 1);
    if (v.zone === 'chips') v.chipL.focus();
  };

  /* changement d'audio / sous-titres (rechargement seulement si nécessaire) */
  P.setTracks = function (a, s) {
    var v = this, at = v.video.currentTime, restart = false;
    if (a != null && a !== v.audioIdx) { v.audioIdx = a; restart = true; }
    var curS = v.subIdx == null ? -1 : v.subIdx;
    if (s !== curS) {
      var st = (v.streams || []).filter(function (x) { return x.Index === s; })[0];
      var wasBurn = v.burnSub != null;
      v.subIdx = s;
      if (st && !st.IsTextSubtitleStream) { v.burnSub = s; restart = true; }
      else if (wasBurn) { v.burnSub = null; restart = true; }
      else if (!restart) v.loadSubs();
    }
    if (restart) { v.stopSession(); v.start(at, true); }
    v.chips();
    v.show();
  };

  /* ---------------- démarrage d'une session de lecture ---------------- */
  P.start = function (atSec, forceTranscode) {
    var v = this, it = v.item;
    v.el.classList.add('loading');
    var startSec = atSec != null ? atSec : ((it.UserData && it.UserData.PlaybackPositionTicks) || 0) / 1e7;
    var body = {
      UserId: A.userId, DeviceProfile: TVM.deviceProfile(), MaxStreamingBitrate: 120000000,
      AutoOpenLiveStream: true, EnableDirectPlay: !forceTranscode, EnableDirectStream: true, EnableTranscoding: true, AllowVideoStreamCopy: true, AllowAudioStreamCopy: true
    };
    if (v.audioIdx != null) body.AudioStreamIndex = v.audioIdx;
    if (v.burnSub != null) body.SubtitleStreamIndex = v.burnSub;
    var pre = TVM.prefetched && TVM.prefetched.id === it.Id && Date.now() - TVM.prefetched.t < 15 * 60000 ? TVM.prefetched.p : null;
    if (pre) TVM.prefetched = null;
    var getInfo = v.info && !forceTranscode && v.audioIdx === v.infoAudio && v.burnSub === v.infoBurn ? Promise.resolve(v.info) :
      pre && !forceTranscode && v.audioIdx == null && v.burnSub == null ? pre.catch(function () { return A.post('/Items/' + it.Id + '/PlaybackInfo', body, { userId: A.userId }); }) :
      A.post('/Items/' + it.Id + '/PlaybackInfo', body, { userId: A.userId });
    return getInfo.then(function (info) {
      if (!v.alive) return;
      var ms = info.MediaSources && info.MediaSources[0];
      if (!ms) throw new Error('aucune source');
      v.info = info; v.infoAudio = v.audioIdx; v.infoBurn = v.burnSub;
      v.ms = ms;
      v.streams = ms.MediaStreams || [];
      var audios = v.streams.filter(function (s) { return s.Type === 'Audio'; });
      /* audio français par défaut */
      if (v.audioIdx == null && audios.length) {
        var fr = C.audioPref === 'vo'
          ? audios.filter(function (s) { return !isFrench(s, C.audioLang); })[0]      /* profil réglé en version originale */
          : audios.filter(function (s) { return isFrench(s, C.audioLang); })[0];
        var fileDef = (audios.filter(function (s) { return s.IsDefault; })[0] || audios[0]).Index;
        v.audioIdx = fr ? fr.Index : (ms.DefaultAudioStreamIndex != null ? ms.DefaultAudioStreamIndex : fileDef);
        if (v.audioIdx !== fileDef && ms.SupportsDirectPlay && !forceTranscode) {
          /* la piste voulue n'est pas celle du fichier par défaut : le serveur réassemble le flux (sans réencoder l'image) */
          return v.start(startSec, true);
        }
      }
      var url, method;
      if (ms.SupportsDirectPlay && !forceTranscode) {
        method = 'DirectPlay';
        url = A.server + '/Videos/' + it.Id + '/stream' + A.qs({ static: 'true', mediaSourceId: ms.Id, deviceId: A.deviceId, api_key: A.token, PlaySessionId: info.PlaySessionId, Tag: ms.ETag });
      } else if (ms.TranscodingUrl) {
        method = ms.SupportsDirectStream ? 'DirectStream' : 'Transcode';
        url = A.server + ms.TranscodingUrl;
      } else {
        method = 'DirectStream';
        url = A.server + '/Videos/' + it.Id + '/stream' + A.qs({ static: 'true', mediaSourceId: ms.Id, api_key: A.token, PlaySessionId: info.PlaySessionId });
      }
      v.method = method;
      v.session = info.PlaySessionId;
      v.startSec = startSec;
      v.video.src = url;
      v.video.load();
      v.loadSubs();
      v.chips();
      if (v.nextEp === undefined) v.findNext();
      else v.buttons();
      if (v.segFor !== it.Id) v.loadSegments();
      TVM.emit('play', v, it, method);
    }).catch(function (e) {
      console.error('[TVM] lecture', e);
      TVM.toast('Lecture impossible');
      v.el.classList.remove('loading');
    });
  };

  /* sous-titres texte en WebVTT (sans conversion de la vidéo) */
  P.loadSubs = function () {
    var v = this, vid = v.video;
    var old = vid.querySelectorAll('track'); for (var i = 0; i < old.length; i++) vid.removeChild(old[i]);
    var subs = v.streams.filter(function (s) { return s.Type === 'Subtitle'; });
    if (v.subIdx == null) {
      var want = C.subtitleLang.length ? subs.filter(function (s) { return s.IsTextSubtitleStream && isFrench(s, C.subtitleLang); })[0] : null;
      v.subIdx = want ? want.Index : -1;
    }
    var st = subs.filter(function (s) { return s.Index === v.subIdx; })[0];
    if (!st || !st.IsTextSubtitleStream) return;
    var tr = document.createElement('track');
    tr.kind = 'subtitles';
    tr.label = st.DisplayTitle || 'Sous-titres';
    tr.srclang = st.Language || 'fr';
    tr.src = A.server + '/Videos/' + v.item.Id + '/' + v.ms.Id + '/Subtitles/' + st.Index + '/0/Stream.vtt' + A.qs({ api_key: A.token });
    tr.default = true;
    vid.appendChild(tr);
    setTimeout(function () { if (vid.textTracks && vid.textTracks[0]) vid.textTracks[0].mode = 'showing'; }, 300);
  };

  P.findNext = function () {
    var v = this, it = v.item;
    v.nextEp = null;
    if (it.Type !== 'Episode' || !it.SeriesId) { v.buttons(); return; }
    A.episodes(it.SeriesId, { StartItemId: it.Id, Limit: 2 }).then(function (l) {
      if (!v.alive) return;
      v.nextEp = l[1] && l[0] && l[0].Id === it.Id ? l[1] : null;
      v.buttons();
      v.chips();
    }).catch(function () { v.buttons(); });
  };

  /* ---------------- événements vidéo ---------------- */
  P.wire = function () {
    var v = this, vid = v.video;
    v.buttons();
    v.paintPP();
    vid.addEventListener('loadedmetadata', function () {
      if (v.startSec > 5 && (!vid.duration || v.startSec < vid.duration - 10)) { try { vid.currentTime = v.startSec; } catch (e) {} }
      v.startSec = 0;
      var p = vid.play(); if (p && p.catch) p.catch(function () {});
    });
    vid.addEventListener('loadeddata', function () { v.refit(); });
    vid.addEventListener('playing', function () {
      if (!v.fitted) { v.fitted = true; setTimeout(function () { if (v.alive) v.refit(); }, 300); }
      v.el.classList.remove('loading');
      if (!v.reported) { v.reported = true; v.report('start'); }
      if (!v.rateShown) { v.rateShown = true; v.flashRate(); }
      v.hidePause();
      v.paintPP();
    });
    vid.addEventListener('play', function () { v.paintPP(); v.hidePause(); });
    vid.addEventListener('waiting', function () { v.el.classList.add('loading'); });
    vid.addEventListener('pause', function () { if (!v.alive) return; v.paintPP(); v.report('progress'); v.show(); });
    vid.addEventListener('timeupdate', function () { if (v.osdOn) v.paintBar(); v.checkSegments(); v.prefetchNext(); });
    vid.addEventListener('ended', function () { if (v.nextEp) v.playNext(); else v.quit(); });
    vid.addEventListener('error', function () {
      if (!v.alive || !vid.getAttribute('src')) return;
      /* la lecture directe a échoué : on repasse par le serveur */
      if (!v.retried && v.method === 'DirectPlay') { v.retried = true; v.stopSession(); v.start(vid.currentTime || null, true); return; }
      TVM.toast('Erreur de lecture'); v.el.classList.remove('loading');
    });
    v.tick = setInterval(function () { if (!vid.paused) v.report('progress'); }, C.progressEvery);
    /* pointeur Magic Remote */
    v.el.querySelector('.pbar').addEventListener('click', function (e) {
      var r = this.getBoundingClientRect(), d = v.dur();
      if (d) { v.seekTo((e.clientX - r.left) / r.width * d); }
    });
    v.el.querySelector('.ppbtn').addEventListener('click', function () { v.toggle(); });
    v.el.querySelector('.ppause').addEventListener('click', function () { v.play(); });
    v.el.addEventListener('mousemove', function () { if (!v.pauseOn) v.show(); });
  };

  P.dur = function () {
    var d = this.video.duration;
    if (!d || !isFinite(d)) d = (this.item.RunTimeTicks || 0) / 1e7;
    return d || 0;
  };
  P.pos = function () { return this.pending != null ? this.pending : this.video.currentTime || 0; };

  P.report = function (what) {
    var v = this, ms = v.ms;
    if (!ms || !v.session) return;
    var b = {
      ItemId: v.item.Id, MediaSourceId: ms.Id, PlaySessionId: v.session, PositionTicks: Math.floor((v.video.currentTime || 0) * 1e7),
      IsPaused: v.video.paused, CanSeek: true, PlayMethod: v.method, AudioStreamIndex: v.audioIdx, SubtitleStreamIndex: v.subIdx >= 0 ? v.subIdx : null
    };
    var path = what === 'start' ? '/Sessions/Playing' : what === 'stop' ? '/Sessions/Playing/Stopped' : '/Sessions/Playing/Progress';
    if (what === 'progress') b.EventName = 'timeupdate';
    return A.post(path, b).catch(function () {});
  };
  P.stopSession = function () {
    var v = this;
    v.report('stop');
    if (v.method !== 'DirectPlay' && v.session) A.del('/Videos/ActiveEncodings', { deviceId: A.deviceId, playSessionId: v.session }).catch(function () {});
    v.reported = false;
  };

  /* ---------------- commandes ---------------- */
  P.play = function () { var p = this.video.play(); if (p && p.catch) p.catch(function () {}); };
  P.toggle = function () {
    var vid = this.video;
    if (vid.paused) this.play(); else vid.pause();
  };
  P.paintPP = function () {
    var b = this.el.querySelector('.ppbtn');
    b.innerHTML = this.video.paused ? SVG.play : SVG.pause;
    this.el.classList.toggle('paused', !!this.video.paused);
  };
  P.seekBy = function (d, now) {
    var v = this, D = v.dur();
    v.pending = TVM.clamp(v.pos() + d, 0, D ? D - 1 : 1e9);
    v.el.classList.add('seeking');
    v.show();
    v.paintBar();
    clearTimeout(v.seekT);
    if (now) v.commitSeek(); else v.seekT = setTimeout(function () { v.commitSeek(); }, 650);
  };
  P.commitSeek = function () {
    var v = this;
    v.el.classList.remove('seeking');
    if (v.pending == null) return;
    var t = v.pending; v.pending = null;
    v.seekTo(t);
  };
  P.seekTo = function (t) {
    try { this.video.currentTime = t; } catch (e) {}
    this.paintBar();
    this.report('progress');
  };
  P.paintBar = function () {
    var v = this, d = v.dur(), p = v.pos(), pct = d ? p / d * 100 : 0;
    v.el.querySelector('.pfill').style.width = pct + '%';
    v.el.querySelector('.pknob').style.left = pct + '%';
    try { var b = v.video.buffered; if (b.length) v.el.querySelector('.pbuf').style.width = Math.min(100, b.end(b.length - 1) / d * 100) + '%'; } catch (e) {}
    v.el.querySelector('.pcur').textContent = t2(p);
    v.el.querySelector('.prem').textContent = t2(d - p);
    var tip = v.el.querySelector('.ptip');
    if (v.pending != null) {
      var th = v.trickAt(p);
      tip.innerHTML = (th ? '<div class="pth" style="width:' + th.w + 'px;height:' + th.h + 'px;background-image:url(' + th.url + ');background-position:' + th.x + 'px ' + th.y + 'px;background-size:' + th.sw + 'px ' + th.sh + 'px"></div>' : '') +
        '<span>' + t2(p) + '</span>';
    } else if (tip.innerHTML) tip.innerHTML = '';
    tip.style.left = pct + '%';
  };

  /* vignettes d'aperçu pendant l'avance rapide (si le serveur génère le « trickplay ») */
  P.trickAt = function (sec) {
    var v = this, full = v.full, tp = full && full.Trickplay;
    if (!tp) return null;
    if (!v.trick || v.trick.id !== full.Id) {
      v.trick = null;
      var key = (v.ms && tp[v.ms.Id]) ? v.ms.Id : Object.keys(tp)[0], set = tp[key];
      if (!set) return null;
      var ws = Object.keys(set).map(Number).sort(function (a, b) { return a - b; });
      var w = ws.filter(function (x) { return x >= 280; })[0] || ws[ws.length - 1];
      v.trick = { id: full.Id, src: key, w: w, inf: set[w] };
    }
    var t = v.trick, inf = t.inf;
    if (!inf || !inf.Interval) return null;
    var idx = Math.min(inf.ThumbnailCount - 1, Math.floor(sec * 1000 / inf.Interval));
    var per = inf.TileWidth * inf.TileHeight, sheet = Math.floor(idx / per), k = idx % per;
    var W = TVM.rem(22), sc = W / inf.Width;
    return {
      url: A.server + '/Videos/' + t.id + '/Trickplay/' + t.w + '/' + sheet + '.jpg' + A.qs({ MediaSourceId: t.src, api_key: A.token }),
      w: Math.round(W), h: Math.round(inf.Height * sc),
      x: -Math.round((k % inf.TileWidth) * inf.Width * sc), y: -Math.round(Math.floor(k / inf.TileWidth) * inf.Height * sc),
      sw: Math.round(inf.TileWidth * inf.Width * sc), sh: Math.round(inf.TileHeight * inf.Height * sc)
    };
  };

  /* ---------------- affichage des commandes ---------------- */
  P.show = function () {
    var v = this;
    if (v.pauseOn) return;
    v.osdOn = true;
    v.el.classList.add('osd');
    if (v.zone === 'none') v.setZone('bar', true);
    v.paintBar();
    clearTimeout(v.hideT);
    v.hideT = setTimeout(function () {
      if (v.zone === 'panel' || v.pending != null) return;
      if (!v.video.paused) v.hide();
      else if (C.pauseScreenAfter) v.showPause();
    }, v.video.paused ? (C.pauseScreenAfter || 8000) : (C.hideAfter || 4000));
  };
  P.hide = function () {
    var v = this;
    v.osdOn = false;
    v.el.classList.remove('osd');
    if (v.zone !== 'panel') v.setZone('none', true);
  };
  P.setZone = function (z, quiet) {
    var v = this;
    v.zone = z;
    v.el.classList.toggle('zbar', z === 'bar');
    v.el.querySelector('.pbar').classList.toggle('f', z === 'bar');
    if (v.btns) { if (z === 'top') v.btns.focus(); else v.btns.blur(); }
    if (v.chipL) { if (z === 'chips') v.chipL.focus(); else v.chipL.blur(); }
    if (v.skipL) { if (z === 'none' || z === 'skip') v.skipL.focus(); else v.skipL.blur(); }
    v.el.classList.toggle('zskip', z === 'skip');
    if (!quiet) v.show();
  };

  /* écran « Vous regardez » après une pause prolongée, avec le classement */
  P.showPause = function () {
    var v = this;
    if (!v.video.paused || v.zone === 'panel') return;
    v.pauseOn = true;
    v.osdOn = false;
    v.el.classList.remove('osd');
    v.setZone('none', true);
    v.el.classList.add('pausing');
  };
  P.hidePause = function () {
    if (!this.pauseOn) return;
    this.pauseOn = false;
    this.el.classList.remove('pausing');
  };

  /* ---------------- passer l'intro / générique / épisode suivant ---------------- */
  var SKIP = { Intro: 'Passer l’intro', Recap: 'Passer le récapitulatif', Preview: 'Passer l’aperçu', Commercial: 'Passer la publicité' };
  /* intro / récap / générique : segments du serveur (Jellyfin 10.10+), sinon plugin Intro Skipper,
     sinon les chapitres du fichier (« Intro », « Opening », « Générique », « Credits »…) */
  P.loadSegments = function () {
    var v = this, id = v.item.Id;
    v.segFor = id; v.segs = []; v.segSrc = ''; v.nextDismissed = false;
    function set(l, src) { if (v.segFor === id && l && l.length && !v.segs.length) { v.segs = l; v.segSrc = src; } }
    A.get('/MediaSegments/' + id).then(function (r) {
      set(((r && r.Items) || []).map(function (x) { return { type: x.Type, a: x.StartTicks / 1e7, b: x.EndTicks / 1e7 }; }), 'serveur');
    }).catch(function () {}).then(function () {
      if (v.segs.length || v.item.Type !== 'Episode') return;
      return A.get('/Episode/' + id + '/IntroSkipperSegments').then(function (r) {
        var l = [];
        if (r && r.Introduction && r.Introduction.Valid) l.push({ type: 'Intro', a: r.Introduction.IntroStart != null ? r.Introduction.IntroStart : r.Introduction.Start, b: r.Introduction.IntroEnd != null ? r.Introduction.IntroEnd : r.Introduction.End });
        if (r && r.Credits && r.Credits.Valid) l.push({ type: 'Outro', a: r.Credits.IntroStart != null ? r.Credits.IntroStart : r.Credits.Start, b: r.Credits.IntroEnd != null ? r.Credits.IntroEnd : r.Credits.End });
        set(l, 'intro skipper');
      }).catch(function () {
        return A.get('/Episode/' + id + '/IntroTimestamps').then(function (r) { if (r && r.Valid) set([{ type: 'Intro', a: r.IntroStart, b: r.IntroEnd }], 'intro skipper'); }).catch(function () {});
      });
    });
  };
  var CH = [[/r[ée]cap|r[ée]sum[ée]|previously|pr[ée]c[ée]demment/i, 'Recap'],
    [/intro|opening|^op\b|g[ée]n[ée]rique (de )?d[ée]but|d[ée]but du g[ée]n[ée]rique|title seq/i, 'Intro'],
    [/credit|cr[ée]dit|ending|^ed\b|outro|g[ée]n[ée]rique|end ?card/i, 'Outro'],
    [/preview|aper[çc]u|next ?time|prochainement/i, 'Preview']];
  P.chapterSegs = function () {
    var v = this, ch = v.full && v.full.Chapters, d = v.dur(), out = [];
    if (!ch || !ch.length || !d) return out;
    ch.forEach(function (c, i) {
      var name = String(c.Name || ''), t = null;
      for (var k = 0; k < CH.length; k++) if (CH[k][0].test(name)) { t = CH[k][1]; break; }
      if (!t) return;
      var a = c.StartPositionTicks / 1e7, b = ch[i + 1] ? ch[i + 1].StartPositionTicks / 1e7 : d;
      if (b - a > 5 && b - a < 600) out.push({ type: t, a: a, b: b });
    });
    return out;
  };
  P.checkSegments = function () {
    var v = this, p = v.video.currentTime || 0, d = v.dur(), i, seg = null, outro = null;
    if (!(v.segs && v.segs.length) && v.full && v.full.Id === v.item.Id && v.segSrc !== 'chapitres') { var cs = v.chapterSegs(); if (cs.length) { v.segs = cs; } v.segSrc = 'chapitres'; }
    var segs = v.segs || [];
    for (i = 0; i < segs.length; i++) {
      if (SKIP[segs[i].type] && p >= segs[i].a && p < segs[i].b - 1) seg = segs[i];
      if (segs[i].type === 'Outro' && !outro) outro = segs[i];
    }
    var k = '';
    if (seg) k = 'skip' + seg.a;
    else if (v.nextEp && !v.nextDismissed && d > 60 && ((outro && p >= outro.a) || (!outro && d - p <= (C.creditsFallback || 30) && d - p > 1))) k = 'next';
    else if (!v.nextEp && v.nextEp !== undefined && !v.nextDismissed && outro && p >= outro.a && d - p > 2) k = 'end';     /* dernier épisode / film : générique de fin */
    if (k === v.skipK) return;
    v.skipK = k;
    var box = v.el.querySelector('.pskip');
    clearInterval(v.countT);
    if (!k) { box.innerHTML = ''; v.el.classList.remove('skipon'); v.skipL = null; if (v.zone === 'skip') v.setZone('bar'); return; }
    var els;
    if (seg) {
      var b = el('div', 'sb f', esc(SKIP[seg.type]));
      b.__a = function () { v.seekTo(seg.b); v.skipK = null; };
      els = [b];
    } else if (k === 'end') {
      var c0 = el('div', 'sb', 'Regarder le générique');
      c0.__a = function () { v.nextDismissed = true; v.checkSegments(); };
      var q0 = el('div', 'sb w f', 'Passer le générique');
      q0.__a = function () { v.quit(); };
      els = [c0, q0];
    } else {
      var ne = v.nextEp || {};
      var c = el('div', 'sb', 'Regarder le générique');
      c.__a = function () { v.nextDismissed = true; v.checkSegments(); };
      var n = el('div', 'sb w f', '<i class="fl"></i>' + SVG.play + '<span>Épisode suivant</span>' +
        (ne.IndexNumber != null ? '<small>S' + (ne.ParentIndexNumber || 1) + ' : E' + ne.IndexNumber + (ne.Name ? ' · ' + esc(ne.Name) : '') + '</small>' : ''));
      n.__a = function () { v.playNext(); };
      els = [c, n];
      var t0 = Date.now(), total = (C.nextCountdown || 10) * 1000, fl = n.querySelector('.fl'), done = 0;
      v.countT = setInterval(function () {
        if (v.video.paused) { t0 += 250; return; }
        done = Math.min(1, (Date.now() - t0) / total);
        fl.style.width = (done * 100) + '%';
        if (done >= 1) { clearInterval(v.countT); v.playNext(); }
      }, 250);
    }
    box.innerHTML = '';
    els.forEach(function (e) { e.addEventListener('click', function () { e.__a(); }); box.appendChild(e); });
    v.skipL = new TVM.List(els);
    v.skipL.i = els.length - 1;
    v.el.classList.add('skipon');
    /* comme Netflix : le bouton prend la main, OK suffit pour passer */
    if (v.zone === 'bar' && v.pending == null && !v.video.paused) v.hide();
    if (v.zone === 'none' || v.zone === 'skip') v.skipL.focus(); else v.skipL.blur();
  };

  /* ---------------- audio et sous-titres (écran Netflix : image réduite à gauche) ---------------- */
  P.openPanel = function () {
    var v = this, pan = v.el.querySelector('.ppanel .ppin');
    var auds = v.streams.filter(function (s) { return s.Type === 'Audio'; });
    var subs = [{ Index: -1, Language: '', DisplayTitle: 'désactivés' }].concat(v.streams.filter(function (s) { return s.Type === 'Subtitle'; }));
    var curS = v.subIdx == null ? -1 : v.subIdx, items = [], first = 0;
    pan.innerHTML = '';
    function sec(title, arr, cur, kind) {
      pan.appendChild(el('h3', '', title));
      arr.forEach(function (s) {
        var on = s.Index === cur;
        var d = el('div', 'opt' + (on ? ' on' : ''), '<i>' + (on ? SVG.check : '') + '</i>' + esc(s.Index === -1 ? 'désactivés' : trackLabel(s, kind)));
        d.__s = s; d.__k = kind;
        d.addEventListener('click', function () { v.pl.set(items.indexOf(d)); v.panelKey('ok'); });
        if (on && !items.some(function (x) { return x.classList.contains('on'); })) first = items.length;
        pan.appendChild(d); items.push(d);
      });
    }
    sec('Sous-titres', subs, curS, 's');
    sec('Audio', auds, v.audioIdx, 'a');
    v.pl = new TVM.List(items, { onMove: function (i) {
      var it = items[i], H = TVM.rem(64), y = it.offsetTop + it.offsetHeight / 2;
      var off = Math.max(0, Math.min(pan.scrollHeight - H, y - H / 2));
      TVM.move(pan, 0, -off);
    } });
    v.pl.set(first);
    clearTimeout(v.hideT);
    v.osdOn = false;
    v.el.classList.remove('osd');
    v.el.classList.add('panel');
    v.fitVideo();
    v.zone = 'panel';
  };
  P.closePanel = function () {
    this.el.classList.remove('panel');
    this.refit();
    this.setZone('chips');
  };
  P.panelKey = function (k) {
    var v = this;
    if (k === 'up' || k === 'down') { v.pl.step(k === 'up' ? -1 : 1); return; }
    if (k === 'back' || k === 'left') { v.closePanel(); return; }
    if (k === 'ok') {
      var d = v.pl.current(); if (!d) return;
      var s = d.__s;
      v.el.classList.remove('panel');
      v.refit();
      v.zone = 'chips';
      if (d.__k === 'a') v.setTracks(s.Index, v.subIdx == null ? -1 : v.subIdx);
      else v.setTracks(v.audioIdx, s.Index);
      v.setZone('chips');
    }
  };

  /* ---------------- épisode suivant / quitter ---------------- */
  P.playNext = function () {
    var v = this, n = v.nextEp;
    if (!n) return;
    clearInterval(v.countT);
    v.stopSession();
    v.item = n; v.info = null; v.nextEp = undefined; v.retried = false; v.burnSub = null; v.full = null; v.trick = null;
    v.audioIdx = null;                   /* on reprend le français sur l'épisode suivant */
    v.subIdx = null;
    v.rateShown = false; v.skipK = null; v.segFor = null;
    v.el.querySelector('.pskip').innerHTML = ''; v.el.classList.remove('skipon');
    v.hidePause();
    v.title();
    v.start(0);
  };
  /* l'épisode suivant est préparé 2 min avant la fin : il démarre sans attendre */
  P.prefetchNext = function () {
    var v = this, n = v.nextEp, d = v.dur();
    if (!n || v.prefetchedFor === n.Id || !d || d - (v.video.currentTime || 0) > 120) return;
    v.prefetchedFor = n.Id;
    var body = { UserId: A.userId, DeviceProfile: TVM.deviceProfile(), MaxStreamingBitrate: 120000000, AutoOpenLiveStream: true,
      EnableDirectPlay: true, EnableDirectStream: true, EnableTranscoding: true, AllowVideoStreamCopy: true, AllowAudioStreamCopy: true };
    TVM.prefetched = { id: n.Id, t: Date.now(), p: A.post('/Items/' + n.Id + '/PlaybackInfo', body, { userId: A.userId }) };
    TVM.prefetched.p.catch(function () {});
    [A.backdrop(n, C.backdropWidth), A.logo(n, 700), A.land(n, 420)].forEach(function (u) { if (u) { var im = new Image(); im.src = u; } });
  };
  P.quit = function () {
    if (this.quitting) return;
    this.quitting = true;
    TVM.app.pop();
  };
  P.destroy = function () {
    var v = this;
    v.alive = false;
    clearInterval(v.tick); clearInterval(v.countT); clearTimeout(v.hideT); clearTimeout(v.seekT); clearTimeout(v.rateT);
    v.stopSession();
    try { v.video.pause(); v.video.removeAttribute('src'); v.video.load(); } catch (e) {}
  };

  /* ---------------- touches ----------------
     OSD caché : OK = pause, ← → = -10/+10 s, ↑ ↓ = commandes
     Commandes : ↑ icônes du haut (retour, recommencer, suivant), barre (lecture + avance), ↓ pastilles de langue */
  P.onKey = function (k) {
    var v = this;
    if (v.pauseOn) {
      v.hidePause();
      if (k === 'ok' || k === 'play' || k === 'playpause') { v.play(); return true; }
      if (k === 'back' || k === 'stop') { v.quit(); return true; }
      v.setZone('bar');
      return true;
    }
    if (k === 'play') { v.play(); v.show(); return true; }
    if (k === 'pause') { v.video.pause(); return true; }
    if (k === 'playpause') { v.toggle(); v.show(); return true; }
    if (k === 'stop') { v.quit(); return true; }
    if (k === 'ffwd' || k === 'rew') { v.seekBy(k === 'ffwd' ? 30 : -30); return true; }
    if (v.zone === 'panel') { v.panelKey(k); return true; }
    if (k === 'back') { v.quit(); return true; }        /* retour à la page d'avant la vidéo */

    /* bouton « Passer l'intro » / « Épisode suivant » quand les commandes sont cachées */
    var skipOn = !!(v.skipL && v.skipK);
    if ((v.zone === 'none' || v.zone === 'skip') && skipOn) {
      if (k === 'ok') { var s = v.skipL.current(); if (s) s.__a(); if (v.zone === 'skip') v.setZone('none', true); v.hide(); return true; }
      if ((k === 'left' || k === 'right') && v.skipL.items.length > 1) { v.skipL.step(k === 'left' ? -1 : 1); return true; }
      if (v.zone === 'skip') {
        if (k === 'down') { v.setZone('bar'); return true; }
        if (k === 'up') { v.setZone('top'); return true; }
        return true;
      }
    }
    if (v.zone === 'skip') { v.setZone('bar'); return true; }
    if (v.zone === 'none') {
      if (k === 'ok') { v.toggle(); v.setZone('bar'); return true; }
      if (k === 'left' || k === 'right') { v.seekBy(k === 'left' ? -C.seekStep : C.seekStep); return true; }
      if (k === 'up' || k === 'down') { v.setZone('bar'); return true; }
      return true;
    }
    if (v.zone === 'bar') {
      if (k === 'left' || k === 'right') { v.seekBy(k === 'left' ? -C.seekStep : C.seekStep); return true; }
      if (k === 'ok') { if (v.pending != null) { v.commitSeek(); v.play(); } else v.toggle(); v.show(); return true; }
      if (k === 'up') { v.setZone(skipOn ? 'skip' : 'top'); return true; }
      if (k === 'down') { v.setZone('chips'); return true; }
      return true;
    }
    if (v.zone === 'top') {
      if (k === 'left' || k === 'right') { v.btns.step(k === 'left' ? -1 : 1); v.show(); return true; }
      if (k === 'down') { v.setZone('bar'); return true; }
      if (k === 'ok') { var b = v.btns.current(); if (b) b.__a(); v.show(); return true; }
      return true;
    }
    if (v.zone === 'chips') {
      if (k === 'left' || k === 'right') { v.chipL.step(k === 'left' ? -1 : 1); v.show(); return true; }
      if (k === 'up') { v.setZone('bar'); return true; }
      if (k === 'ok') { var c = v.chipL.current(); if (c) c.__a(); return true; }
      return true;
    }
    return true;
  };
  P.onShow = function () {};
})();
