/*
 * Jellyfin Maison (webOS) — modification du profil, façon Netflix
 *  • icônes de profil dessinées par l'appli (visages colorés + « Jeunesse »), enregistrées
 *    sur la télé et envoyées au serveur Jellyfin (visibles aussi sur PC / téléphone) ;
 *  • réglages propres à chaque profil, gardés sur cette télé :
 *      - Profil Jeunesse : l'appli s'ouvre directement sur l'espace Jeunesse ;
 *      - Langue audio : français ou version originale ;
 *      - Sous-titres : désactivés ou français.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config, S = TVM.store;

  /* ---------------- réglages par profil ---------------- */
  function pkey(uid) { return 'prof.' + A.server + '|' + uid; }
  TVM.profPrefs = function (uid) {
    var p = S.get(pkey(uid), {}) || {};
    var kids = p.kids === true ? 'on' : (p.kids === 'on' || p.kids === 'off') ? p.kids : 'auto';
    return { kids: kids, audio: p.audio || 'fr', subs: p.subs || 'off' };
  };
  TVM.setProfPrefs = function (uid, p) { S.set(pkey(uid), p); };
  var BASE_SUBS = C.subtitleLang.slice();
  TVM.applyProfPrefs = function (uid) {
    var p = TVM.profPrefs(uid);
    C.audioPref = p.audio;                                   /* 'fr' ou 'vo' (lu par le lecteur) */
    C.subtitleLang = p.subs === 'fr' ? ['fre', 'fra', 'fr', 'french', 'français'] : BASE_SUBS.slice();
    return p;
  };

  /* ---------------- icônes de profil : personnages originaux dessinés par l'appli ----------------
     (aucune image protégée : visages, héros manga, animaux, robots, petits monstres… inventés ici) */
  var BG = ['#f5c518', '#2d6cdf', '#2a9db0', '#e50914', '#2ebd59', '#8a4dff', '#ff5fa2', '#ff8a1f', '#14b8a6', '#5b6b8a', '#ff4f5e', '#33c8ff'];
  var SKIN = ['#ffe3cc', '#f9cfa8', '#eab48a', '#c98c5f', '#9b6440', '#6e4429'];
  var HAIR = ['#1d1d2e', '#f2d14b', '#e8473d', '#3d8bff', '#8f5bff', '#2fbf71', '#ff7ac8', '#f1f1f6', '#ff9a2e', '#6b3f23'];
  var IRIS = ['#3b6fe0', '#2fa36b', '#8a4dff', '#d9452b', '#1e9bb8', '#7a4a20'];
  var ICONS = [], ROWS = [];
  function row(label, kind, n, extra) {
    var r = { label: label, keys: [] };
    for (var v = 0; v < n; v++) {
      var spec = { k: kind + v, f: kind, v: v, c: BG[(v * 5 + kind.length) % BG.length] };
      if (extra) extra(spec, v);
      ICONS.push(spec); r.keys.push(spec.k);
    }
    ROWS.push(r);
  }
  row('Classiques', 'smile', 10, function (s, v) { s.c = BG[v]; });
  ICONS.splice(4, 0, { k: 'kids', f: 'kids', v: 0, c: 'rainbow' }); ROWS[0].keys.splice(4, 0, 'kids');
  row('Héros manga', 'boy', 10);
  row('Héroïnes manga', 'girl', 10);
  row('Animaux', 'animal', 10);
  row('Robots', 'robot', 8);
  row('Petits monstres', 'monster', 8);
  row('Venus d’ailleurs', 'alien', 8);
  row('Expressions', 'expr', 10);
  var BYKEY = {};
  ICONS.forEach(function (s) { BYKEY[s.k] = s; });
  TVM.profileIcons = ICONS;

  function roundRect(g, x, y, w, h, r) {
    g.beginPath(); g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r); g.lineTo(x + w, y + h - r);
    g.quadraticCurveTo(x + w, y + h, x + w - r, y + h); g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r); g.lineTo(x, y + r);
    g.quadraticCurveTo(x, y, x + r, y); g.closePath();
  }
  function shade(hex, k) {
    var n = parseInt(hex.slice(1), 16), r = n >> 16, gg = n >> 8 & 255, b = n & 255;
    function f(v) { return Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k))); }
    return 'rgb(' + f(r) + ',' + f(gg) + ',' + f(b) + ')';
  }

  function draw(spec, size) {
    var cv = document.createElement('canvas');
    cv.width = cv.height = size;
    var g = cv.getContext('2d');
    g.scale(size / 100, size / 100);
    g.lineCap = 'round'; g.lineJoin = 'round';
    /* fond */
    if (spec.c === 'rainbow') {
      var cols = ['#ff4f5e', '#ffb020', '#ffe13d', '#4fe36a', '#33c8ff', '#8a4dff', '#ff6bc1'];
      for (var i = 0; i < cols.length; i++) { g.fillStyle = cols[i]; g.fillRect(i * 100 / cols.length, 0, 100 / cols.length + 1, 100); }
    } else {
      var gr = g.createLinearGradient(0, 0, 0, 100);
      gr.addColorStop(0, shade(spec.c, 0.08)); gr.addColorStop(1, shade(spec.c, -0.22));
      g.fillStyle = gr; g.fillRect(0, 0, 100, 100);
    }
    function fill(c) { g.fillStyle = c; g.fill(); }
    function circ(x, y, r, c) { g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); fill(c); }
    function ell(x, y, rx, ry, c, rot) { g.beginPath(); g.ellipse(x, y, rx, ry, rot || 0, 0, Math.PI * 2); fill(c); }
    function line(pts, c, w) { g.beginPath(); g.moveTo(pts[0], pts[1]); for (var i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.strokeStyle = c; g.lineWidth = w; g.stroke(); }
    function poly(pts, c) { g.beginPath(); g.moveTo(pts[0], pts[1]); for (var i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); fill(c); }
    function smile(x, y, w, d, c, lw) { g.beginPath(); g.moveTo(x - w, y); g.quadraticCurveTo(x, y + d, x + w, y); g.strokeStyle = c; g.lineWidth = lw; g.stroke(); }
    /* œil « manga » : grand iris, reflets, cils */
    function mangaEye(x, y, w, h, iris, lash, girl) {
      ell(x, y, w, h, '#fff');
      ell(x, y + h * 0.12, w * 0.78, h * 0.82, iris);
      ell(x, y + h * 0.2, w * 0.42, h * 0.45, shade(iris, -0.55));
      circ(x - w * 0.32, y - h * 0.28, w * 0.3, '#fff');
      circ(x + w * 0.3, y + h * 0.38, w * 0.14, 'rgba(255,255,255,.85)');
      g.beginPath(); g.ellipse(x, y + h * 0.15, w * 1.08, h * 1.08, 0, Math.PI * 1.08, Math.PI * 1.92); g.strokeStyle = lash; g.lineWidth = girl ? 3.2 : 2.6; g.stroke();
      if (girl) { line([x + w * 0.95, y - h * 0.55, x + w * 1.35, y - h * 0.85], lash, 2.2); }
    }
    function headShape(skin, cx) {
      cx = cx || 50;
      g.beginPath(); g.moveTo(cx - 24, 50); g.bezierCurveTo(cx - 25, 22, cx + 25, 22, cx + 24, 50);
      g.bezierCurveTo(cx + 23, 68, cx + 12, 82, cx, 85); g.bezierCurveTo(cx - 12, 82, cx - 23, 68, cx - 24, 50); fill(skin);
    }
    function body(shirt, skin) {
      ell(50, 112, 40, 26, shirt);
      g.fillStyle = skin; g.fillRect(44, 76, 12, 12);
    }
    var v = spec.v;
    switch (spec.f) {
      case 'kids':
        g.fillStyle = '#fff'; roundRect(g, 14, 38, 72, 24, 12); g.fill();
        g.fillStyle = '#e5267a'; g.font = 'bold 15px Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText('jeunesse', 50, 50.5);
        break;
      case 'smile':
        circ(33, 38, 5.5, '#fff'); circ(67, 38, 5.5, '#fff'); smile(50, 62, 22, 14, '#fff', 4.5);
        break;
      case 'expr': {
        var e = v % 5;
        if (e === 0) { circ(33, 38, 5.5, '#fff'); line([60, 39, 73, 39], '#fff', 4.5); smile(50, 62, 22, 14, '#fff', 4.5); }
        else if (e === 1) { circ(33, 37, 5.5, '#fff'); circ(67, 37, 5.5, '#fff'); g.beginPath(); g.moveTo(28, 58); g.quadraticCurveTo(50, 88, 72, 58); g.closePath(); fill('#fff'); ell(50, 70, 8, 4, '#ff6b8a'); }
        else if (e === 2) { g.fillStyle = '#111'; roundRect(g, 17, 30, 29, 15, 5); g.fill(); roundRect(g, 54, 30, 29, 15, 5); g.fill(); g.fillRect(44, 33, 12, 4); smile(50, 63, 17, 9, '#fff', 4.5); }
        else if (e === 3) { circ(33, 38, 6.5, '#fff'); circ(67, 38, 6.5, '#fff'); g.beginPath(); g.arc(50, 66, 8, 0, Math.PI * 2); g.strokeStyle = '#fff'; g.lineWidth = 4.5; g.stroke(); }
        else { line([26, 40, 38, 34, 40, 42], '#fff', 4); line([74, 40, 62, 34, 60, 42], '#fff', 4); smile(50, 60, 20, 16, '#fff', 4.5); ell(26, 56, 6, 3.5, 'rgba(255,90,140,.7)'); ell(74, 56, 6, 3.5, 'rgba(255,90,140,.7)'); }
        break;
      }
      case 'boy': {
        var skin = SKIN[v % SKIN.length], hair = HAIR[v % HAIR.length], iris = IRIS[v % IRIS.length];
        body(shade(BG[(v + 4) % BG.length], -0.15), skin);
        ell(26, 56, 4, 6, skin); ell(74, 56, 4, 6, skin);
        headShape(skin);
        /* cheveux en pointes */
        var sp = v % 3 === 0 ? 1.15 : v % 3 === 1 ? 0.85 : 1;
        poly([22, 58, 17, 40, 25, 32 - 6 * sp, 22, 16 - 4 * sp, 37, 22, 40, 6 - 6 * sp, 50, 18, 61, 4 - 6 * sp, 64, 20, 79, 14 - 4 * sp, 75, 30, 85, 38, 78, 58, 75, 45, 67, 40, 63, 49, 57, 39, 50, 47, 43, 39, 37, 49, 33, 41, 26, 47], hair);
        if (v % 3 === 1) { g.fillStyle = '#e53935'; g.fillRect(24, 36, 52, 6); g.fillStyle = '#cfd8dc'; roundRect(g, 42, 35, 16, 8, 2); g.fill(); }
        mangaEye(40, 58, 5.2, 6.8, iris, '#222', false); mangaEye(60, 58, 5.2, 6.8, iris, '#222', false);
        line([34, 49, 45, 48], shade(hair === '#f1f1f6' ? '#888888' : hair, -0.2), 2.2); line([55, 48, 66, 49], shade(hair === '#f1f1f6' ? '#888888' : hair, -0.2), 2.2);
        if (v % 2) smile(51, 73, 5, 3, '#7a3b2e', 2); else line([46, 73, 55, 72], '#7a3b2e', 2);
        if (v % 4 === 3) line([62, 66, 68, 70], 'rgba(200,60,60,.7)', 1.6);
        break;
      }
      case 'girl': {
        var skin2 = SKIN[(v + 1) % SKIN.length], hair2 = HAIR[(v + 6) % HAIR.length], iris2 = IRIS[(v + 2) % IRIS.length], st = v % 3;
        if (st === 0) { g.fillStyle = hair2; roundRect(g, 19, 30, 62, 66, 22); g.fill(); }
        if (st === 1) { ell(15, 62, 10, 24, hair2, -0.15); ell(85, 62, 10, 24, hair2, 0.15); }
        if (st === 2) { g.fillStyle = hair2; roundRect(g, 21, 30, 58, 46, 18); g.fill(); }
        body(shade(BG[(v + 7) % BG.length], -0.1), skin2);
        headShape(skin2);
        g.beginPath(); g.moveTo(23, 54); g.bezierCurveTo(20, 18, 80, 18, 77, 54);
        g.lineTo(72, 44); g.lineTo(66, 38); g.lineTo(60, 46); g.lineTo(52, 37); g.lineTo(45, 46); g.lineTo(38, 38); g.lineTo(31, 45); g.closePath(); fill(hair2);
        if (st === 1) { circ(22, 34, 5, hair2); circ(78, 34, 5, hair2); }
        if (v % 2 === 0) { var rb = '#ff3b6b'; poly([62, 26, 74, 19, 74, 33], rb); poly([62, 26, 50, 19, 50, 33], rb); circ(62, 26, 3.2, shade(rb, -0.25)); }
        mangaEye(39, 59, 6, 7.8, iris2, '#1a1a1a', true); mangaEye(61, 59, 6, 7.8, iris2, '#1a1a1a', true);
        ell(32, 69, 5, 2.6, 'rgba(255,110,140,.45)'); ell(68, 69, 5, 2.6, 'rgba(255,110,140,.45)');
        smile(50, 74, 3.5, 2.6, '#a0413a', 1.8);
        break;
      }
      case 'animal': {
        var a = v % 10, col = ['#ffb547', '#c98b5a', '#ff7f2a', '#ffffff', '#f3eef5', '#8b5a3c', '#55c26a', '#2b2f3a', '#ffd23d', '#9aa7b8'][a];
        var dark = '#222';
        if (a === 0) { poly([24, 40, 28, 14, 44, 30], col); poly([76, 40, 72, 14, 56, 30], col); poly([28, 34, 30, 21, 39, 30], '#ff9fb2'); poly([72, 34, 70, 21, 61, 30], '#ff9fb2'); }
        if (a === 1) { ell(24, 50, 9, 18, shade(col, -0.35), 0.25); ell(76, 50, 9, 18, shade(col, -0.35), -0.25); }
        if (a === 2) { poly([22, 42, 24, 12, 44, 30], col); poly([78, 42, 76, 12, 56, 30], col); poly([27, 35, 28, 20, 38, 30], '#fff4e8'); poly([73, 35, 72, 20, 62, 30], '#fff4e8'); }
        if (a === 3) { circ(28, 28, 9, dark); circ(72, 28, 9, dark); }
        if (a === 4) { ell(38, 18, 7, 20, col); ell(62, 18, 7, 20, col); ell(38, 20, 3.5, 14, '#ffb3c6'); ell(62, 20, 3.5, 14, '#ffb3c6'); }
        if (a === 5 || a === 9) { circ(28, 30, 9, col); circ(72, 30, 9, col); circ(28, 30, 4.5, shade(col, 0.3)); circ(72, 30, 4.5, shade(col, 0.3)); }
        if (a === 8) { for (var m = 0; m < 12; m++) { var an = m / 12 * Math.PI * 2; ell(50 + Math.cos(an) * 30, 54 + Math.sin(an) * 30, 9, 13, '#e08a1e', an + Math.PI / 2); } }
        if (a === 6) { circ(34, 32, 11, col); circ(66, 32, 11, col); }
        ell(50, 56, 29, 27, col);
        if (a === 7) { ell(50, 60, 22, 21, '#fff'); }
        if (a === 2) { poly([22, 56, 50, 84, 50, 60], '#fff4e8'); poly([78, 56, 50, 84, 50, 60], '#fff4e8'); }
        if (a === 3) { ell(38, 52, 8, 10, dark, 0.5); ell(62, 52, 8, 10, dark, -0.5); }
        if (a === 5 || a === 9 || a === 1) ell(50, 67, 12, 9, shade(col, 0.45));
        var ey = a === 6 ? 32 : 52;
        if (a === 6) { circ(34, ey, 6, '#fff'); circ(66, ey, 6, '#fff'); }
        circ(38 - (a === 6 ? 4 : 0), ey, a === 6 ? 3.6 : 4.2, a === 3 ? '#fff' : dark); circ(62 + (a === 6 ? 4 : 0), ey, a === 6 ? 3.6 : 4.2, a === 3 ? '#fff' : dark);
        circ(36.6, ey - 1.6, 1.4, a === 3 ? dark : '#fff'); circ(60.6, ey - 1.6, 1.4, a === 3 ? dark : '#fff');
        if (a === 7) { poly([44, 62, 56, 62, 50, 70], '#ff9d2e'); }
        else if (a === 6) smile(50, 64, 16, 10, '#1d6b33', 3);
        else { ell(50, 63, 4.2, 3, a === 4 ? '#ff7aa2' : dark); smile(50, 67, 6, 4, dark, 1.8); }
        if (a === 0) { line([30, 64, 16, 61], '#fff', 1.4); line([30, 68, 16, 70], '#fff', 1.4); line([70, 64, 84, 61], '#fff', 1.4); line([70, 68, 84, 70], '#fff', 1.4); }
        ell(34, 66, 4, 2.4, 'rgba(255,110,140,.5)'); ell(66, 66, 4, 2.4, 'rgba(255,110,140,.5)');
        break;
      }
      case 'robot': {
        var metal = ['#cfd8dc', '#b0bec5', '#ffd54f', '#90caf9', '#ef9a9a', '#a5d6a7', '#ce93d8', '#ffcc80'][v % 8], glow = ['#00e5ff', '#76ff03', '#ff4081', '#ffea00', '#ff6d00', '#e040fb', '#00e676', '#40c4ff'][v % 8];
        line([50, 28, 50, 14], '#555', 3); circ(50, 12, 4.5, glow);
        g.fillStyle = shade(metal, -0.3); roundRect(g, 16, 42, 8, 18, 3); g.fill(); roundRect(g, 76, 42, 8, 18, 3); g.fill();
        var mg2 = g.createLinearGradient(0, 28, 0, 82); mg2.addColorStop(0, shade(metal, 0.25)); mg2.addColorStop(1, shade(metal, -0.2));
        g.fillStyle = mg2; roundRect(g, 22, 28, 56, 54, v % 2 ? 10 : 18); g.fill();
        g.fillStyle = '#1b1f2a'; roundRect(g, 28, 40, 44, 18, 9); g.fill();
        if (v % 3 === 2) { g.fillStyle = glow; roundRect(g, 32, 46, 36, 6, 3); g.fill(); }
        else { circ(39, 49, 5, glow); circ(61, 49, 5, glow); circ(38, 47.5, 1.6, '#fff'); circ(60, 47.5, 1.6, '#fff'); }
        g.fillStyle = '#37474f'; roundRect(g, 36, 64, 28, 10, 3); g.fill();
        for (var t = 0; t < 4; t++) line([40 + t * 6.5, 65.5, 40 + t * 6.5, 72.5], metal, 1.6);
        circ(27, 33, 1.8, '#607d8b'); circ(73, 33, 1.8, '#607d8b'); circ(27, 77, 1.8, '#607d8b'); circ(73, 77, 1.8, '#607d8b');
        break;
      }
      case 'monster': {
        var mc = ['#7c4dff', '#00bfa5', '#ff5252', '#ffab00', '#64dd17', '#2979ff', '#f50057', '#00b8d4'][v % 8];
        if (v % 2) { poly([30, 34, 24, 12, 40, 28], '#fff3c4'); poly([70, 34, 76, 12, 60, 28], '#fff3c4'); }
        g.beginPath(); g.moveTo(20, 86); g.bezierCurveTo(14, 40, 30, 22, 50, 22); g.bezierCurveTo(70, 22, 86, 40, 80, 86);
        for (var w2 = 0; w2 < 5; w2++) g.quadraticCurveTo(74 - w2 * 12, 78, 68 - w2 * 12, 86);
        g.closePath(); fill(mc);
        for (var sp2 = 0; sp2 < 6; sp2++) circ(30 + (sp2 * 23) % 42, 68 + (sp2 % 3) * 5, 2.2, shade(mc, -0.25));
        if (v % 3 === 0) { circ(50, 48, 13, '#fff'); circ(51, 50, 7, '#222'); circ(48, 46, 2.5, '#fff'); }
        else { circ(39, 48, 8, '#fff'); circ(61, 48, 8, '#fff'); circ(40, 50, 4, '#222'); circ(60, 50, 4, '#222'); circ(38.5, 48, 1.5, '#fff'); circ(58.5, 48, 1.5, '#fff'); }
        g.beginPath(); g.moveTo(36, 64); g.quadraticCurveTo(50, 80, 64, 64); g.closePath(); fill('#3a0d2a');
        poly([42, 65, 45, 71, 48, 66], '#fff'); poly([52, 66, 55, 71, 58, 65], '#fff');
        break;
      }
      case 'alien': {
        var ac = ['#7ee081', '#9fa8ff', '#ff9ad5', '#6fe3e3', '#c3f06b', '#ffb36b', '#d1a3ff', '#8ef0b5'][v % 8];
        line([38, 30, 30, 12], shade(ac, -0.3), 2.6); line([62, 30, 70, 12], shade(ac, -0.3), 2.6); circ(30, 11, 4.5, '#ffe14d'); circ(70, 11, 4.5, '#ffe14d');
        g.beginPath(); g.moveTo(50, 24); g.bezierCurveTo(84, 24, 84, 58, 66, 76); g.quadraticCurveTo(50, 90, 34, 76); g.bezierCurveTo(16, 58, 16, 24, 50, 24); fill(ac);
        if (v % 2) { ell(38, 52, 9, 13, '#111', 0.5); ell(62, 52, 9, 13, '#111', -0.5); circ(36, 47, 2.6, '#fff'); circ(60, 47, 2.6, '#fff'); }
        else { circ(50, 50, 12, '#fff'); circ(50, 52, 7, '#111'); circ(47, 48, 2.4, '#fff'); }
        smile(50, 70, 7, 5, shade(ac, -0.5), 2.4);
        if (v % 4 === 3) { g.beginPath(); g.arc(50, 52, 40, Math.PI * 1.1, Math.PI * 1.9); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 3; g.stroke(); }
        break;
      }
    }
    return cv;
  }
  var thumbs = {};
  /* paquets d'images : img/avatars/avatars.json = { "rangees": [ { "titre": "Manga", "images": ["manga/01.jpg", …] } ] } */
  var packsP = null;
  TVM.avatarPacks = function () {
    if (packsP) return packsP;
    packsP = new Promise(function (ok) {
      try {
        var x = new XMLHttpRequest();
        x.open('GET', 'img/avatars/avatars.json', true);
        x.onload = function () {
          try {
            var j = JSON.parse(x.responseText), rows = j.rangees || j.rows || [];
            ok(rows.map(function (r) { return { label: r.titre || r.label || '', files: (r.images || r.files || []).map(function (f) { return 'img/avatars/' + f; }) }; })
              .filter(function (r) { return r.files.length; }));
          } catch (e) { ok([]); }
        };
        x.onerror = function () { ok([]); };
        x.send();
      } catch (e) { ok([]); }
    });
    return packsP;
  };
  TVM.iconUrl = function (key, size) {
    if (String(key).indexOf('f:') === 0) return key.slice(2);
    var spec = BYKEY[key]; if (!spec) return '';
    var k = key + '@' + size;
    if (!thumbs[k]) thumbs[k] = draw(spec, size).toDataURL('image/png');
    return thumbs[k];
  };
  /* image d'un profil : icône choisie sur cette télé, sinon image du serveur */
  TVM.avatarFor = function (u, w) {
    if (!u || !u.Id) return '';
    var p = S.get(pkey(u.Id), {}) || {};
    if (p.icon != null && (BYKEY[p.icon] || String(p.icon).indexOf('f:') === 0)) return TVM.iconUrl(p.icon, 160);
    return A.userImg(u, w || 240);
  };

  /* envoi de l'icône au serveur Jellyfin (pour qu'elle apparaisse aussi ailleurs) */
  function tokenFor(u) {
    var s = S.get('sessions', {})[A.server + '|' + u.Id];
    if (s) return Promise.resolve(s.token);
    if (A.userId === u.Id && A.token) return Promise.resolve(A.token);
    if (!u.HasPassword) return A.login(u.Name, '').then(function () { return A.token; });
    return Promise.reject(new Error('pas de session'));
  }
  function imageData(t) {
    if (t.g != null && String(t.g).indexOf('f:') === 0) return new Promise(function (ok, ko) {
      var im = new Image();
      im.onload = function () {
        try { var c = document.createElement('canvas'); c.width = c.height = 400; c.getContext('2d').drawImage(im, 0, 0, 400, 400); ok({ type: 'image/jpeg', b64: c.toDataURL('image/jpeg', 0.9).split(',')[1] }); } catch (e) { ko(e); }
      };
      im.onerror = ko; im.src = t.g.slice(2);
    });
    if (t.g != null) return Promise.resolve({ type: 'image/png', b64: draw(BYKEY[t.g], 400).toDataURL('image/png').split(',')[1] });
    return fetch(t.url).then(function (r) { if (!r.ok) throw new Error('image'); return r.blob(); }).then(function (b) {
      return new Promise(function (ok, ko) {
        var fr = new FileReader();
        fr.onload = function () { ok({ type: b.type || 'image/jpeg', b64: String(fr.result).split(',')[1] }); };
        fr.onerror = ko; fr.readAsDataURL(b);
      });
    });
  }
  function upload(u, t) {
    var img;
    return imageData(t).then(function (d) { img = d; return tokenFor(u); }).then(function (tok) {
      var b64 = img.b64;
      var auth = 'MediaBrowser Client="Jellyfin Maison TV", Device="' + TVM.deviceName + '", DeviceId="' + A.deviceId + '", Version="' + TVM.version + '", Token="' + tok + '"';
      function send(path) {
        return fetch(A.server + path, { method: 'POST', headers: { 'Authorization': auth, 'X-Emby-Authorization': auth, 'Content-Type': img.type }, body: b64 })
          .then(function (r) { if (!r.ok) { var e = new Error('HTTP ' + r.status); e.status = r.status; throw e; } });
      }
      return send('/UserImage' + A.qs({ userId: u.Id })).catch(function (e) {
        if (e.status === 404 || e.status === 405) return send('/Users/' + u.Id + '/Images/Primary');
        throw e;
      });
    });
  }

  /* ---------------- écran « Modification du profil » ---------------- */
  var ICO = {
    icon: '<svg viewBox="0 0 24 24"><rect x="3.5" y="3.5" width="17" height="17" rx="3" fill="none" stroke="currentColor" stroke-width="1.7"/><circle cx="9" cy="10" r="1.3" fill="currentColor"/><circle cx="15" cy="10" r="1.3" fill="currentColor"/><path d="M8 14.5q4 3 8 0" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>',
    kids: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c.8-4 3.6-6 7-6s6.2 2 7 6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    audio: '<svg viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5v14l-4.5-4.5H4z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    subs: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M6.5 14.5h4M12.5 14.5h5M6.5 11h7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    forget: '<svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg>'
  };

  TVM.ProfileEditView = function (u) {
    var v = this;
    v.u = u;
    v.p = TVM.profPrefs(u.Id);
    v.el = el('div', 'view pedit');
    v.el.innerHTML =
      '<div class="peleft"><h1>Modification du profil</h1><p>Sélectionnez ce que vous souhaitez changer.</p><div class="pelist"></div>' +
      '<div class="pebadge"></div><div class="pedone">Terminé</div></div>' +
      '<div class="peright"><div class="peav"></div><div class="pename"></div><div class="pelang"></div></div>';
    v.paint();
  };
  var E = TVM.ProfileEditView.prototype;
  E.paint = function () {
    var v = this, u = v.u, p = v.p, list = v.el.querySelector('.pelist');
    var img = TVM.avatarFor(u, 400);
    v.el.querySelector('.peav').innerHTML = img ? '<img src="' + img + '">' : '<div class="ini">' + esc((u.Name || '?').charAt(0)) + '</div>';
    v.el.querySelector('.pename').textContent = u.Name || '';
    v.el.querySelector('.pelang').textContent = (p.audio === 'vo' ? 'Version originale' : 'Français') + (p.subs === 'fr' ? ' • sous-titres français' : '');
    var kidsNow = p.kids === 'on' || (p.kids === 'auto' && u.Policy && u.Policy.MaxParentalRating != null && +u.Policy.MaxParentalRating <= 12);
    v.el.querySelector('.pebadge').innerHTML = (kidsNow
      ? '<span class="pbg k">Jeunesse</span><div>Interface Jeunesse sur ce profil.</div>'
      : '<span class="pbg">Tous les âges</span><div>Interface adulte sur ce profil.</div>') +
      '<small>Automatique : un profil dont le contrôle parental Jellyfin est à 12 ans ou moins a l\u2019interface Jeunesse.' +
      ' Les contenus visibles se règlent dans Jellyfin (Tableau de bord → Utilisateurs).</small>';
    var rows = [
      { k: 'icon', l: 'Icône', a: function () { TVM.app.push(new TVM.IconPickerView(u, function (t) { v.setIcon(t); })); } },
      { k: 'kids', l: 'Interface Jeunesse : ' + (p.kids === 'on' ? 'oui' : p.kids === 'off' ? 'non' : 'automatique (âge)'),
        a: function () { p.kids = p.kids === 'auto' ? 'on' : p.kids === 'on' ? 'off' : 'auto'; v.save(); } },
      { k: 'audio', l: 'Langue audio : ' + (p.audio === 'vo' ? 'version originale' : 'français'), a: function () { p.audio = p.audio === 'vo' ? 'fr' : 'vo'; v.save(); } },
      { k: 'subs', l: 'Sous-titres : ' + (p.subs === 'fr' ? 'français' : 'désactivés'), a: function () { p.subs = p.subs === 'fr' ? 'off' : 'fr'; v.save(); } }
    ];
    if (A.hasSession(u.Id)) rows.push({ k: 'forget', l: 'Oublier le mot de passe sur cette télé', a: function () { A.forget(u.Id); TVM.toast('Mot de passe oublié sur cette télé'); TVM.profilesDirty = true; v.paint(); } });
    var old = v.list ? v.list.i : 0;
    list.innerHTML = '';
    var items = rows.map(function (r) {
      var d = el('div', 'perow', ICO[r.k] + '<span>' + esc(r.l) + '</span>');
      d.__a = r.a; d.addEventListener('click', r.a); list.appendChild(d); return d;
    });
    var done = v.el.querySelector('.pedone');
    done.__a = function () { TVM.app.pop(); };
    if (!done.__w) { done.__w = 1; done.addEventListener('click', function () { done.__a(); }); }
    items.push(done);
    v.list = new TVM.List(items);
    v.list.set(Math.min(old, items.length - 1));
  };
  E.save = function () { TVM.setProfPrefs(this.u.Id, this.raw()); TVM.profilesDirty = true; this.paint(); };
  E.raw = function () { var r = S.get(pkey(this.u.Id), {}) || {}; r.kids = this.p.kids; r.audio = this.p.audio; r.subs = this.p.subs; return r; };
  E.setIcon = function (t) {
    var v = this, r = v.raw();
    r.icon = t.g; delete r.iconUrl;
    TVM.setProfPrefs(v.u.Id, r); TVM.profilesDirty = true;
    v.paint();
    upload(v.u, t).then(function () { TVM.toast('Icône enregistrée'); }, function () {
      TVM.toast('Icône gardée sur cette télé (ouvre ce profil une fois pour l’envoyer au serveur)');
    });
  };
  E.onShow = function () { this.list.focus(); };
  E.onKey = function (k) {
    if (k === 'up' || k === 'down') { this.list.step(k === 'up' ? -1 : 1); return true; }
    if (k === 'ok') { var c = this.list.current(); if (c) c.__a(); return true; }
    return k !== 'back';
  };

  /* ---------------- choix de l'icône (comme Netflix : une rangée par série, avec ses personnages) ---------------- */
  var TILE_BG = BG;
  TVM.IconPickerView = function (u, done) {
    var v = this;
    v.done = done;
    v.el = el('div', 'view ipick');
    var cur = TVM.avatarFor(u, 200);
    v.el.innerHTML = '<div class="iphead"><h1>Modification du profil</h1><p>Changez d’icône de profil.</p>' +
      '<div class="ipcur"><span>' + esc(u.Name || '') + '</span>' + (cur ? '<img src="' + cur + '">' : '') + '</div></div>' +
      '<div class="ipw"><div class="iprows"></div></div>';
    v.rowsEl = v.el.querySelector('.iprows');
    v.rows = [];
    v.r = 0;
    /* tes images à toi (img/avatars/avatars.json) en premier, puis les icônes classiques */
    TVM.avatarPacks().then(function (packs) {
      if (!v.alive) return;
      function std(re) { ROWS.forEach(function (r) { if (re.test(r.label)) v.addRow({ label: r.label, tiles: r.keys.map(function (k) { return { g: k }; }) }); }); }
      std(/Classiques/);
      packs.forEach(function (pk) { v.addRow({ label: pk.label, tiles: pk.files.map(function (f) { return { g: 'f:' + f }; }) }); });
      std(/Expressions/);
      v.paint();
    });
    v.alive = true;
  };
  var IP = TVM.IconPickerView.prototype;
  IP.addRow = function (r) {
    var v = this, idx = v.rows.length;
    var row = el('div', 'iprow', '<div class="iplab">' + (r.logo ? '<img src="' + r.logo + '" alt="">' : esc(r.label)) + '</div><div class="iptw"><div class="ipt"></div></div>');
    var track = row.querySelector('.ipt');
    var els = r.tiles.map(function (t, i) {
      var src = t.g != null ? TVM.iconUrl(t.g, 160) : t.url;
      var d = el('div', 'ipi' + (t.url ? ' ph' : ''), '<img src="' + src + '" alt="">');
      if (t.url) d.style.backgroundColor = TILE_BG[(idx + i) % TILE_BG.length];
      d.addEventListener('click', function () { v.r = idx; v.rows[idx].c = i; v.pick(); });
      track.appendChild(d); return d;
    });
    v.rowsEl.appendChild(row);
    v.rows.push({ el: row, track: track, tiles: r.tiles, els: els, c: 0 });
  };
  IP.paint = function () {
    var v = this, R = TVM.rem(14.6), W = TVM.rem(12.8);
    v.rows.forEach(function (row, i) {
      row.el.classList.toggle('cur', i === v.r);
      row.els.forEach(function (e, j) { e.classList.toggle('f', i === v.r && j === row.c); });
      TVM.move(row.track, -Math.max(0, row.c - 4) * W, 0);
    });
    TVM.move(v.rowsEl, 0, -Math.max(0, v.r - 1) * R);
  };
  IP.pick = function () {
    var row = this.rows[this.r], t = row && row.tiles[row.c];
    if (!t) return;
    TVM.app.pop();
    this.done(t);
  };
  IP.onShow = function () { this.paint(); };
  IP.destroy = function () { this.alive = false; };
  IP.onKey = function (k) {
    var v = this, row = v.rows[v.r];
    if (k === 'left' && row.c > 0) { row.c--; v.paint(); return true; }
    if (k === 'right' && row.c < row.tiles.length - 1) { row.c++; v.paint(); return true; }
    if (k === 'up' && v.r > 0) { v.r--; v.paint(); return true; }
    if (k === 'down' && v.r < v.rows.length - 1) { v.r++; v.paint(); return true; }
    if (k === 'ok') { v.pick(); return true; }
    return k !== 'back';
  };

  /* ---------------- menu du profil (bouton en haut à droite de l'accueil) ---------------- */
  TVM.ProfileMenuView = function () {
    var v = this;
    v.overlay = true;
    v.el = el('div', 'view pmenu');
    var box = el('div', 'pmbox');
    v.el.appendChild(box);
    var items = [];
    function add(cls, html, act) {
      var d = el('div', 'pmi ' + cls, html);
      d.__a = act; d.addEventListener('click', act); box.appendChild(d); items.push(d);
    }
    function av(u) { var i = TVM.avatarFor(u, 120); return i ? '<img src="' + i + '">' : '<i>' + esc((u.Name || '?').charAt(0)) + '</i>'; }
    var me = A.user || { Id: A.userId, Name: '' };
    add('me', av(me) + '<div><b>' + esc(me.Name || '') + '</b><small>Changer de profil</small></div>', function () { TVM.app.reset(new TVM.ProfilesView()); });
    var sess = S.get('sessions', {});
    for (var k in sess) if (sess.hasOwnProperty(k) && k.indexOf(A.server + '|') === 0) {
      (function (uid, name) {
        if (uid === A.userId) return;
        add('other', av({ Id: uid, Name: name }) + '<span>' + esc(name) + '</span>', function () {
          A.useSession(uid).then(function () { TVM.goHome(); }, function () { TVM.app.reset(new TVM.ProfilesView()); });
        });
      })(k.split('|')[1], sess[k].name || 'Profil');
    }
    add('act', '<svg viewBox="0 0 24 24"><path d="M4 20l1-4L16 5l3 3L8 19z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Modifier le profil</span>',
      function () { TVM.app.pop(); TVM.app.push(new TVM.ProfileEditView(me)); });
    add('act', '<svg class="ico" viewBox="0 0 24 24"><path d="M12 20.5s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.5 2.9c0 5.4-7.5 10-7.5 10z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg><span>Mes goûts</span>',
      function () { TVM.app.pop(); TVM.app.push(new TVM.TasteQuizView(false)); });
    add('act', TVM.ICON.gear + '<span>Réglages</span>', function () { TVM.app.pop(); TVM.app.push(new TVM.SettingsView()); });
    add('act', '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .8-1 1.5v.4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><circle cx="12" cy="17" r="1" fill="currentColor"/></svg><span>Obtenir de l’aide</span>',
      function () { TVM.app.pop(); TVM.app.push(new TVM.HelpView()); });
    add('act', '<svg viewBox="0 0 24 24"><path d="M13 4h6v16h-6M10 8l-4 4 4 4M6 12h10" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Quitter Jellyfin</span>',
      function () { TVM.exit(); });
    v.list = new TVM.List(items);
  };
  TVM.ProfileMenuView.prototype.onShow = function () { this.list.focus(); };
  TVM.ProfileMenuView.prototype.onKey = function (k) {
    if (k === 'up' || k === 'down') { this.list.step(k === 'up' ? -1 : 1); return true; }
    if (k === 'ok') { this.list.current().__a(); return true; }
    if (k === 'left') { TVM.app.pop(); return true; }
    return k !== 'back';
  };

  /* ---------------- « Obtenir de l'aide » ---------------- */
  TVM.HelpView = function () {
    var v = this;
    v.el = el('div', 'view help');
    v.el.innerHTML = '<div class="hleft"><h1>Obtenir de l’aide</h1><div class="hlist"></div></div><div class="hright"></div>';
    var list = v.el.querySelector('.hlist'), right = v.el.querySelector('.hright');
    function kv(pairs) { return pairs.map(function (p) { return '<h3>' + esc(p[0]) + '</h3><p>' + esc(p[1] == null ? '—' : String(p[1])) + '</p>'; }).join(''); }
    var ua = navigator.userAgent, wv = (ua.match(/Web0S|webOS[^;)]*/i) || ['webOS'])[0], ch = (ua.match(/Chrome\/([\d.]+)/) || [, '?'])[1];
    var pages = [
      { t: 'Retour', back: true },
      { t: 'Utilisateur', show: function () {
        right.innerHTML = kv([['Nom de profil', A.user && A.user.Name], ['Administrateur', A.user && A.user.Policy && A.user.Policy.IsAdministrator ? 'oui' : 'non'],
          ['Dernière connexion', A.user && A.user.LastLoginDate ? new Date(A.user.LastLoginDate).toLocaleString('fr-FR') : null],
          ['Pays / Langue', 'FR / ' + (navigator.language || 'fr-FR')]]);
      } },
      { t: 'Appareil', show: function () {
        right.innerHTML = kv([['Application', 'Jellyfin Maison ' + TVM.version], ['Système', wv], ['Moteur web', 'Chromium ' + ch],
          ['Écran', window.innerWidth + ' × ' + window.innerHeight], ['Identifiant', A.deviceId]]);
      } },
      { t: 'Réseau', show: function () {
        right.innerHTML = kv([['Serveur', A.server], ['État', 'test en cours…']]);
        A.get('/System/Info/Public').then(function (i) {
          right.innerHTML = kv([['Serveur', A.server], ['Nom du serveur', i.ServerName], ['Version de Jellyfin', i.Version], ['Adresse locale', i.LocalAddress]]);
        }, function () { right.innerHTML = kv([['Serveur', A.server], ['État', 'injoignable']]); });
      } },
      { t: 'Vidéo', show: function () {
        var vid = document.createElement('video');
        function can(t) { var r = vid.canPlayType(t); return r ? 'oui' : 'non'; }
        right.innerHTML = kv([['H.264', can('video/mp4; codecs="avc1.640028"')], ['HEVC (H.265)', can('video/mp4; codecs="hvc1.1.6.L120.90"')],
          ['VP9', can('video/webm; codecs="vp9"')], ['Lecture directe', 'mp4, mkv, ts, webm'], ['Audio par défaut', C.audioPref === 'vo' ? 'version originale' : 'français']]);
      } },
      { t: 'Vérifier votre réseau', show: function () {
        right.innerHTML = '<h3>Vérification</h3><p>Mesure en cours…</p>';
        var t0 = Date.now(), n = 0, tot = 0;
        (function ping() {
          var t = Date.now();
          A.get('/System/Ping').catch(function () { return A.get('/System/Info/Public'); }).then(function () {
            tot += Date.now() - t; n++;
            if (n < 5) return ping();
            right.innerHTML = kv([['Serveur', 'joignable ✓'], ['Temps de réponse moyen', Math.round(tot / n) + ' ms'], ['Durée du test', (Date.now() - t0) + ' ms']]);
          }, function () { right.innerHTML = kv([['Serveur', 'injoignable ✗'], ['Conseil', 'vérifie que le PC du serveur est allumé et sur le même réseau']]); });
        })();
      } },
      { t: 'Tester l\u2019aperçu vidéo', show: function () { right.innerHTML = kv([['Test', 'Appuie sur OK pour lancer un aperçu ici et voir ce qui se passe.']]); },
        act: function () {
          right.innerHTML = '<h3>Test de l\u2019aperçu vidéo</h3><p class="htlog">Recherche d\u2019un film…</p><div class="htbox"></div>';
          var log = right.querySelector('.htlog'), box = right.querySelector('.htbox');
          function say(t) { log.innerHTML += '<br>' + esc(t); }
          A.items({ IncludeItemTypes: 'Movie', SortBy: 'Random', Limit: 1 }).then(function (l) {
            var it = l[0]; if (!it) { say('Aucun film'); return; }
            say('Film : ' + it.Name);
            TVM.previewUrl(it).then(function (u) {
              say('Adresse : ' + (u ? (u.indexOf('m3u8') > 0 ? 'flux HLS' : 'fichier direct') : 'aucune'));
              if (!u) return;
              TVM.preview.start(box, it, 0, { onPlay: function () { say('▶ La vidéo joue (image + son attendus)'); } });
              var t0 = Date.now();
              var chk = setInterval(function () {
                var vv = document.querySelector('.help .pvid');
                if (!vv) { say('Vidéo arrêtée'); clearInterval(chk); return; }
                say(((Date.now() - t0) / 1000).toFixed(0) + ' s · état ' + vv.readyState + ' · ' + (vv.error ? 'erreur ' + vv.error.code : 'ok') + ' · ' + (vv.currentSrc.indexOf('m3u8') > 0 ? 'HLS' : 'direct') + ' · ' + vv.videoWidth + '×' + vv.videoHeight);
                if (Date.now() - t0 > 20000) { clearInterval(chk); TVM.preview.stop(); say('Fin du test'); }
              }, 2000);
            });
          });
        } },
      { t: 'Tester l\u2019écran de veille', act: function () { if (TVM.saverShow) TVM.saverShow(); } },
      { t: 'Recharger tes personnalisations', show: function () { right.innerHTML = kv([['Personnalisations', TVM.ext ? TVM.ext.summary() : '—']]); },
        act: function () { if (TVM.ext) TVM.ext.load(true).then(function (k) { TVM.toast(k + ' personnalisation(s) chargée(s)'); }); } },
      { t: 'Recharger Jellyfin', act: function () { location.reload(); } },
      { t: 'Changer de serveur', act: function () { TVM.app.push(TVM.SetupView()); } },
      { t: 'Quitter Jellyfin', act: function () { TVM.exit(); } },
      { t: 'Se déconnecter', act: function () { A.forget(A.userId); TVM.app.reset(new TVM.ProfilesView()); } }
    ];
    var items = pages.map(function (pg) {
      var d = el('div', 'hrow', (pg.back ? '<svg viewBox="0 0 24 24"><path d="M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '') + esc(pg.t));
      d.__p = pg; d.addEventListener('click', function () { v.list.set(items.indexOf(d)); v.onKey('ok'); }); list.appendChild(d); return d;
    });
    v.list = new TVM.List(items, { onMove: function (i) { var pg = pages[i]; if (pg.show) pg.show(); else if (!pg.back) right.innerHTML = ''; } });
    v.i0 = 1;
  };
  TVM.HelpView.prototype.onShow = function () { this.list.set(this.list.i || this.i0); };
  TVM.HelpView.prototype.onKey = function (k) {
    if (k === 'up' || k === 'down') { this.list.step(k === 'up' ? -1 : 1); return true; }
    if (k === 'ok') { var pg = this.list.current().__p; if (pg.back) { TVM.app.pop(); return true; } if (pg.act) pg.act(); return true; }
    return k !== 'back';
  };
})();
