/*
 * Jellyfin Maison (webOS) — aperçus vidéo façon Netflix
 * Quand on reste sur une jaquette (ou sur une fiche), une vidéo se lance dedans :
 *  • bande-annonce locale si le titre en a une ;
 *  • sinon un passage du film / du premier épisode à voir (à 20 %) ;
 *  • pour « Continuer à regarder » : l'épisode à l'endroit où on s'est arrêté.
 * Un seul aperçu à la fois ; il s'arrête dès qu'on bouge. Aucune position de lecture
 * n'est enregistrée sur le serveur pendant un aperçu.
 * Réglages : TVM.config.preview (true/false), previewDelay, previewSound, previewMax.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, C = TVM.config;
  C.preview = TVM.store.get('preview', true);   // aperçus vidéo activés (réglable dans ⚙ Réglages)
  C.previewDelay = 1800;      // ms d'attente sur une jaquette avant de lancer la vidéo
  C.previewSound = true;      // avec le son (comme Netflix)
  C.previewMax = 90000;       // durée maxi d'un aperçu (ms)

  var cache = {}, timer = 0, maxT = 0, token = 0, cur = null;

  /* bande-annonce : fichier direct (léger) */
  function stream(id, at) {
    return A.server + '/Videos/' + id + '/stream' + A.qs({ static: 'true', api_key: A.token, deviceId: A.deviceId }) +
      (at > 1 ? '#t=' + Math.floor(at) : '');
  }
  /* passage d'un film / épisode : petit flux HLS 720p préparé par le serveur
     (la télé ne lit pas toujours le fichier d'origine en aperçu, et ça reste léger pour elle) */
  function hls(id, at) {
    return A.server + '/Videos/' + id + '/master.m3u8' + A.qs({
      MediaSourceId: id, DeviceId: A.deviceId, PlaySessionId: 'apercu' + id.slice(0, 8) + Date.now().toString(36), api_key: A.token,
      VideoCodec: 'h264', AudioCodec: 'aac', MaxAudioChannels: 2, TranscodingMaxAudioChannels: 2, MaxWidth: 1280, MaxHeight: 720,
      VideoBitrate: 3000000, AudioBitrate: 128000, SegmentContainer: 'ts', BreakOnNonKeyFrames: true,
      StartTimeTicks: Math.floor(Math.max(0, at) * 1e7)
    });
  }
  /* fichier direct → même passage en petit flux HLS préparé par le serveur (si la télé ne lit pas le fichier) */
  function toHls(url) {
    var m = /\/Videos\/([^/]+)\/stream/.exec(url), t = /#t=(\d+)/.exec(url);
    return m ? hls(m[1], t ? +t[1] : 0) : null;
  }
  function trailer(id) {
    return A.get('/Items/' + id + '/LocalTrailers', { userId: A.userId }).then(function (l) {
      l = (l && l.Items) || l || [];
      return l[0] ? stream(l[0].Id, 0) : null;
    }).catch(function () { return null; });
  }
  function at20(it) { return (it.RunTimeTicks || 0) / 1e7 * 0.2; }

  TVM.previewUrl = function (it) {
    if (!it || !it.Id) return Promise.resolve(null);
    if (cache[it.Id]) return cache[it.Id];
    var p;
    if (it.Type === 'Episode') {
      var ud = it.UserData || {};
      p = Promise.resolve(stream(it.Id, ud.PlaybackPositionTicks ? ud.PlaybackPositionTicks / 1e7 : at20(it)));
    } else if (it.Type === 'Series') {
      p = trailer(it.Id).then(function (u) {
        if (u) return u;
        return A.nextUp({ SeriesId: it.Id, Limit: 1 }).then(function (l) {
          return l[0] || A.episodes(it.Id, { Limit: 1 }).then(function (e) { return e[0]; });
        }).then(function (e) { return e ? stream(e.Id, at20(e)) : null; });
      });
    } else if (it.Type === 'Movie' || it.Type === 'Video') {
      p = (it.LocalTrailerCount ? trailer(it.Id) : Promise.resolve(null)).then(function (u) { return u || stream(it.Id, at20(it)); });
    } else p = Promise.resolve(null);
    p = p.catch(function () { return null; });
    cache[it.Id] = p;
    return p;
  };

  TVM.preview = {
    /* host : élément dans lequel placer la vidéo ; la classe « vid » lui est ajoutée quand l'image arrive */
    start: function (host, it, delay, opts) {
      TVM.preview.stop();
      opts = opts || {};
      if (!C.preview || !host || !it) return;
      var my = ++token;
      timer = setTimeout(function () {
        TVM.previewUrl(it).then(function (url) {
          if (my !== token || !url || !host.parentNode) return;
          /* webOS affiche la vidéo sur un plan à part : elle reste invisible (son seul) si elle est
             dans un bloc arrondi, transparent ou déplacé. On la pose donc directement dans la page,
             à l'emplacement exact de la jaquette, sans arrondi ni transparence. */
          var view = host.closest ? host.closest('.view') : null;
          if (!view) return;
          var r = host.getBoundingClientRect(), vr = view.getBoundingClientRect();
          var v = document.createElement('video');
          v.className = 'pvid';
          v.style.left = Math.round(r.left - vr.left) + 'px';
          v.style.top = Math.round(r.top - vr.top) + 'px';
          v.style.width = Math.round(r.width) + 'px';
          v.style.height = Math.round(r.height) + 'px';
          v.muted = !C.previewSound;
          var bg = A.backdrop(it, 1280); if (bg) v.setAttribute('poster', bg);   /* image tant que la vidéo charge */
          v.setAttribute('preload', 'auto');
          v.addEventListener('playing', function () { if (my === token) { v.classList.add('on'); host.classList.add('vid'); if (opts.onPlay && !v.__p) { v.__p = 1; opts.onPlay(); } } });
          v.addEventListener('error', function () {
            if (my !== token) return;
            var h = !v.__h && toHls(url);
            if (h) { v.__h = 1; url = h; if (cur) cur.url = h; v.src = h; var p2 = v.play(); if (p2 && p2.catch) p2.catch(function () {}); return; }
            TVM.preview.stop();
          });
          v.addEventListener('ended', function () { if (my === token) { if (cur) cur.ended = true; TVM.preview.stop(); } });
          v.src = url;
          if (host.classList.contains('hero')) view.insertBefore(v, view.firstChild);                              /* bandeau : tout au fond, sous le texte et les rangées */
          else if (host.classList.contains('dbg') && host.parentNode === view) view.insertBefore(v, host.nextSibling);   /* fond de fiche : sous le texte */
          else { v.classList.add('top'); view.appendChild(v); }                                                  /* jaquette : par-dessus */
          cur = { v: v, host: host, url: url, opts: opts };
          var pr = v.play(); if (pr && pr.catch) pr.catch(function () {});
          maxT = setTimeout(function () { if (my === token) TVM.preview.stop(); }, C.previewMax);
        });
      }, delay != null ? delay : C.previewDelay);
    },
    stop: function () {
      clearTimeout(timer); clearTimeout(maxT);
      token++;
      if (!cur) return;
      var c = cur; cur = null;
      if (c.opts && c.opts.onStop) { try { c.opts.onStop(!!c.ended); } catch (e) {} }
      c.host.classList.remove('vid');
      try { c.v.pause(); c.v.removeAttribute('src'); c.v.load(); } catch (e) {}
      if (c.v.parentNode) c.v.parentNode.removeChild(c.v);
      /* on arrête la préparation du flux sur le serveur */
      var m = /PlaySessionId=([^&#]+)/.exec(c.url || '');
      if (m) A.del('/Videos/ActiveEncodings', { deviceId: A.deviceId, playSessionId: decodeURIComponent(m[1]) }).catch(function () {});
    }
  };
  TVM.on('view', function () { TVM.preview.stop(); });
})();
