/*
 * Jellyfin Maison (webOS) — démarrage
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api;

  function hideSplash() {
    var s = document.getElementById('splash');
    if (s) { s.className = 'off'; setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 600); }
  }

  TVM.on('unauthorized', function () {
    if (TVM.__reauth) return;
    TVM.__reauth = true;
    A.forget(A.userId);
    TVM.toast('Session expirée : choisis ton profil');
    TVM.app.reset(new TVM.ProfilesView());
    setTimeout(function () { TVM.__reauth = false; }, 3000);
  });

  var sp = document.getElementById('splash'); if (sp && !TVM.config.intro) sp.innerHTML = TVM.logoHtml();   /* avec l'intro : écran noir, pas de logo en double */

  function boot() {
    if (!A.server) { TVM.app.reset(TVM.SetupView()); hideSplash(); return; }
    /* comme Netflix : à l'ouverture, toujours « Qui est-ce ? » (le dernier profil est déjà sélectionné) */
    TVM.app.reset(new TVM.ProfilesView());
    hideSplash();
  }

  /* l'appli revient au premier plan : on rafraîchit « Continuer à regarder » */
  document.addEventListener('webkitvisibilitychange', function () {
    var v = TVM.app.top();
    if (!document.webkitHidden && v && v.refreshContinue) v.refreshContinue();
  });

  /* logo + petite musique d'abord (rien d'autre ne tourne pendant, donc pas d'à-coups), puis « Qui est-ce ? » */
  TVM.intro(boot);
})();
