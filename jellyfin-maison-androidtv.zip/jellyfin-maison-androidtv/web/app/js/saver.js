/*
 * Jellyfin Maison (webOS) — écran de veille façon Netflix
 * Sans toucher la télécommande pendant quelques minutes (hors lecture d'une vidéo),
 * tes films et séries défilent en grand : image qui avance doucement, logo, genres et heure.
 * N'importe quelle touche revient là où tu étais.
 * Réglage : ⚙ Réglages → Écran de veille (3 min, 10 min ou désactivé).
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, C = TVM.config, el = TVM.el, esc = TVM.esc;
  C.saverMinutes = TVM.store.get('saverMinutes2', 1);   /* 1 min : avant la veille LG (environ 2 min) */

  var idleT = 0, box = null, items = [], i = -1, slideT = 0, clockT = 0, layer = 0;

  function busy() {
    var v = TVM.app.top();
    if (!v) return true;
    if (v.video && v.el && /player/.test(v.el.className) && !v.video.paused) return true;   /* jamais pendant une vidéo qui joue (en pause : oui) */
    if (/profiles/.test(v.el.className || '')) return true;                   /* « Qui est-ce ? » a déjà son diaporama */
    if (document.getElementById('intro')) return true;
    return false;
  }
  function arm() {
    clearTimeout(idleT);
    if (!C.saverMinutes) return;
    idleT = setTimeout(function () { if (busy()) arm(); else show(); }, C.saverMinutes * 60000);
  }
  TVM.saverArm = arm;

  function load() {
    if (!A.token || !A.userId) return Promise.resolve([]);
    var q = { IncludeItemTypes: 'Movie,Series', SortBy: 'Random', Limit: 40, ImageTypes: 'Backdrop', EnableImageTypes: 'Backdrop,Logo', Fields: 'Genres,ProductionYear', EnableUserData: false };
    var hs = TVM.homeScope;
    if (hs && hs.type === 'kids' && hs.libs && hs.libs.length) {
      /* profil Jeunesse : uniquement des images jeunesse */
      return Promise.all(hs.libs.map(function (l) { var o = JSON.parse(JSON.stringify(q)); o.ParentId = l.Id; o.Limit = 20; return A.items(o).catch(function () { return []; }); }))
        .then(function (rs) { var out = []; rs.forEach(function (r) { out = out.concat(r); }); return out.filter(function (it) { return it.BackdropImageTags && it.BackdropImageTags.length; }).sort(function () { return Math.random() - .5; }); });
    }
    return A.items(q)
      .then(function (l) { return l.filter(function (it) { return it.BackdropImageTags && it.BackdropImageTags.length; }); })
      .catch(function () { return []; });
  }
  function clock() {
    if (!box) return;
    var d = new Date(), h = d.getHours(), m = d.getMinutes();
    box.querySelector('.svclk').textContent = h + ':' + (m < 10 ? '0' : '') + m;
    clockT = setTimeout(clock, 20000);
  }
  function next() {
    if (!box || !items.length) return;
    i = (i + 1) % items.length;
    var it = items[i], url = A.backdrop(it, C.backdropWidth || 1920), im = new Image();
    im.onload = im.onerror = function () {
      if (!box) return;
      var ls = box.querySelectorAll('.svbg');
      layer = 1 - layer;
      var L = ls[layer];
      L.style.backgroundImage = 'url("' + url + '")';
      L.className = 'svbg z' + (i % 3);         /* trois mouvements de caméra différents */
      void L.offsetWidth;
      L.className += ' on';
      ls[1 - layer].className = ls[1 - layer].className.replace(' on', '');
      var logo = A.logo(it, 500), cap = box.querySelector('.svcap');
      cap.className = 'svcap';
      setTimeout(function () {
        if (!box) return;
        cap.innerHTML = (logo ? '<img src="' + logo + '">' : '<h2>' + esc(it.Name) + '</h2>') +
          '<p>' + [it.ProductionYear].concat((it.Genres || []).slice(0, 3).map(TVM.genreFr || String)).filter(Boolean).join(' • ') + '</p>';
        cap.className = 'svcap on';
      }, 700);
      slideT = setTimeout(next, 10000);
    };
    im.src = url;
  }
  function show() {
    if (box) return;
    load().then(function (l) {
      if (!l.length || busy()) { arm(); return; }
      items = l; i = -1;
      TVM.preview && TVM.preview.stop();
      box = el('div', '', '<div class="svbg"></div><div class="svbg"></div><div class="svshade"></div>' +
        '<div class="svtop">' + TVM.logoHtml() + '<span class="svclk"></span></div><div class="svcap"></div>');
      box.id = 'saver';
      document.body.appendChild(box);
      setTimeout(function () { if (box) box.className = 'on'; }, 30);
      clock();
      next();
    });
  }
  function hide() {
    clearTimeout(slideT); clearTimeout(clockT);
    var b = box; box = null;
    if (b) { b.className = ''; setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 500); }
  }
  /* toute action réveille ; la touche qui réveille ne fait rien d'autre */
  window.addEventListener('keydown', function (e) {
    if (box) { e.stopPropagation(); e.preventDefault(); hide(); }
    arm();
  }, true);
  /* pointeur Magic Remote : on ne compte qu'un vrai mouvement (il frémit tout seul) */
  var mx = -1, my = -1;
  window.addEventListener('mousemove', function (e) {
    if (Math.abs(e.clientX - mx) + Math.abs(e.clientY - my) < 30) return;
    mx = e.clientX; my = e.clientY;
    if (box) hide();
    arm();
  }, true);
  TVM.saverShow = show;
  TVM.saverHide = function () { if (box) hide(); arm(); };

  /* La télé LG lance sa propre veille (écran noir « Pour rallumer l'écran… ») quand aucune vidéo
     ne joue. On lui demande d'attendre tant que notre écran de veille s'en occupe (même méthode
     que Kodi / Moonlight sur webOS). Au bout d'une heure d'écran de veille, on la laisse faire. */
  var shownAt = 0, bridges = [];
  function luna(uri, params, cb) {
    if (!window.PalmServiceBridge) return null;
    try {
      var b = new window.PalmServiceBridge();
      b.onservicecallback = function (m) { try { if (cb) cb(JSON.parse(m)); } catch (e) {} };
      b.call(uri, JSON.stringify(params));
      bridges.push(b); if (bridges.length > 20) bridges.splice(1, 1);
      return b;
    } catch (e) { return null; }
  }
  var origShow = show;
  show = function () { shownAt = Date.now(); origShow(); };
  TVM.saverShow = show;
  luna('luna://com.webos.service.tvpower/power/registerScreenSaverRequest', { subscribe: true, clientName: 'fr.maison.webos-jelly' }, function (r) {
    if (!r || !r.timestamp) return;
    var v = TVM.app.top(), playing = v && v.video && !v.video.paused;
    var ours = C.saverMinutes > 0 && (!box || Date.now() - shownAt < 3600000);
    var ack = !(playing || ours);
    luna('luna://com.webos.service.tvpower/power/responseScreenSaverRequest', { clientName: 'fr.maison.webos-jelly', ack: ack, timestamp: r.timestamp });
    if (!ack && !box && !busy()) show();     /* la télé allait s'éteindre : on lance tout de suite les images */
  });
  arm();
})();
