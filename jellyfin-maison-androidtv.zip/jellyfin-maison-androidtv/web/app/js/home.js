/*
 * Jellyfin Maison (webOS) — accueil et pages de catégories, façon Netflix
 *
 * Pourquoi c'est fluide sur une vieille télé :
 *  • la sélection est calculée à partir des DONNÉES (rangée r, colonne c), jamais en
 *    cherchant les éléments dans la page ;
 *  • on ne fait que déplacer des calques (transform) : pas de défilement natif ;
 *  • seules les rangées proches de l'écran existent dans la page (les autres sont
 *    retirées), et dans une rangée seules les affiches visibles sont créées ;
 *  • les rangées sont chargées au serveur juste avant d'arriver dessus.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc, C = TVM.config;

  /* géométrie en rem (1 rem = 16 px en 1920×1080) */
  var G = {
    poster: { w: 14, h: 21 },
    land: { w: 14, h: 21 },          /* « Continuer à regarder » : jaquettes + progression, comme Netflix */
    top: { w: 21.6, h: 21 },
    wide: 37.33,                     /* jaquette choisie : 16:9 à la même hauteur */
    gap: 1,
    title: 3.4,
    padY: 6.6,                       /* place pour la ligne d'infos sous la jaquette choisie */
    left: 4,            // marge gauche des rangées
    heroH: 52,          // hauteur du bandeau (agrandi comme Netflix)
    rowsStart: 46       // début des rangées (elles mordent sur le bas du bandeau)
  };
  TVM.layout = G;

  var GENRES = {
    'action': 'Action', 'adventure': 'Aventure', 'action & adventure': 'Action et aventure', 'animation': 'Animation',
    'anime': 'Animé', 'biography': 'Biographie', 'comedy': 'Comédie', 'crime': 'Policier', 'documentary': 'Documentaire',
    'drama': 'Drame', 'family': 'En famille', 'fantasy': 'Fantastique', 'history': 'Histoire', 'horror': 'Horreur',
    'kids': 'Jeunesse', 'music': 'Musique', 'musical': 'Comédie musicale', 'mystery': 'Mystère', 'news': 'Info',
    'reality': 'Téléréalité', 'romance': 'Romance', 'science fiction': 'Science-fiction', 'sci-fi': 'Science-fiction',
    'sci-fi & fantasy': 'Science-fiction et fantastique', 'soap': 'Feuilleton', 'sport': 'Sport', 'suspense': 'Suspense',
    'talk': 'Talk-show', 'thriller': 'Thriller', 'tv movie': 'Téléfilm', 'war': 'Guerre', 'war & politics': 'Guerre et politique',
    'western': 'Western', 'tragedy': 'Tragédie', 'martial arts': 'Arts martiaux', 'short': 'Courts métrages', 'sports': 'Sport'
  };
  function genreFr(n) { return GENRES[String(n || '').toLowerCase()] || n; }
  TVM.genreFr = genreFr;

  function nameKey(it) {
    var n = it.Type === 'Episode' || it.Type === 'Season' ? it.SeriesName : it.Name;
    if (!n) return '';
    return 'n:' + String(n).toLowerCase().replace(/[^a-z0-9àâäéèêëïîôöùûüç]/g, '') + ':' + (it.Type === 'Movie' ? (it.ProductionYear || '') : '');
  }
  function key(it) { return it.Type === 'Episode' || it.Type === 'Season' ? (it.SeriesId || it.Id) : it.Id; }

  /* ================================================================ onglets */
  function findLib(views, type, re, avoid) {
    var l = views.filter(function (v) { return (!type || v.CollectionType === type) && (!re || re.test(v.Name)) && !(avoid && avoid.test(v.Name)); });
    return l[0] || null;
  }
  var SEARCH_ICO = '<svg class="sico" viewBox="0 0 24 24"><path fill="currentColor" d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>';
  /* micro (commandes vocales) juste à droite de la loupe */
  var MIC_ICO = '<svg class="sico mic" viewBox="0 0 24 24"><path fill="currentColor" d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm5.3-3a5.3 5.3 0 01-10.6 0H5a7 7 0 006 6.9V21h2v-3.1a7 7 0 006-6.9h-1.7z"/></svg>';
  function micTab() { return TVM.voice && TVM.voice.available() ? [{ label: MIC_ICO, html: true, scope: { type: 'voice' } }] : []; }
  TVM.homeTabs = function (views, kids) { return kids ? kidsTabs(views) : buildTabs(views); };
  function buildTabs(views) {
    if (C.tabs) {
      return C.tabs.map(function (t) { return { label: t.label, scope: t.scope || (t.match ? { type: 'lib', lib: findLib(views, null, t.match) } : { type: 'home' }) }; })
        .filter(function (t) { return t.scope.type !== 'lib' || t.scope.lib; });
    }
    var tabs = [{ label: SEARCH_ICO, html: true, scope: { type: 'search' } }].concat(micTab(),
      [{ label: 'Accueil', scope: { type: 'home' } }]);
    var series = findLib(views, 'tvshows', /s[ée]rie/i, /jeunesse|junior|anim/i) || findLib(views, 'tvshows', null, /anim/i);
    var films = findLib(views, 'movies', /film/i, /jeunesse|junior|anim/i) || findLib(views, 'movies', null, /anim/i);
    var anime = findLib(views, null, /anim/i);
    if (series) tabs.push({ label: 'Séries', scope: { type: 'lib', lib: series } });
    if (films) tabs.push({ label: 'Films', scope: { type: 'lib', lib: films } });
    if (anime) tabs.push({ label: 'Animé', scope: { type: 'lib', lib: anime } });
    tabs.push({ label: 'Nouveautés', scope: { type: 'new' } });
    tabs.push({ label: 'Mon Jellyfin', scope: { type: 'mine' } });
    tabs.push({ label: 'Catégories', scope: { type: 'cats' } });
    return tabs;
  }
  /* médiathèques de l'espace Jeunesse (réglable : TVM.config.kidsLibs) ; chaque profil ne voit
     que celles auxquelles il a accès dans Jellyfin (Tableau de bord → Utilisateurs → Accès aux médiathèques) */
  function kidsLibs(views) {
    var re = C.kidsLibs || /jeunesse|junior|anim|kids|enfant/i;
    return views.filter(function (v) { return re.test(v.Name || ''); });
  }
  TVM.kidsLibs = kidsLibs;
  /* médiathèques de l'interface Jeunesse : celles « jeunesse » si le profil en a, sinon tout ce qu'il voit */
  TVM.kidsScopeLibs = function (views) { var k = kidsLibs(views); return k.length ? k : views.slice(); };
  /* profil Jeunesse : réglage du profil (oui / non), sinon automatique :
     contrôle parental Jellyfin ≤ 12 ans, ou accès uniquement aux médiathèques jeunesse */
  TVM.isKidsProfile = function (user, views, pref) {
    pref = pref || {};
    if (pref.kids === 'on' || pref.kids === true) return true;
    if (pref.kids === 'off') return false;
    var pol = (user && user.Policy) || {}, max = pol.MaxParentalRating;
    if (max != null && max !== '' && +max <= 12) return true;
    var k = kidsLibs(views || []);
    return !!(views && views.length && k.length === views.length);
  };
  /* même requête sur plusieurs médiathèques, résultats mélangés un par un */
  function multi(libs, fn) {
    return Promise.all(libs.map(function (l) { return fn(l).catch(function () { return []; }); })).then(function (rs) {
      var out = [], max = 0; rs.forEach(function (r) { max = Math.max(max, r.length); });
      for (var i = 0; i < max; i++) rs.forEach(function (r) { if (r[i]) out.push(r[i]); });
      return out;
    });
  }
  function typesOf(lib) { var ct = lib.CollectionType; return ct === 'tvshows' ? 'Series' : ct === 'movies' ? 'Movie' : 'Movie,Series'; }
  /* menu de l'espace Jeunesse, comme Netflix Jeunesse : 🔍 Accueil Séries Films Mon Jellyfin */
  function kidsTabs(views) {
    var K = TVM.kidsScopeLibs(views), tabs = [{ label: SEARCH_ICO, html: true, scope: { type: 'search' } }].concat(micTab(), [{ label: 'Accueil', scope: { type: 'kids', libs: K } }]);
    var ser = K.filter(function (l) { return l.CollectionType === 'tvshows'; }), mov = K.filter(function (l) { return l.CollectionType === 'movies'; });
    if (ser.length) tabs.push({ label: 'Séries', scope: { type: 'kids', libs: ser, sub: 'series' } });
    if (mov.length) tabs.push({ label: 'Films', scope: { type: 'kids', libs: mov, sub: 'movies' } });
    tabs.push({ label: 'Mon Jellyfin', scope: { type: 'mine', kidsMine: true } });
    return tabs;
  }
  var viewsCache = null;
  function getViews() {
    if (viewsCache && viewsCache.uid === A.userId) return Promise.resolve(viewsCache.list);
    return A.views().then(function (l) {
      l = l.filter(function (v) { return !/^(playlists|music|books|photos|livetv)$/i.test(v.CollectionType || ''); });
      viewsCache = { uid: A.userId, list: l };
      return l;
    });
  }
  TVM.getViews = getViews;

  function sameScope(a, b) {
    if (a.type !== b.type) return false;
    if (a.type === 'kids') return (a.sub || '') === (b.sub || '');
    if (a.type === 'mine') return !!a.kidsMine === !!b.kidsMine;
    return a.type !== 'lib' || (a.lib && b.lib && a.lib.Id === b.lib.Id);
  }
  TVM.sameScope = sameScope;

  /* types d'éléments selon la médiathèque */
  function typesFor(scope) {
    if (scope.type === 'lib') {
      var ct = scope.lib.CollectionType;
      if (ct === 'tvshows') return 'Series';
      if (ct === 'movies') return 'Movie';
      if (ct === 'boxsets') return 'BoxSet';
    }
    return 'Movie,Series';
  }

  /* ================================================================ rangées façon Netflix
     (en plus des genres) : recommandations, pépites, acclamés, mini-séries, décennies… */
  function prenom() { return A.user && A.user.Name ? String(A.user.Name).split(/[ .@]/)[0] : ''; }
  function lastWatched(P) {
    var o = { IncludeItemTypes: 'Movie,Episode', Filters: 'IsPlayed', SortBy: 'DatePlayed', SortOrder: 'Descending', Limit: 12 };
    if (P) o.ParentId = P;
    return A.items(o).then(function (l) {
      var out = [], seen = {};
      l.forEach(function (it) { var id = it.Type === 'Episode' ? it.SeriesId : it.Id, name = it.Type === 'Episode' ? it.SeriesName : it.Name;
        if (id && !seen[id]) { seen[id] = 1; out.push({ Id: id, Name: name }); } });
      return out;
    });
  }
  function shuffle(l) { for (var i = l.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = l[i]; l[i] = l[j]; l[j] = t; } return l; }
  function netflixRows(P, T) {
    var movies = T === 'Movie', series = T === 'Series', R = [];
    function q(o) { o.IncludeItemTypes = o.IncludeItemTypes || (T === 'BoxSet' ? 'Movie,Series' : T); if (P) o.ParentId = P; o.Limit = o.Limit || C.rowSize * 2; return o; }
    if (TVM.tasteRow) R.push(TVM.tasteRow(P, T));
    var lw = null; function LW() { return lw || (lw = lastWatched(P).catch(function () { return []; })); }
    R.push({ title: 'Sélection pour ' + (prenom() || 'vous'), type: 'poster', load: function () {
      return LW().then(function (l) {
        return Promise.all(l.slice(0, 4).map(function (x) { return A.similar(x.Id).catch(function () { return []; }); })).then(function (rs) {
          var out = [], max = 0; rs.forEach(function (r) { max = Math.max(max, r.length); });
          for (var i = 0; i < max; i++) rs.forEach(function (r) { if (r[i]) out.push(r[i]); });
          return out;
        });
      });
    } });
    R.push({ title: 'Pépites à découvrir', type: 'poster', load: function () { return A.items(q({ Filters: 'IsUnplayed', MinCommunityRating: 7.3, SortBy: 'Random' })); } });
    R.push({ title: 'Parce que vous avez regardé…', type: 'poster', becauseOf: 0, load: function () {
      var row = this;
      return LW().then(function (l) {
        var x = l[0]; if (!x) return [];
        row.title = 'Parce que vous avez regardé ' + x.Name;
        return A.similar(x.Id);
      });
    } });
    R.push({ title: 'Acclamés par la critique', type: 'poster', load: function () { return A.items(q({ SortBy: 'CriticRating,CommunityRating', SortOrder: 'Descending', MinCriticRating: 70 })); } });
    if (!movies) R.push({ title: 'Mini-séries', type: 'poster', load: function () {
      return A.items(q({ IncludeItemTypes: 'Series', SortBy: 'Random', Limit: 300, Fields: 'ChildCount,' + A.FIELDS })).then(function (l) {
        return l.filter(function (it) { return it.ChildCount === 1; }).slice(0, C.rowSize);
      });
    } });
    R.push({ title: 'Les années 2010', type: 'poster', load: function () { return A.items(q({ Years: '2010,2011,2012,2013,2014,2015,2016,2017,2018,2019', SortBy: 'Random' })); } });
    if (!series) R.push({ title: 'Moins de 90 minutes', type: 'poster', load: function () {
      return A.items(q({ IncludeItemTypes: 'Movie', SortBy: 'Random', Limit: 200 })).then(function (l) {
        return l.filter(function (it) { return it.RunTimeTicks && it.RunTimeTicks < 90 * 6e8; }).slice(0, C.rowSize);
      });
    } });
    R.push({ title: 'Les années 2000', type: 'poster', load: function () { return A.items(q({ Years: '2000,2001,2002,2003,2004,2005,2006,2007,2008,2009', SortBy: 'Random' })); } });
    R.push({ title: 'Les grands classiques', type: 'poster', load: function () { return A.items(q({ MaxPremiereDate: '1999-12-31', MinCommunityRating: 6.8, SortBy: 'CommunityRating', SortOrder: 'Descending' })); } });
    R.push({ title: 'Les années 90', type: 'poster', load: function () { return A.items(q({ Years: '1990,1991,1992,1993,1994,1995,1996,1997,1998,1999', SortBy: 'Random' })); } });
    if (!series) R.push({ title: 'Sagas et collections', type: 'poster', load: function () { return A.items({ IncludeItemTypes: 'BoxSet', SortBy: 'Random', Limit: C.rowSize }); } });
    R.push({ title: 'Populaires chez vous', type: 'poster', load: function () { return A.items(q({ SortBy: 'PlayCount,DatePlayed', SortOrder: 'Descending' })); } });
    R.push({ title: 'Coups de cœur des spectateurs', type: 'poster', load: function () { return A.items(q({ MinCommunityRating: 7.8, SortBy: 'Random' })); } });
    if (!movies) R.push({ title: 'Séries terminées à regarder d\u2019une traite', type: 'poster', load: function () {
      return A.items(q({ IncludeItemTypes: 'Series', SortBy: 'Random', Limit: 300, Fields: 'Status,' + A.FIELDS })).then(function (l) { return l.filter(function (it) { return it.Status === 'Ended'; }).slice(0, C.rowSize); });
    } });
    if (!movies) R.push({ title: 'Séries toujours en cours', type: 'poster', load: function () {
      return A.items(q({ IncludeItemTypes: 'Series', SortBy: 'DateLastContentAdded', SortOrder: 'Descending', Limit: 200, Fields: 'Status,' + A.FIELDS })).then(function (l) { return l.filter(function (it) { return it.Status === 'Continuing'; }).slice(0, C.rowSize); });
    } });
    if (!series) R.push({ title: 'Grands films de plus de 2 h', type: 'poster', load: function () {
      return A.items(q({ IncludeItemTypes: 'Movie', SortBy: 'Random', Limit: 200 })).then(function (l) { return l.filter(function (it) { return it.RunTimeTicks > 120 * 6e8; }).slice(0, C.rowSize); });
    } });
    R.push({ title: 'Les années 80', type: 'poster', load: function () { return A.items(q({ Years: '1980,1981,1982,1983,1984,1985,1986,1987,1988,1989', SortBy: 'Random' })); } });
    R.push({ title: 'Sortis cette année', type: 'poster', load: function () { var y = new Date().getFullYear(); return A.items(q({ Years: y + ',' + (y - 1), SortBy: 'PremiereDate', SortOrder: 'Descending' })); } });
    R.push({ title: 'Pas encore commencés', type: 'poster', load: function () { return A.items(q({ Filters: 'IsUnplayed', SortBy: 'Random' })); } });
    R.push({ title: 'À revoir', type: 'poster', load: function () { return A.items(q({ Filters: 'IsPlayed', SortBy: 'Random' })); } });
    R.push({ title: 'Ajoutés il y a longtemps, jamais vus', type: 'poster', load: function () { return A.items(q({ Filters: 'IsUnplayed', SortBy: 'DateCreated', SortOrder: 'Ascending' })); } });
    R.forEach(function (r) { r.mix = true; });
    return R;
  }
  /* dernière rangée : « Tout le catalogue » (grille complète, triable) */
  function catalogRow(scope) {
    return { title: 'Tout le catalogue', type: 'poster', noDedupe: true, last: true, min: 1, load: function () {
      return [{ __catalog: true, Id: '__catalog', Name: 'Tout le catalogue' }];
    } };
  }
  /* mélange : une rangée « Netflix » toutes les deux rangées de genre */
  function interleave(a, b) {
    var out = [], i = 0, j = 0;
    while (i < a.length || j < b.length) {
      if (i < a.length) out.push(a[i++]);
      if (j < b.length) out.push(b[j++]);
      if (j < b.length) out.push(b[j++]);
    }
    return out;
  }

  /* ================================================================ rangées */
  function rowsFor(scope) {
    var P = scope.type === 'lib' ? scope.lib.Id : undefined, T = typesFor(scope), R = [];
    function q(o) { o.IncludeItemTypes = o.IncludeItemTypes || T; if (P) o.ParentId = P; o.Limit = o.Limit || C.rowSize; return o; }

    if (scope.type === 'new') {
      R.push({ title: 'Nouveaux films', type: 'poster', load: function () { return A.items({ IncludeItemTypes: 'Movie', SortBy: 'DateCreated', SortOrder: 'Descending', Limit: C.rowSize }); } });
      R.push({ title: 'Nouvelles séries et nouveaux épisodes', type: 'poster', load: function () { return A.items({ IncludeItemTypes: 'Series', SortBy: 'DateLastContentAdded,DateCreated', SortOrder: 'Descending', Limit: C.rowSize }); } });
      R.push({ title: 'Derniers épisodes ajoutés', type: 'land', noDedupe: true, min: 1, load: function () { return A.items({ IncludeItemTypes: 'Episode', SortBy: 'DateCreated', SortOrder: 'Descending', Limit: C.rowSize }); } });
      return R;
    }
    if (scope.type === 'mine') {
      /* comme « Mon Netflix » : Continuer, Top 10, Regardés récemment, Ma liste… puis plein de catégories */
      R.push({ title: 'Continuer à regarder', type: 'land', progress: true, noDedupe: true, min: 1, load: function () {
        return Promise.all([A.resumeItems({ Limit: 40 }).catch(function () { return []; }), A.nextUp({ Limit: 30 }).catch(function () { return []; })]).then(function (r) {
          var out = [], seen = {};
          r[0].concat(r[1]).forEach(function (it) { var k = key(it); if (!seen[k]) { seen[k] = 1; out.push(it); } });
          return out;
        });
      } });
      R.push({ title: 'Top 10 aujourd\u2019hui', type: 'top', min: 3, max: 10, noDedupe: true, load: function () { return A.items({ IncludeItemTypes: 'Movie,Series', SortBy: 'CommunityRating,SortName', SortOrder: 'Descending', Limit: 10, MinCommunityRating: 1 }); } });
      R.push({ title: 'Regardés récemment', type: 'poster', noDedupe: true, min: 1, load: function () {
        return A.items({ IncludeItemTypes: 'Movie,Episode', Filters: 'IsPlayed', SortBy: 'DatePlayed', SortOrder: 'Descending', Limit: 60 }).then(function (l) {
          var out = [], seen = {}; l.forEach(function (it) { var k = key(it); if (!seen[k]) { seen[k] = 1; out.push(it); } }); return out;
        });
      } });
      R.push({ title: 'Ma liste — Séries', type: 'poster', noDedupe: true, min: 1, load: function () { return A.items({ IncludeItemTypes: 'Series', Filters: 'IsFavorite', SortBy: 'SortName', Limit: 200 }); } });
      R.push({ title: 'Ma liste — Films', type: 'poster', noDedupe: true, min: 1, load: function () { return A.items({ IncludeItemTypes: 'Movie', Filters: 'IsFavorite', SortBy: 'SortName', Limit: 200 }); } });
      R.push({ title: 'Nouveautés', type: 'poster', load: function () { return A.items({ IncludeItemTypes: 'Movie,Series', SortBy: 'DateLastContentAdded,DateCreated', SortOrder: 'Descending', Limit: C.rowSize * 2 }); } });
      return R.concat(netflixRows(undefined, 'Movie,Series'));
    }
    if (scope.type === 'kids') {
      var L = scope.libs;
      R.push({ title: 'Les préférés des enfants', type: 'poster', load: function () {
        return multi(L, function (l) { return A.items({ ParentId: l.Id, IncludeItemTypes: typesOf(l), SortBy: 'Random', Limit: 8 }); }).then(function (l) {
          l = l.slice(0, 16);
          l.splice(Math.min(2, l.length), 0, { __surprise: true, Id: '__surprise', Name: 'Surprise !' });
          return l;
        });
      } });
      R.push({ title: 'Continuer à regarder', type: 'land', progress: true, min: 1, load: function () {
        return Promise.all([multi(L, function (l) { return A.resumeItems({ ParentId: l.Id, Limit: 20 }); }),
          multi(L, function (l) { return A.nextUp({ ParentId: l.Id, Limit: 15 }); })]).then(function (r) {
          var out = [], seen = {};
          r[0].concat(r[1]).forEach(function (it) { var k = key(it); if (!seen[k]) { seen[k] = 1; out.push(it); } });
          return out.slice(0, 25);
        });
      } });
      R.push({ title: 'Top 10 Jeunesse', type: 'top', min: 3, max: 10, load: function () {
        return multi(L, function (l) { return A.items({ ParentId: l.Id, IncludeItemTypes: typesOf(l), SortBy: 'CommunityRating,SortName', SortOrder: 'Descending', Limit: 10, MinCommunityRating: 1 }); })
          .then(function (l) { return l.sort(function (a, b) { return (b.CommunityRating || 0) - (a.CommunityRating || 0); }); });
      } });
      L.forEach(function (lib) {
        R.push({ title: lib.Name, type: 'poster', load: function () { return A.items({ ParentId: lib.Id, IncludeItemTypes: typesOf(lib), SortBy: 'DateLastContentAdded,DateCreated', SortOrder: 'Descending', Limit: C.rowSize * 2 }); } });
      });
      R.push(catalogRow(scope));
      R.push({ title: 'Ma liste', type: 'poster', noDedupe: true, last: true, min: 1, load: function () {
        return multi(L, function (l) { return A.items({ ParentId: l.Id, IncludeItemTypes: typesOf(l), Filters: 'IsFavorite', SortBy: 'SortName' }); });
      } });
      return R;
    }
    if (scope.type === 'list') {
      R.push({ title: 'Ma liste — Séries', type: 'poster', noDedupe: true, min: 1, load: function () { return A.items({ IncludeItemTypes: 'Series', Filters: 'IsFavorite', SortBy: 'SortName', Limit: 200 }); } });
      R.push({ title: 'Ma liste — Films', type: 'poster', noDedupe: true, min: 1, load: function () { return A.items({ IncludeItemTypes: 'Movie', Filters: 'IsFavorite', SortBy: 'SortName', Limit: 200 }); } });
      return R;
    }
    R.push({
      title: 'Continuer à regarder', type: 'land', progress: true, min: 1,
      load: function () {
        var o = {}; if (P) o.ParentId = P;
        return Promise.all([A.resumeItems({ ParentId: P, Limit: 40 }).catch(function () { return []; }),
          A.nextUp({ ParentId: P, Limit: 30 }).catch(function () { return []; })]).then(function (r) {
          var out = [], seen = {};
          r[0].sort(function (a, b) { return String((b.UserData || {}).LastPlayedDate || '').localeCompare(String((a.UserData || {}).LastPlayedDate || '')); });
          r[0].concat(r[1]).forEach(function (it) { var k = key(it); if (!seen[k]) { seen[k] = 1; out.push(it); } });   /* un seul épisode par série */
          return out.slice(0, 25);
        });
      }
    });
    R.push({ title: 'Top 10', type: 'top', min: 3, max: 10, load: function () { return A.items(q({ SortBy: 'CommunityRating,SortName', SortOrder: 'Descending', Limit: 10, MinCommunityRating: 1 })); } });
    R.push({ title: 'Nouveautés', type: 'poster', load: function () { return A.items(q({ SortBy: 'DateLastContentAdded,DateCreated', SortOrder: 'Descending', Limit: C.rowSize * 2 })); } });
    R = R.concat(netflixRows(P, T));
    R.push({ title: 'Ma liste', type: 'poster', noDedupe: true, last: true, min: 1, load: function () { return A.items(q({ Filters: 'IsFavorite', SortBy: 'DatePlayed,SortName', SortOrder: 'Descending' })); } });
    R.push(catalogRow(scope));
    return R;
  }
  function genreRows(scope) {
    var P = scope.type === 'lib' ? scope.lib.Id : undefined, T = typesFor(scope);
    if (scope.type === 'kids') return kidsGenreRows(scope.libs);
    if (scope.type !== 'home' && scope.type !== 'lib' && scope.type !== 'mine') return Promise.resolve([]);
    return A.genres({ ParentId: P, IncludeItemTypes: T, Fields: 'ItemCounts' }).then(function (gs) {
      function count(g) { return (g.MovieCount || 0) + (g.SeriesCount || 0) + (g.ChildCount || 0); }
      /* les genres les plus fournis ; un seul par nom français (Sci-Fi et Science Fiction = Science-fiction) */
      var byLabel = {};
      gs.forEach(function (g) { var l = genreFr(g.Name); if (!byLabel[l] || count(g) > count(byLabel[l].g)) byLabel[l] = { g: g, l: l }; });
      var list = Object.keys(byLabel).map(function (k) { return byLabel[k]; });
      var anyCount = list.some(function (x) { return count(x.g) > 0; });
      if (anyCount) list = list.filter(function (x) { return count(x.g) >= C.minRow; }).sort(function (a, b) { return count(b.g) - count(a.g); });
      list = list.slice(0, C.genreRows);
      /* ordre du jour : change chaque jour mais reste stable dans la journée */
      var seed = Math.floor(Date.now() / 864e5);
      list.sort(function (a, b) { return Math.sin(seed * 9301 + a.l.length * 49297 + a.l.charCodeAt(0)) - Math.sin(seed * 9301 + b.l.length * 49297 + b.l.charCodeAt(0)); });
      var gl = list.map(function (x) {
        return {
          title: x.l, type: 'poster',
          load: function () { var o = { Genres: x.g.Name, IncludeItemTypes: T, SortBy: 'Random', Limit: C.rowSize * 2 }; if (P) o.ParentId = P; return A.items(o); }
        };
      });
      /* rangées par studio / chaîne (Disney, Netflix, HBO…) */
      var so = { IncludeItemTypes: T, Recursive: true, userId: A.userId, Limit: 40, SortBy: 'SortName' }; if (P) so.ParentId = P;
      return A.get('/Studios', so).then(function (r) {
        var st = ((r && r.Items) || []).filter(function (x) { return x.Name && x.Name.length < 30; });
        st.sort(function () { return Math.random() - .5; });
        return gl.concat(st.slice(0, 6).map(function (x) {
          return { title: 'Productions ' + x.Name, type: 'poster', load: function () { var o = { StudioIds: x.Id, IncludeItemTypes: T, SortBy: 'Random', Limit: C.rowSize }; if (P) o.ParentId = P; return A.items(o); } };
        }));
      }).catch(function () { return gl; });
    }).catch(function () { return []; });
  }

  /* case « ? » de Netflix Jeunesse : un programme tiré au hasard se lance */
  function surprise(L) {
    if (!L.length) return;
    var lib = L[Math.floor(Math.random() * L.length)];
    A.items({ ParentId: lib.Id, IncludeItemTypes: typesOf(lib), SortBy: 'Random', Limit: 1 }).then(function (l) {
      var it = l[0]; if (!it) return;
      var o = el('div', 'surpop', '<div class="sbox"><b>?</b><div class="sname">' + esc(it.Name) + '</div></div>');
      document.body.appendChild(o);
      setTimeout(function () { o.classList.add('on'); }, 30);
      setTimeout(function () {
        if (o.parentNode) o.parentNode.removeChild(o);
        if (it.Type === 'Series') A.nextUp({ SeriesId: it.Id, Limit: 1 }).then(function (n) {
          if (n[0]) return n[0];
          return A.episodes(it.Id, { Limit: 1 }).then(function (e) { return e[0]; });
        }).then(function (ep) { TVM.playItem(ep || it); }, function () { TVM.app.push(new TVM.DetailsView(it)); });
        else TVM.playItem(it);
      }, 1900);
    });
  }
  function kidsGenreRows(L) {
    return Promise.all(L.map(function (l) { return A.genres({ ParentId: l.Id, IncludeItemTypes: typesOf(l), Fields: 'ItemCounts' }).catch(function () { return []; }); })).then(function (rs) {
      var by = {};
      rs.forEach(function (gs) { gs.forEach(function (g) {
        var lab = genreFr(g.Name), n = (g.MovieCount || 0) + (g.SeriesCount || 0) + (g.ChildCount || 0);
        if (!by[lab]) by[lab] = { l: lab, names: [], n: 0 };
        if (by[lab].names.indexOf(g.Name) < 0) by[lab].names.push(g.Name);
        by[lab].n += n;
      }); });
      var list = Object.keys(by).map(function (k) { return by[k]; });
      if (list.some(function (x) { return x.n > 0; })) list = list.filter(function (x) { return x.n >= C.minRow; });
      list.sort(function (a, b) { return b.n - a.n; });
      return list.slice(0, C.genreRows).map(function (x) {
        return { title: x.l, type: 'poster', load: function () {
          return multi(L, function (l) { return A.items({ ParentId: l.Id, Genres: x.names.join('|'), IncludeItemTypes: typesOf(l), SortBy: 'Random', Limit: C.rowSize }); });
        } };
      });
    });
  }

  /* ================================================================ écran */
  TVM.HomeView = function (scope) {
    var v = this;
    v.scope = scope;
    v.el = el('div', 'view home');
    v.el.innerHTML =
      '<div class="hero"><div class="hbg a"></div><div class="hbg b"></div><div class="hshade"></div>' +
      '  <div class="hinfo"><div class="hlogo"></div><div class="hmeta"></div><div class="hover"></div>' +
      '    <div class="hbtns"><div class="btn play">&#9654;&nbsp; Lecture</div><div class="btn more">&#9432;&nbsp; Plus d\'infos</div></div></div></div>' +
      '<div class="content"><div class="rows"></div></div>' +
      '<div class="menu"><div class="mleft">' + TVM.logoHtml() + '</div><div class="tabs"></div><div class="mright"></div></div>';
    v.content = v.el.querySelector('.content');
    v.rowsEl = v.el.querySelector('.rows');
    v.menuEl = v.el.querySelector('.menu');
    if (scope.type === 'kids' || scope.kidsMine) {
      v.el.classList.add('kids');
      v.menuEl.querySelector('.mright').insertAdjacentHTML('afterbegin', '<span class="kmark"><b>J</b><b>E</b><b>U</b><b>N</b><b>E</b><b>S</b><b>S</b><b>E</b></span>');
    }
    v.heroEl = v.el.querySelector('.hero');
    v.zone = 'hero';
    v.r = 0;
    v.rows = [];
    v.seen = {};
    v.chain = Promise.resolve();
    v.alive = true;

    /* ---------- menu ---------- */
    var tabsEl = v.el.querySelector('.tabs'), right = v.el.querySelector('.mright');
    v.menu = new TVM.List([]);
    getViews().then(function (views) {
      v.views = views;
      v.tabs = scope.type === 'kids' || scope.kidsMine ? kidsTabs(views) : buildTabs(views);
      /* logo à gauche, onglets au centre, puis à droite : icône du profil (▾ menu) et roue dentée des réglages */
      var items = v.tabs.map(function (t, i) {
        var d = el('div', 'tab' + (t.html ? ' ico t-' + t.scope.type : ''), t.html ? t.label : esc(t.label));
        if (sameScope(t.scope, scope)) d.classList.add('on');
        d.addEventListener('click', function () { v.menu.set(i); v.openTab(i); });
        tabsEl.appendChild(d);
        return d;
      });
      var prof = el('div', 'tab ico prof');
      var img = TVM.avatarFor ? TVM.avatarFor(A.user, 96) : A.userImg(A.user, 96);
      prof.innerHTML = (img ? '<img src="' + img + '">' : '<span>' + esc((A.user && A.user.Name || '?').charAt(0)) + '</span>') + '<em>' + TVM.ICON.chevron + '</em>';
      prof.addEventListener('click', function () { TVM.app.push(new TVM.ProfileMenuView()); });
      var gear = el('div', 'tab ico gear', TVM.ICON.gear);
      gear.addEventListener('click', function () { TVM.app.push(new TVM.SettingsView()); });
      right.appendChild(prof); right.appendChild(gear);
      items.push(prof, gear);
      v.menu = new TVM.List(items);
      var cur = 0; while (v.tabs[cur] && /search|voice/.test(v.tabs[cur].scope.type)) cur++;
      v.tabs.forEach(function (t, i) { if (sameScope(t.scope, scope)) cur = i; });
      v.menu.i = cur;
      if (v.zone === 'menu') v.menu.focus();
    });
    v.openTab = function (i) {
      var n = v.tabs ? v.tabs.length : 0;
      if (i === n) { TVM.app.push(new TVM.ProfileMenuView()); return; }
      if (i === n + 1) { TVM.app.push(new TVM.SettingsView()); return; }
      var t = v.tabs && v.tabs[i];
      if (!t) return;
      if (t.scope.type === 'cats') { TVM.app.push(new TVM.CategoriesView(v.views)); return; }
      if (t.scope.type === 'search') { TVM.app.push(new TVM.SearchView()); return; }
      if (t.scope.type === 'voice') { TVM.voice.start(); return; }
      if (sameScope(t.scope, scope)) { v.go('hero'); return; }
      var nv = new TVM.HomeView(t.scope);
      nv.startInMenu = i;
      TVM.app.reset(nv);
    };

    /* ---------- bandeau ---------- */
    v.hero = { items: [], i: -1, layer: 0, timer: 0, btns: new TVM.List([v.el.querySelector('.hbtns .play'), v.el.querySelector('.hbtns .more')]) };
    v.el.querySelector('.hbtns .play').addEventListener('click', function () { v.heroAct(0); });
    v.el.querySelector('.hbtns .more').addEventListener('click', function () { v.heroAct(1); });
    var hq = { SortBy: 'Random', Limit: C.heroCount, ImageTypes: 'Backdrop', IncludeItemTypes: typesFor(scope) === 'BoxSet' ? 'Movie,Series' : typesFor(scope) };
    if (scope.type === 'lib') hq.ParentId = scope.lib.Id;
    if (scope.type === 'new') { hq.SortBy = 'DateCreated'; hq.SortOrder = 'Descending'; }
    if (scope.type === 'list' || scope.type === 'mine') hq.Filters = 'IsFavorite';
    var heroLoad = scope.type === 'kids' ? multi(scope.libs, function (l) {
      return A.items({ ParentId: l.Id, SortBy: 'Random', Limit: Math.ceil(C.heroCount / scope.libs.length) + 1, ImageTypes: 'Backdrop', IncludeItemTypes: typesOf(l) });
    }) : A.items(hq);
    heroLoad.then(function (items) {
      v.hero.items = items.filter(function (it) { return A.backdrop(it, 10); });
      if (!v.hero.items.length) { v.heroEl.classList.add('empty'); if (v.zone === 'hero') v.go('rows'); return; }
      v.heroNext();
    });

    /* ---------- rangées ---------- */
    v.rows = rowsFor(scope).map(function (r) { return v.makeRow(r); });
    genreRows(scope).then(function (gr) {
      if (!v.alive || !gr.length) return;
      var at = v.rows.length;
      for (var i = 0; i < v.rows.length; i++) if (v.rows[i].def.last) { at = i; break; }
      var made = gr.map(function (r) { return v.makeRow(r); });
      var m0 = -1;
      for (var j = 0; j < v.rows.length; j++) if (v.rows[j].def.mix) { m0 = j; break; }
      var curRow = v.zone === 'rows' ? v.r : -1;
      if (m0 >= 0 && curRow < m0) {
        /* comme Netflix : les genres s'intercalent entre les rangées « sélection », « pépites »… */
        var mix = v.rows.slice(m0, at).filter(function (r) { return r.def.mix; });
        var before = v.rows.slice(0, m0), after = v.rows.slice(at);
        v.rows = before.concat(interleave(mix, made), after);
      } else {
        Array.prototype.splice.apply(v.rows, [at, 0].concat(made));
        if (v.zone === 'rows' && v.r >= at) v.r += made.length;
      }
      v.relayout();
      v.update();
    });
    TVM.emit('home', v, scope);     /* une extension peut ajouter des rangées : v.addRow({...}) */
    v.relayout();
    v.update();
  };

  var H = TVM.HomeView.prototype;

  /* une extension peut ajouter une rangée : { title, type:'poster'|'land'|'top', load: function(){ return Promise<items> } } */
  H.addRow = function (def, index) {
    var r = this.makeRow(def);
    if (index == null) { index = this.rows.length; for (var i = 0; i < this.rows.length; i++) if (this.rows[i].def.last) { index = i; break; } }
    this.rows.splice(index, 0, r);
    this.relayout(); this.update();
    return r;
  };

  H.makeRow = function (def) {
    var g = G[def.type] || G.poster;
    var expand = def.type !== 'top';
    return { def: def, items: null, state: 'idle', col: 0, el: null, track: null, cards: {}, dead: false, expand: expand,
      cw: TVM.rem(g.w), ch: TVM.rem(g.h), step: TVM.rem(g.w + G.gap), wide: TVM.rem(G.wide), h: TVM.rem(G.title + g.h + G.padY), top: 0 };
  };

  H.relayout = function () {
    var y = TVM.rem(G.rowsStart);
    for (var i = 0; i < this.rows.length; i++) {
      var r = this.rows[i];
      r.top = y;
      if (!r.dead) y += r.h;
      if (r.el) { TVM.move(r.el, 0, r.top); r.el.style.display = r.dead ? 'none' : ''; }
    }
  };

  /* chargement dans l'ordre des rangées (pour que « une affiche à la fois » soit stable) */
  H.loadUpTo = function (n) {
    var v = this;
    for (var idx = 0; idx <= n && idx < v.rows.length; idx++) {
      (function (row) {
        if (row.state !== 'idle') return;
        row.state = 'loading';
        var p = Promise.resolve().then(function () { return row.def.load.call(row.def); }).catch(function (e) { console.warn('[TVM] rangée', row.def.title, e); return []; });
        v.chain = v.chain.then(function () {
          return p.then(function (items) {
            if (!v.alive) return;
            items = items || [];
            /* jamais deux fois le même titre dans une rangée (même série présente dans deux médiathèques…) */
            var inRow = {};
            items = items.filter(function (it) {
              if (it.__surprise || it.__catalog) return true;
              var a = key(it), b = nameKey(it);
              if (inRow[a] || (b && inRow[b])) return false;
              inRow[a] = 1; if (b) inRow[b] = 1;
              return true;
            });
            if (C.dedupe && !row.def.noDedupe) items = items.filter(function (it) { var b = nameKey(it); return !v.seen[key(it)] && !(b && v.seen[b]); });
            items = items.slice(0, row.def.max || C.rowSize);
            var min = row.def.min != null ? row.def.min : C.minRow;
            if (items.length < min) items = [];                       /* rangée trop maigre : on ne l'affiche pas */
            if (!row.def.noDedupe || row.def.mark) items.forEach(function (it) { v.seen[key(it)] = 1; var b = nameKey(it); if (b) v.seen[b] = 1; });
            row.items = items;
            row.state = 'ready';
            if (row.el) { var h = row.el.querySelector('h2'); if (h) h.textContent = row.def.title; }   /* titre calculé au chargement */
            if (!items.length) { row.dead = true; v.relayout(); }
            v.update();
            TVM.emit('row', v, row);
          });
        });
      })(v.rows[idx]);
    }
  };

  /* ---------------- rendu d'une rangée (fenêtre d'affiches visibles) ---------------- */
  H.renderRow = function (i) {
    var v = this, row = v.rows[i];
    if (!row || row.dead) return;
    if (!row.el) {
      row.el = el('div', 'row t-' + row.def.type);
      row.el.innerHTML = '<h2>' + esc(row.def.title) + '</h2><div class="track"></div><div class="rinfo"></div>';
      row.track = row.el.querySelector('.track');
      row.track.style.height = row.ch + 'px';
      TVM.move(row.el, 0, row.top);
      v.rowsEl.appendChild(row.el);
      row.cards = {};
      row.el.addEventListener('click', function (e) {
        var c = e.target.closest ? e.target.closest('.card') : null;
        if (c && c.__i != null) { v.r = i; row.col = c.__i; v.activate(); }
      });
    }
    if (row.state !== 'ready') {
      if (!row.el.querySelector('.skel')) row.track.innerHTML = '<div class="skel"></div>';
      return;
    }
    var sk = row.el.querySelector('.skel'); if (sk) sk.parentNode.removeChild(sk);
    var n = row.items.length, visible = Math.ceil(window.innerWidth / row.step) + 1;
    var from = row.col, to = Math.min(n - 1, row.col + visible + 2);
    for (var k in row.cards) {
      if (row.cards.hasOwnProperty(k) && (k < from || k > to)) { var old = row.cards[k]; old.parentNode && old.parentNode.removeChild(old); delete row.cards[k]; }
    }
    for (var c = from; c <= to; c++) if (!row.cards[c]) row.cards[c] = v.makeCard(row, c);
    v.placeCards(row, i);
    TVM.move(row.track, TVM.rem(G.left) - row.col * row.step, 0);
  };
  /* la jaquette choisie s'élargit (seulement dans la rangée active) et pousse les suivantes */
  H.placeCards = function (row, i) {
    if (row.items && row.items.length === 1 && row.items[0].__catalog && row.cards[0]) {
      /* « Afficher tout le catalogue » : un grand bouton centré, à la fin des rangées */
      var d0 = row.cards[0], w0 = TVM.rem(44), h0 = TVM.rem(9);
      d0.style.width = w0 + 'px'; d0.style.height = h0 + 'px';
      TVM.move(d0, ((window.innerWidth || 1920) - w0) / 2 - TVM.rem(G.left), (row.ch - h0) / 2);
      return;
    }
    var active = this.zone === 'rows' && this.r === i && row.expand;
    var extra = active ? row.wide - row.cw : 0;
    for (var k in row.cards) {
      if (!row.cards.hasOwnProperty(k)) continue;
      var idx = +k, d = row.cards[k], wide = active && idx === row.col;
      TVM.move(d, idx * row.step + (active && idx > row.col ? extra : 0), 0);
      d.style.width = (wide ? row.wide : row.cw) + 'px';
      if (wide) this.widen(row, d, row.items[idx]); else d.classList.remove('wide');
    }
  };
  H.widen = function (row, d, it) {
    if (it.__surprise || it.__catalog) return;
    d.classList.add('wide');
    if (d.__wl) return;
    var bg = A.backdrop(it, 800) || A.land(it, 800), logo = A.logo(it, 400), ud = it.UserData || {};
    var w = el('div', 'wl', (bg ? '<img class="wbg" src="' + bg + '">' : '') +
      (logo ? '<img class="wlogo" src="' + logo + '">' : '<div class="wname">' + esc(it.Type === 'Episode' ? (it.SeriesName || it.Name) : it.Name) + '</div>') +
      (ud.PlayedPercentage ? '<div class="prog"><i style="width:' + Math.round(ud.PlayedPercentage) + '%"></i></div>' : ''));
    d.appendChild(w);
    d.__wl = w;
  };
  function infoLine(it) {
    if (it.__surprise) return '<div class="ri1">Un programme jeunesse tiré au hasard</div>';
    if (it.__catalog) return '<div class="ri1">Tous les titres, de A à Z (ou par date, année, note)</div>';
    var ud = it.UserData || {}, l1 = [], l2 = '';
    if (it.Type === 'Episode') {
      l1.push('S' + (it.ParentIndexNumber || 0) + ' É' + (it.IndexNumber || 0) + ' • ' + esc(it.Name));
    } else {
      if (it.ProductionYear) l1.push(it.ProductionYear);
      if (it.Type === 'Series' && it.ChildCount) l1.push(it.ChildCount + ' saison' + (it.ChildCount > 1 ? 's' : ''));
      else if (it.RunTimeTicks) l1.push(TVM.duration(it.RunTimeTicks));
      if (it.Genres && it.Genres[0]) l1.push(esc(genreFr(it.Genres[0])));
      if (it.OfficialRating) l1.push('<span class="rate">' + esc(it.OfficialRating) + '</span>');
    }
    if (ud.PlaybackPositionTicks && it.RunTimeTicks) l2 = 'Encore ' + TVM.duration(it.RunTimeTicks - ud.PlaybackPositionTicks);
    return '<div class="ri1">' + l1.join(' • ') + '</div>' + (l2 ? '<div class="ri2">' + l2 + '</div>' : '');
  }

  H.makeCard = function (row, i) {
    var it = row.items[i], t = row.def.type, d = el('div', 'card');
    d.__i = i;
    d.style.width = row.cw + 'px';
    d.style.height = row.ch + 'px';
    TVM.move(d, i * row.step, 0);
    var src, html = '';
    if (it.__catalog) {
      d.classList.add('catal');
      d.innerHTML = '<div class="cg"><i></i><i></i><i></i><i></i><i></i><i></i></div><b>Afficher tout le catalogue</b>';
      row.el.classList.add('catrow');
      row.track.appendChild(d);
      return d;
    }
    if (it.__surprise) {
      d.classList.add('surp');
      d.innerHTML = '<i>✦</i><i>✦</i><i>✦</i><b>?</b><span>Surprise !</span>';
      row.track.appendChild(d);
      return d;
    }
    if (t === 'land') {
      src = A.poster(it, C.posterWidth);
      var ud = it.UserData || {}, pct = ud.PlayedPercentage || 0;
      html = (src ? '<img class="pim" src="' + src + '">' : '<div class="noimg">' + esc(it.SeriesName || it.Name) + '</div>') +
        (row.def.progress && pct ? '<div class="prog"><i style="width:' + Math.round(pct) + '%"></i></div>' : '');
    } else if (t === 'top') {
      src = A.poster(it, C.posterWidth);
      html = '<span class="num">' + (i + 1) + '</span>' + (src ? '<img src="' + src + '">' : '<div class="noimg">' + esc(it.Name) + '</div>');
    } else {
      src = A.poster(it, C.posterWidth);
      html = src ? '<img class="pim" src="' + src + '">' : '<div class="noimg">' + esc(it.Name) + '</div>';
    }
    d.innerHTML = html;
    row.track.appendChild(d);
    TVM.emit('card', d, it, row.def);
    return d;
  };

  /* ---------------- mise à jour générale (après chaque touche) ---------------- */
  H.update = function (fromPointer) {
    var v = this;
    if (!v.alive) return;
    var first = v.firstRow();
    if (v.zone === 'rows' && v.rows[v.r] && v.rows[v.r].dead) {          /* rangée vide (tout déjà affiché ailleurs) */
      var alt = v.nextRow(v.r, 1); if (alt < 0) alt = v.nextRow(v.r, -1);
      v.r = alt < 0 ? first : alt;
    }
    var r = v.zone === 'rows' ? v.r : first;
    r = Math.max(r, 0);
    /* on charge et on affiche toujours 4 vraies rangées sous la rangée choisie
       (les rangées trop maigres, masquées, ne comptent pas : plus de « vide » en dessous) */
    var lo = r, hi = r, seen = 0;
    for (var b = r - 1; b >= 0; b--) if (!v.rows[b].dead) { lo = b; break; }
    for (var a = r + 1; a < v.rows.length && seen < 4; a++) { hi = a; if (!v.rows[a].dead) seen++; }
    v.loadUpTo(hi + 1);
    for (var i = 0; i < v.rows.length; i++) {
      var row = v.rows[i];
      if (i >= lo && i <= hi && !row.dead) { v.renderRow(i); }
      else if (row.el) { row.el.parentNode.removeChild(row.el); row.el = null; row.cards = {}; }
    }

    /* focus (l'aperçu vidéo ne s'arrête que si la sélection change vraiment) */
    var fcr = v.rows[v.r], fk = v.zone === 'rows' ? 'r' + v.r + ':' + (fcr ? fcr.col + ':' + (fcr.items && fcr.items[fcr.col] ? fcr.items[fcr.col].Id : '') : '') : 'top';
    var changed = fk !== v.fk;
    if (changed) { v.fk = fk; v.pvOn = false; TVM.preview.stop(); if (fk === 'top' && v.hero.items[v.hero.i]) v.heroVideo(v.hero.items[v.hero.i]); }
    if (v.cur) { v.cur.classList.remove('f'); v.cur = null; }
    v.menu.blur(); v.hero.btns.blur();
    var y = 0, browsing = v.zone === 'rows';
    if (v.zone === 'menu') { v.menu.focus(); }
    else if (v.zone === 'hero') { v.hero.btns.focus(); }
    else {
      var cr = v.rows[v.r];
      if (cr && cr.el) {
        var card = cr.cards[cr.col], it = cr.items && cr.items[cr.col];
        if (card) { card.classList.add('f'); v.cur = card; }
        y = cr.top - TVM.rem(8.6);                /* la rangée choisie se place juste sous le menu */
        var info = cr.el.querySelector('.rinfo');
        if (info && it) { info.innerHTML = infoLine(it); TVM.move(info, TVM.rem(G.left), 0); }
        if (card && it && card.__wl && (changed || !v.pvOn)) { v.pvOn = true; TVM.preview.start(card.__wl, it); }   /* la vidéo démarre si on reste dessus */
      }
    }
    for (var g = 0; g < v.rows.length; g++) if (v.rows[g].el) {
      v.rows[g].el.classList.toggle('gone', browsing && g < v.r);
      v.rows[g].el.classList.toggle('cur', browsing && g === v.r);
    }
    v.menuEl.classList.toggle('away', false);
    v.heroEl.classList.toggle('browse', browsing);
    TVM.move(v.content, 0, -y);
    if (!browsing && v.browsing) { v.browsing = false; clearTimeout(v.hero.ft); v.heroNext(); }
    if (browsing) { v.browsing = true; clearTimeout(v.hero.timer); }
  };

  H.firstRow = function () { for (var i = 0; i < this.rows.length; i++) if (!this.rows[i].dead) return i; return 0; };
  H.nextRow = function (from, d) {
    for (var i = from + d; i >= 0 && i < this.rows.length; i += d) if (!this.rows[i].dead) return i;
    return -1;
  };

  /* ---------------- bandeau ---------------- */
  H.heroNext = function () {
    var v = this, h = v.hero;
    clearTimeout(h.timer);
    if (!v.alive || !h.items.length || v.zone === 'rows') return;
    if (v.el.style.display === 'none') { h.timer = setTimeout(function () { v.heroNext(); }, 3000); return; }
    var n = (h.i + 1) % h.items.length;
    v.paintHero(h.items[n], function () {
      h.i = n;
      if (h.items.length > 1) h.timer = setTimeout(function () { v.heroNext(); }, C.heroInterval);
      v.heroVideo(h.items[n]);
    });
  };
  /* comme Netflix : la bande-annonce / un extrait se lance dans le bandeau, avec le son */
  H.heroVideo = function (it) {
    var v = this, h = v.hero;
    if (!C.preview || !it || v.zone === 'rows' || v.el.style.display === 'none') return;
    TVM.preview.start(v.heroEl, it, 2500, {
      onPlay: function () { clearTimeout(h.timer); },
      onStop: function (ended) {
        if (!v.alive || v.zone === 'rows') return;
        clearTimeout(h.timer);
        if (h.items.length > 1) h.timer = setTimeout(function () { v.heroNext(); }, ended ? 600 : C.heroInterval);
      }
    });
  };
  /* titre sélectionné dans une rangée → affiché en grand en haut (attente courte : pas de chargement pendant qu'on fait défiler vite) */
  H.heroFocus = function (it) {
    var v = this, h = v.hero;
    clearTimeout(h.ft);
    if (h.shown === it.Id) return;
    h.ft = setTimeout(function () { if (v.alive && v.zone === 'rows') v.paintHero(it); }, 320);
  };
  H.paintHero = function (it, done) {
    var v = this, h = v.hero, url = A.backdrop(it, C.backdropWidth);
    h.shown = it.Id;
    var paint = function () {
      if (!v.alive || h.shown !== it.Id) return;
      var layers = v.el.querySelectorAll('.hbg');
      if (url) {
        h.layer = 1 - h.layer;
        layers[h.layer].style.backgroundImage = 'url("' + url + '")';
        layers[h.layer].classList.add('on');
        layers[1 - h.layer].classList.remove('on');
      }
      var ep = it.Type === 'Episode', logo = A.logo(it, 600), meta = [];
      if (ep) meta.push('S' + (it.ParentIndexNumber || 0) + ':É' + (it.IndexNumber || 0) + ' « ' + esc(it.Name) + ' »');
      if (it.ProductionYear && !ep) meta.push(it.ProductionYear);
      if (it.OfficialRating) meta.push('<span class="rate">' + esc(it.OfficialRating) + '</span>');
      if (it.Type === 'Series' && it.ChildCount) meta.push(it.ChildCount + ' saison' + (it.ChildCount > 1 ? 's' : ''));
      else if (it.RunTimeTicks) meta.push(TVM.duration(it.RunTimeTicks));
      v.el.querySelector('.hlogo').innerHTML = logo ? '<img src="' + logo + '">' : '<h1>' + esc(ep ? (it.SeriesName || it.Name) : it.Name) + '</h1>';
      v.el.querySelector('.hmeta').innerHTML = meta.join(' &nbsp;·&nbsp; ');
      v.el.querySelector('.hover').textContent = it.Overview || '';
      if (done) done();
    };
    if (!url) { paint(); return; }
    var im = new Image();
    im.onload = im.onerror = paint;
    im.src = url;
  };
  H.heroAct = function (b) {
    var it = this.hero.items[this.hero.i];
    if (!it) return;
    if (b === 0) TVM.playItem(it); else TVM.app.push(new TVM.DetailsView(it));
  };

  /* ---------------- OK sur une affiche ---------------- */
  H.activate = function () {
    var row = this.rows[this.r];
    if (!row || !row.items) return;
    var it = row.items[row.col];
    if (!it) return;
    if (row.def.onSelect) { row.def.onSelect(it); return; }
    if (it.__surprise) { surprise(this.scope.libs || []); return; }
    if (it.__catalog) { TVM.app.push(new TVM.CatalogView(this.scope)); return; }
    if (row.def.progress || it.Type === 'Episode') TVM.playItem(it);       /* « Continuer à regarder » : reprise directe */
    else TVM.app.push(new TVM.DetailsView(it));
  };

  /* ---------------- touches ---------------- */
  H.onKey = function (k) {
    var v = this;
    if (v.zone === 'menu') {
      if (k === 'left' || k === 'right') { v.menu.step(k === 'left' ? -1 : 1); v.armTab(); return true; }
      if (k === 'down') { v.go(v.hero.items.length ? 'hero' : 'rows'); return true; }
      if (k === 'ok') { v.openTab(v.menu.i); return true; }
      if (k === 'back') { return v.backHome(); }
      return true;
    }
    if (v.zone === 'hero') {
      if (k === 'left' || k === 'right') { v.hero.btns.step(k === 'left' ? -1 : 1); return true; }
      if (k === 'up') { v.go('menu'); return true; }
      if (k === 'down') { v.go('rows'); return true; }
      if (k === 'ok') { v.heroAct(v.hero.btns.i); return true; }
      if (k === 'back') { v.go('menu'); return true; }
      return true;
    }
    var row = v.rows[v.r];
    if (k === 'left' || k === 'right') {
      if (row && row.items) { var n = TVM.clamp(row.col + (k === 'left' ? -1 : 1), 0, row.items.length - 1); if (n !== row.col) { row.col = n; v.update(); } }
      return true;
    }
    if (k === 'up') {
      var p = v.nextRow(v.r, -1);
      if (p < 0) v.go(v.hero.items.length ? 'hero' : 'menu'); else { v.r = p; v.update(); }
      return true;
    }
    if (k === 'down') { var q = v.nextRow(v.r, 1); if (q >= 0) { v.r = q; v.update(); } return true; }
    if (k === 'ok') { v.activate(); return true; }
    if (k === 'back') {
      if (row && row.col > 0) { row.col = 0; v.update(); return true; }      /* 1er Retour : début de la rangée */
      v.go(v.hero.items.length ? 'hero' : 'menu'); return true;              /* 2e : retour en haut */
    }
    if (k === 'play' || k === 'playpause') { var pi = row && row.items && row.items[row.col]; if (pi && !pi.__catalog && !pi.__surprise) TVM.playItem(pi); return true; }
    return true;
  };
  /* comme Netflix : rester 2 secondes sur un onglet l'ouvre, sans appuyer sur OK */
  H.armTab = function () {
    var v = this, i = v.menu.i;
    clearTimeout(v.tabT);
    if (!v.tabs || i >= v.tabs.length) return;
    var t = v.tabs[i];
    if (t.scope.type === 'cats' || t.scope.type === 'search' || sameScope(t.scope, v.scope)) return;
    v.tabT = setTimeout(function () { if (v.alive && v.zone === 'menu' && v.menu.i === i) v.openTab(i); }, C.tabDelay);
  };
  H.go = function (zone) {
    clearTimeout(this.tabT);
    this.zone = zone;
    if (zone === 'rows') this.r = this.firstRow();
    this.update();
  };
  /* Retour depuis le menu : vers l'accueil, puis double appui pour quitter */
  H.backHome = function () {
    var hs = TVM.homeScope || { type: 'home' };
    if (!sameScope(this.scope, hs)) { TVM.app.reset(new TVM.HomeView(hs)); return true; }
    var now = Date.now();
    if (now - (this.lastBack || 0) < 2500) { TVM.exit(); return true; }
    this.lastBack = now;
    TVM.toast('Appuie encore sur Retour pour quitter');
    return true;
  };

  H.onShow = function () {
    var v = this;
    if (v.startInMenu != null) { v.zone = 'menu'; v.menu.i = v.startInMenu; v.startInMenu = null; }
    v.update();
    if (v.hero.i >= 0) v.heroNext();
    /* au retour du lecteur : on rafraîchit « Continuer à regarder » */
    if (v.needRefresh) { v.needRefresh = false; v.refreshContinue(); }
  };
  H.onHide = function () { clearTimeout(this.hero.timer); TVM.preview.stop(); this.needRefresh = true; };
  H.destroy = function () { clearTimeout(this.tabT); this.alive = false; clearTimeout(this.hero.timer); TVM.preview.stop(); };
  H.refreshContinue = function () {
    var v = this;
    v.rows.forEach(function (row) {
      if (!row.def.progress || row.state !== 'ready') return;
      Promise.resolve().then(row.def.load).then(function (items) {
        if (!v.alive) return;
        row.items = items; row.col = Math.min(row.col, Math.max(0, items.length - 1));
        var wasDead = row.dead; row.dead = !items.length;
        if (row.el) { row.el.parentNode.removeChild(row.el); row.el = null; row.cards = {}; }
        if (wasDead !== row.dead) v.relayout();
        v.update();
      }).catch(function () {});
    });
  };
})();
