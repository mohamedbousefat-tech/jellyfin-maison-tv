/*
 * Jellyfin Maison (webOS) — personnalisations chargées depuis TON serveur
 *
 * 1) CSS : dans Jellyfin › Tableau de bord › Général › « CSS personnalisé », tout ce qui est
 *    placé entre ces deux lignes s'applique à l'appli télé (et n'a aucun effet ailleurs) :
 *        /* TVMAISON-DEBUT *\/
 *        .card.f { … }
 *        /* TVMAISON-FIN *\/
 *
 * 2) JS : dans JS Injector, un script qui contient ces deux lignes :
 *        // TVMAISON-DEBUT
 *        if (window.TVM) { TVM.on('home', function (page) { … }); }
 *        // TVMAISON-FIN
 *    Seul le code entre les deux repères est exécuté par l'appli télé : ton « tout en un »
 *    (fait pour le site web, trop lourd pour la C9) n'est jamais chargé ici.
 *
 * Les personnalisations sont relues à chaque démarrage de l'appli.
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api;
  var RE_CSS = /\/\*\s*TVMAISON-DEBUT\s*\*\/([\s\S]*?)\/\*\s*TVMAISON-FIN\s*\*\//g;
  var RE_JS = /TVMAISON-DEBUT[^\n]*\n([\s\S]*?)\n[^\n]*TVMAISON-FIN/g;
  var done = { css: 0, js: 0, src: [] };

  function blocks(text, re) {
    var out = [], m;
    re.lastIndex = 0;
    while ((m = re.exec(text))) out.push(m[1]);
    return out;
  }
  function text(url) {
    return fetch(url, { headers: { 'Authorization': A.authValue() } }).then(function (r) { return r.ok ? r.text() : ''; }).catch(function () { return ''; });
  }
  function addCss(css) {
    var old = document.getElementById('tvm-custom-css');
    if (old) old.parentNode.removeChild(old);
    if (!css) return;
    var st = document.createElement('style');
    st.id = 'tvm-custom-css';
    st.textContent = css;
    document.head.appendChild(st);
  }
  function runJs(code, from) {
    try { (new Function('TVM', code))(TVM); done.js++; }
    catch (e) { console.error('[TVM] personnalisation JS (' + from + ')', e); TVM.toast('Erreur dans ta personnalisation JS'); }
  }

  TVM.ext = {
    summary: function () { return done.css + ' bloc(s) CSS, ' + done.js + ' bloc(s) JS'; },
    load: function (again) {
      if (!A.server) return Promise.resolve(0);
      if (again) done = { css: 0, js: 0, src: [] };
      /* CSS personnalisé du serveur */
      var pCss = text(A.server + '/Branding/Css').then(function (css) {
        var b = blocks(css || '', RE_CSS);
        done.css = b.length;
        addCss(b.join('\n'));
      });
      /* scripts JS Injector : on cherche les repères dans la page web du serveur et ses scripts ajoutés */
      var pJs = text(A.server + '/web/index.html').then(function (html) {
        if (!html) return;
        var jobs = [];
        blocks(html, RE_JS).forEach(function (c) { jobs.push(Promise.resolve({ c: c, f: 'index.html' })); });
        var re = /<script[^>]+src=["']([^"']+)["']/gi, m;
        while ((m = re.exec(html))) {
          var src = m[1];
          if (/(\.bundle\.js|\.chunk\.js|serviceworker|libraries\/|main\.jellyfin)/i.test(src)) continue;   /* code d'origine de Jellyfin */
          var url = /^https?:/i.test(src) ? src : A.server + (src.charAt(0) === '/' ? '' : '/web/') + src;
          done.src.push(url);
          jobs.push(text(url).then(function (url) { return function (t) { return { all: blocks(t || '', RE_JS), f: url }; }; }(url)));
        }
        return Promise.all(jobs).then(function (res) {
          res.forEach(function (r) {
            if (r.c) runJs(r.c, r.f);
            if (r.all) r.all.forEach(function (c) { runJs(c, r.f); });
          });
        });
      });
      return Promise.all([pCss, pJs]).then(function () {
        TVM.emit('extensions');
        /* l'accueil était déjà affiché avant le chargement : on le présente aux extensions */
        if (done.js) TVM.app.stack.forEach(function (v) { if (v instanceof TVM.HomeView) TVM.emit('home', v, v.scope); });
        return done.css + done.js;
      });
    }
  };
})();
