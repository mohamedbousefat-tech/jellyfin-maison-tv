/*
 * Jellyfin Maison (webOS) — intro du logo (reprise du module 26 de ton « tout en un »)
 * Écran noir, le « J » vert se dessine en lumière, les lettres JELLYFIN tombent et s'allument
 * comme un néon, éclat lumineux + « ting » cristallin. Son original fabriqué par l'appli.
 * Jouée à l'ouverture de l'appli et après un changement de profil. N'importe quelle touche la passe.
 * Réglages : TVM.config.intro (true/false), introSound (true/false), introVolume (0 à 1).
 */
(function () {
  'use strict';
  var TVM = window.TVM, C = TVM.config;
  C.intro = TVM.store.get('intro', true);
  C.introSound = true;
  C.introVolume = 0.8;

  /* ---------------- son ---------------- */
  var ctx = null;
  function reverb(c, sec, decay) {
    var len = Math.floor(c.sampleRate * sec), ir = c.createBuffer(2, len, c.sampleRate);
    for (var ch = 0; ch < 2; ch++) {
      var d = ir.getChannelData(ch);
      for (var i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    var cv = c.createConvolver(); cv.buffer = ir; return cv;
  }
  function env(g, pts) { g.gain.setValueAtTime(0.0001, pts[0][0]); for (var i = 1; i < pts.length; i++) g.gain.exponentialRampToValueAtTime(Math.max(0.0001, pts[i][1]), pts[i][0]); }
  function fmBell(c, dest, fr, t, dur, vol, ratio, depth) {
    var car = c.createOscillator(), mod = c.createOscillator(), mg = c.createGain(), g = c.createGain();
    car.frequency.value = fr; mod.frequency.value = fr * ratio;
    mg.gain.setValueAtTime(fr * depth, t); mg.gain.exponentialRampToValueAtTime(fr * 0.05, t + dur);
    mod.connect(mg); mg.connect(car.frequency); car.connect(g); g.connect(dest);
    env(g, [[t, 0], [t + 0.008, vol], [t + dur, 0.0001]]);
    car.start(t); mod.start(t); car.stop(t + dur + 0.05); mod.stop(t + dur + 0.05);
  }
  function synth(c) {
    var t0 = c.currentTime + 0.08;
    var out = c.createGain(); out.gain.value = C.introVolume * 1.5;
    var comp = c.createDynamicsCompressor(); out.connect(comp); comp.connect(c.destination);
    var rv = reverb(c, 3.5, 2.6), rvg = c.createGain(); rvg.gain.value = 0.9; rv.connect(rvg); rvg.connect(out);
    var dry = c.createGain(); dry.gain.value = 0.6; dry.connect(out);
    function both(n) { n.connect(dry); n.connect(rv); }
    /* grave qui monte */
    var sub = c.createOscillator(), sub2 = c.createOscillator(), sg = c.createGain(), s2g = c.createGain();
    sub.type = 'sine'; sub.frequency.setValueAtTime(41.2, t0); sub.frequency.linearRampToValueAtTime(55, t0 + 2.6);
    sub2.type = 'triangle'; sub2.frequency.setValueAtTime(82.4, t0); sub2.frequency.linearRampToValueAtTime(110, t0 + 2.6);
    s2g.gain.value = 0.25; sub2.connect(s2g); s2g.connect(sg); sub.connect(sg); both(sg);
    env(sg, [[t0, 0], [t0 + 2.4, 0.5], [t0 + 3.0, 0.35], [t0 + 5.6, 0.0001]]);
    sub.start(t0); sub2.start(t0); sub.stop(t0 + 5.8); sub2.stop(t0 + 5.8);
    /* souffle */
    var len = Math.floor(c.sampleRate * 6), nb = c.createBuffer(1, len, c.sampleRate), nd = nb.getChannelData(0);
    for (var i = 0; i < len; i++) nd[i] = Math.random() * 2 - 1;
    var ns = c.createBufferSource(), nf = c.createBiquadFilter(), ng = c.createGain();
    ns.buffer = nb; nf.type = 'bandpass'; nf.Q.value = 2.5;
    nf.frequency.setValueAtTime(250, t0); nf.frequency.exponentialRampToValueAtTime(2400, t0 + 2.6); nf.frequency.exponentialRampToValueAtTime(600, t0 + 5.5);
    env(ng, [[t0, 0], [t0 + 2.5, 0.22], [t0 + 5.5, 0.0001]]);
    ns.connect(nf); nf.connect(ng); both(ng); ns.start(t0); ns.stop(t0 + 5.8);
    /* nappe */
    var pf = c.createBiquadFilter(); pf.type = 'lowpass'; pf.Q.value = 1;
    pf.frequency.setValueAtTime(300, t0 + 0.6); pf.frequency.exponentialRampToValueAtTime(3200, t0 + 2.7); pf.frequency.exponentialRampToValueAtTime(900, t0 + 5.5);
    var pg = c.createGain(); env(pg, [[t0 + 0.6, 0], [t0 + 2.6, 0.07], [t0 + 5.6, 0.0001]]);
    pf.connect(pg); both(pg);
    [220, 329.63, 440, 493.88, 659.25].forEach(function (fr) {
      [-9, 9].forEach(function (dt) {
        var o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = fr; o.detune.value = dt;
        o.connect(pf); o.start(t0 + 0.6); o.stop(t0 + 5.8);
      });
    });
    /* scintillements (une lettre = un scintillement) puis le « ting » */
    [1318.5, 1760, 1975.5, 2637, 2217.5, 2960, 1760, 3520].forEach(function (fr, k) { fmBell(c, rv, fr, t0 + 0.9 + k * 0.16, 1.2, 0.035, 3.5, 1.2); });
    fmBell(c, dry, 880, t0 + 2.65, 4.0, 0.20, 3.5, 2.2);
    fmBell(c, rv, 880, t0 + 2.65, 4.0, 0.25, 3.5, 2.2);
    fmBell(c, rv, 1318.5, t0 + 2.67, 3.4, 0.10, 2.0, 1.5);
    fmBell(c, rv, 1760, t0 + 2.70, 3.0, 0.06, 3.5, 1.0);
  }
  /* son pré-enregistré (snd/intro.mp3, fabriqué à partir de la même musique) : un simple lecteur audio
     démarre à coup sûr sur la télé ; la synthèse en direct reste en secours */
  var audioEl = null;
  function playSound() {
    if (!C.introSound) return;
    try {
      audioEl = new Audio('snd/intro.mp3');
      audioEl.volume = C.introVolume;
      var pr = audioEl.play();
      if (pr && pr.catch) pr.catch(function () { audioEl = null; liveSound(); });
      return;
    } catch (e) { audioEl = null; }
    liveSound();
  }
  function liveSound() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
      ctx = new AC();
      var go = function () { if (ctx && ctx.state === 'running') synth(ctx); };
      if (ctx.state === 'running') go(); else if (ctx.resume) ctx.resume().then(go)['catch'](function () {});
    } catch (e) {}
  }
  function stopSound(fade) {
    if (audioEl) {
      var a = audioEl; audioEl = null;
      if (!fade) { try { a.pause(); } catch (e) {} }
      else (function down() { try { a.volume = Math.max(0, a.volume - 0.08); if (a.volume > 0) setTimeout(down, 120); else a.pause(); } catch (e) {} })();
    }
    if (!ctx) return;
    var c = ctx; ctx = null;
    setTimeout(function () { try { c.close(); } catch (e) {} }, fade ? 3500 : 0);
  }

  /* ---------------- image ---------------- */
  var J = 'M18 6L32 2V34A15 15 0 0 1 2 34V26H14V34A4 4 0 0 0 18 34Z';
  TVM.intro = function (done) {
    var cb = done || function () {}, called = false;
    done = function () { if (!called) { called = true; cb(); } };
    if (!C.intro) { done(); return; }
    var o = document.createElement('div');
    o.id = 'intro';
    var lets = 'JELLYFIN'.split('').map(function (ch, i) {
      var d = (0.9 + i * 0.16).toFixed(2), w = (2.65 + i * 0.05).toFixed(2);
      return '<b style="-webkit-animation-delay:' + w + 's;animation-delay:' + w + 's"><i style="-webkit-animation-delay:' + d + 's,' + d + 's;animation-delay:' + d + 's,' + d + 's">' + ch + '</i></b>';
    }).join('');
    o.innerHTML = '<div class="ifg"></div><div class="ifl"></div><div class="ivg"></div>' +
      '<div class="ilg"><span class="imk"><svg viewBox="0 0 34 52"><defs><linearGradient id="introG" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6dff6d"/><stop offset="1" stop-color="#1fb81f"/></linearGradient></defs>' +
      '<path class="ifi" fill="url(#introG)" d="' + J + '"/><path class="iln" d="M25 4V37" stroke="#0e8a1c" stroke-width="1.2"/>' +
      '<path class="ist" d="' + J + '"/></svg></span><span class="itx">' + lets + '</span></div>';
    document.body.appendChild(o);
    var ended = false, outT, endT;
    function end(skip) {
      if (ended) return;
      ended = true;
      clearTimeout(outT); clearTimeout(endT);
      window.removeEventListener('keydown', onKey, true);
      stopSound(!skip);
      o.className += ' out';
      setTimeout(function () { if (o.parentNode) o.parentNode.removeChild(o); }, skip ? 250 : 700);
      done();
    }
    function onKey(e) { e.stopPropagation(); e.preventDefault(); end(true); }
    window.addEventListener('keydown', onKey, true);
    o.addEventListener('click', function () { end(true); });
    /* on attend que la police et le son soient prêts, puis image et son partent ensemble (pas d'à-coups) */
    var started = false;
    function go() {
      if (started || ended) return;
      started = true;
      requestAnimationFrame(function () { requestAnimationFrame(function () {
        if (ended) return;
        o.className = 'go';
        if (audioEl) { var pr = audioEl.play(); if (pr && pr.catch) pr.catch(function () { audioEl = null; liveSound(); }); }
        else playSound();
        /* l'écran suivant se prépare sous l'intro (encore opaque), puis l'intro s'efface dessus : un seul fondu */
        setTimeout(function () { var sp = document.getElementById('splash'); if (sp) sp.style.display = 'none'; done(); }, 4300);
        outT = setTimeout(function () { o.className = 'go fade'; }, 5000);
        endT = setTimeout(function () { end(false); }, 5600);
      }); });
    }
    if (C.introSound) {
      try {
        audioEl = new Audio(); audioEl.preload = 'auto'; audioEl.volume = C.introVolume;
        audioEl.addEventListener('canplaythrough', function () { fontReady(go); });
        audioEl.addEventListener('error', function () { audioEl = null; fontReady(go); });
        audioEl.src = 'snd/intro.mp3'; audioEl.load();
      } catch (e) { audioEl = null; }
    }
    function fontReady(cb) {
      try { if (document.fonts && document.fonts.ready) { var t = setTimeout(cb, 600); document.fonts.ready.then(function () { clearTimeout(t); cb(); }); return; } } catch (e) {}
      cb();
    }
    if (!audioEl) fontReady(go);
    setTimeout(go, 1500);          /* au pire, on démarre quand même */
  };
})();
