/*
 * Jellyfin Maison (webOS) — dialogue avec le serveur Jellyfin
 * Utilise les adresses récentes de l'API (10.9 et +), avec repli automatique
 * sur les anciennes si le serveur ne les connaît pas.
 */
(function () {
  'use strict';
  var TVM = window.TVM, S = TVM.store;

  var deviceId = S.get('deviceId');
  if (!deviceId) {
    deviceId = 'tvm-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    S.set('deviceId', deviceId);
  }

  var A = TVM.api = { server: S.get('server', ''), token: '', userId: '', user: null, deviceId: deviceId };

  function qs(o) {
    var p = [];
    for (var k in o) if (o.hasOwnProperty(k) && o[k] != null && o[k] !== '') p.push(encodeURIComponent(k) + '=' + encodeURIComponent(o[k]));
    return p.length ? '?' + p.join('&') : '';
  }
  A.qs = qs;

  A.authValue = function () {
    return 'MediaBrowser Client="Jellyfin Maison TV", Device="' + TVM.deviceName + '", DeviceId="' + deviceId +
      '", Version="' + TVM.version + '"' + (A.token ? ', Token="' + A.token + '"' : '');
  };

  A.req = function (method, path, body) {
    var h = { 'Authorization': A.authValue(), 'X-Emby-Authorization': A.authValue() };
    var o = { method: method, headers: h };
    if (body !== undefined) { h['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
    return fetch(A.server + path, o).then(function (r) {
      if (r.status === 401 && A.token) TVM.emit('unauthorized');
      if (!r.ok) { var e = new Error('HTTP ' + r.status + ' ' + path); e.status = r.status; throw e; }
      return r.text().then(function (t) { return t ? JSON.parse(t) : null; });
    });
  };
  A.get = function (p, q) { return A.req('GET', p + qs(q || {})); };
  A.post = function (p, b, q) { return A.req('POST', p + qs(q || {}), b === undefined ? {} : b); };
  A.del = function (p, q) { return A.req('DELETE', p + qs(q || {})); };

  /* adresse récente d'abord, ancienne si 404 */
  A.both = both;
  function both(method, recent, old, q, body) {
    return A.req(method, recent + qs(q || {}), body).catch(function (e) {
      if (e.status === 404 || e.status === 405) return A.req(method, old + qs(q || {}), body);
      throw e;
    });
  }

  A.FIELDS = 'Overview,PrimaryImageAspectRatio,ProductionYear,OfficialRating,CommunityRating,RunTimeTicks,Genres,ChildCount';
  function base(q) {
    var o = { userId: A.userId, Recursive: true, Fields: A.FIELDS, EnableImageTypes: 'Primary,Backdrop,Logo,Thumb', ImageTypeLimit: 1, EnableUserData: true };
    for (var k in q) if (q.hasOwnProperty(k)) o[k] = q[k];
    return o;
  }
  function list(r) { return (r && r.Items) || (r && r.length !== undefined ? r : []) || []; }

  A.items = function (q) { return both('GET', '/Items', '/Users/' + A.userId + '/Items', base(q)).then(list); };
  A.item = function (id) { return both('GET', '/Items/' + id, '/Users/' + A.userId + '/Items/' + id, { userId: A.userId }); };
  A.resumeItems = function (q) {
    var o = base(q); delete o.Recursive; o.MediaTypes = 'Video';
    return both('GET', '/UserItems/Resume', '/Users/' + A.userId + '/Items/Resume', o).then(list);
  };
  A.latest = function (q) {
    var o = base(q); delete o.Recursive;
    return both('GET', '/Items/Latest', '/Users/' + A.userId + '/Items/Latest', o).then(list);
  };
  A.nextUp = function (q) {
    var o = base(q); delete o.Recursive;
    return A.get('/Shows/NextUp', o).then(list);
  };
  A.views = function () { return both('GET', '/UserViews', '/Users/' + A.userId + '/Views', { userId: A.userId }).then(list); };
  A.genres = function (q) {
    var o = { userId: A.userId, Recursive: true, SortBy: 'SortName' };
    for (var k in q) if (q.hasOwnProperty(k)) o[k] = q[k];
    return A.get('/Genres', o).then(list);
  };
  A.seasons = function (id) { return A.get('/Shows/' + id + '/Seasons', { userId: A.userId, Fields: 'PrimaryImageAspectRatio' }).then(list); };
  A.episodes = function (id, q) {
    var o = { userId: A.userId, Fields: 'Overview,PrimaryImageAspectRatio', EnableImageTypes: 'Primary,Thumb,Backdrop', EnableUserData: true };
    for (var k in q) if (q.hasOwnProperty(k)) o[k] = q[k];
    return A.get('/Shows/' + id + '/Episodes', o).then(list);
  };
  A.similar = function (id) {
    return A.get('/Items/' + id + '/Similar', { userId: A.userId, Limit: 24, Fields: A.FIELDS, EnableImageTypes: 'Primary,Backdrop,Logo,Thumb', ImageTypeLimit: 1 }).then(list);
  };
  A.setFavorite = function (id, on) {
    var m = on ? 'POST' : 'DELETE';
    return both(m, '/UserFavoriteItems/' + id, '/Users/' + A.userId + '/FavoriteItems/' + id, { userId: A.userId }, on ? {} : undefined);
  };

  /* ======== Images ======== */
  A.img = function (id, type, w, tag, idx) {
    if (!id) return '';
    return A.server + '/Items/' + id + '/Images/' + type + (idx != null ? '/' + idx : '') +
      qs({ maxWidth: w, quality: TVM.config.imgQuality, tag: tag });
  };
  A.poster = function (it, w) {
    var t = it.ImageTags || {};
    if (it.Type === 'Episode' || it.Type === 'Season') {
      if (it.SeriesId && it.SeriesPrimaryImageTag) return A.img(it.SeriesId, 'Primary', w, it.SeriesPrimaryImageTag);
    }
    if (t.Primary) return A.img(it.Id, 'Primary', w, t.Primary);
    if (it.SeriesId && it.SeriesPrimaryImageTag) return A.img(it.SeriesId, 'Primary', w, it.SeriesPrimaryImageTag);
    return '';
  };
  A.land = function (it, w) {
    var t = it.ImageTags || {};
    if (it.Type === 'Episode' && t.Primary) return A.img(it.Id, 'Primary', w, t.Primary);
    if (t.Thumb) return A.img(it.Id, 'Thumb', w, t.Thumb);
    if (it.ParentThumbItemId && it.ParentThumbImageTag) return A.img(it.ParentThumbItemId, 'Thumb', w, it.ParentThumbImageTag);
    return A.backdrop(it, w) || A.poster(it, w);
  };
  A.backdrop = function (it, w) {
    if (it.BackdropImageTags && it.BackdropImageTags.length) return A.img(it.Id, 'Backdrop', w, it.BackdropImageTags[0], 0);
    if (it.ParentBackdropItemId && it.ParentBackdropImageTags && it.ParentBackdropImageTags.length)
      return A.img(it.ParentBackdropItemId, 'Backdrop', w, it.ParentBackdropImageTags[0], 0);
    return '';
  };
  A.logo = function (it, w) {
    var t = it.ImageTags || {};
    if (t.Logo) return A.img(it.Id, 'Logo', w, t.Logo);
    if (it.ParentLogoItemId && it.ParentLogoImageTag) return A.img(it.ParentLogoItemId, 'Logo', w, it.ParentLogoImageTag);
    return '';
  };
  A.userImg = function (u, w) {
    if (!u || !u.PrimaryImageTag) return '';
    return A.server + '/Users/' + u.Id + '/Images/Primary' + qs({ maxWidth: w, tag: u.PrimaryImageTag, quality: 90 });
  };

  /* ======== Comptes (mot de passe saisi une seule fois par profil) ======== */
  function key(uid) { return A.server + '|' + uid; }
  A.hasSession = function (uid) { return !!S.get('sessions', {})[key(uid)]; };
  A.login = function (name, pw) {
    A.token = '';
    return A.post('/Users/AuthenticateByName', { Username: name, Pw: pw || '' }).then(function (r) {
      A.token = r.AccessToken; A.userId = r.User.Id; A.user = r.User;
      var s = S.get('sessions', {}); s[key(A.userId)] = { token: A.token, name: r.User.Name }; S.set('sessions', s);
      S.set('lastUser', A.userId);
      return r.User;
    });
  };
  A.useSession = function (uid) {
    var s = S.get('sessions', {})[key(uid)];
    if (!s) return Promise.reject(new Error('pas de session'));
    A.token = s.token; A.userId = uid;
    return both('GET', '/Users/Me', '/Users/' + uid, {}).then(function (u) {
      A.user = u; S.set('lastUser', uid); return u;
    }, function (e) {
      if (e.status === 401) { var all = S.get('sessions', {}); delete all[key(uid)]; S.set('sessions', all); }
      A.token = ''; throw e;
    });
  };
  A.forget = function (uid) { var all = S.get('sessions', {}); delete all[key(uid)]; S.set('sessions', all); };
  A.setServer = function (url) {
    url = String(url || '').trim();
    if (url && !/^https?:\/\//i.test(url)) url = 'http://' + url;
    url = url.replace(/\/+$/, '').replace(/\/web(\/index\.html)?$/i, '');
    A.server = url; S.set('server', url);
    return url;
  };
})();
