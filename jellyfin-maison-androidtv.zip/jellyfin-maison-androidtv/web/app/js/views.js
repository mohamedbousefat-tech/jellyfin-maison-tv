/*
 * Jellyfin Maison (webOS) — écrans simples : serveur, profils, mot de passe, réglages, catégories
 */
(function () {
  'use strict';
  var TVM = window.TVM, A = TVM.api, el = TVM.el, esc = TVM.esc;

  /* Petit formulaire générique : champs + boutons, navigation ↑ ↓ */
  function Form(title, fields, buttons, note) {
    var v = this;
    v.el = el('div', 'view form');
    var box = el('div', 'form-box');
    box.appendChild(el('div', 'logo', TVM.logoMark() + '<span class="lt">JELLYFIN</span>'));
    box.appendChild(el('h1', '', esc(title)));
    v.inputs = {};
    var items = [];
    fields.forEach(function (f) {
      var lab = el('label', 'fld', '<span>' + esc(f.label) + '</span>');
      var inp = el('input');
      inp.type = f.type || 'text';
      inp.value = f.value || '';
      inp.placeholder = f.placeholder || '';
      inp.setAttribute('autocomplete', 'off');
      lab.appendChild(inp);
      box.appendChild(lab);
      v.inputs[f.name] = inp;
      items.push(lab);
      inp.addEventListener('keydown', function (e) {
        if (e.keyCode === 13) { e.preventDefault(); inp.blur(); v.list.step(1); }
      });
    });
    var row = el('div', 'btns');
    buttons.forEach(function (b) {
      var bt = el('div', 'btn', esc(b.label));
      bt.__act = b.act;
      bt.addEventListener('click', function () { b.act(v); });
      row.appendChild(bt);
      items.push(bt);
    });
    box.appendChild(row);
    if (note) box.appendChild(el('p', 'note', note));
    v.msg = el('p', 'msg');
    box.appendChild(v.msg);
    v.el.appendChild(box);
    v.list = new TVM.List(items);
    v.onShow = function () { v.list.focus(); };
    v.onKey = function (k) {
      var cur = v.list.current(), inp = cur && cur.querySelector && cur.querySelector('input');
      if (k === 'up') { if (inp) inp.blur(); v.list.step(-1); return true; }
      if (k === 'down') { if (inp) inp.blur(); v.list.step(1); return true; }
      if (k === 'left' || k === 'right') {
        if (cur && cur.classList.contains('btn')) v.list.step(k === 'left' ? -1 : 1);
        return true;
      }
      if (k === 'ok') {
        if (inp) { inp.focus(); return true; }
        if (cur && cur.__act) cur.__act(v);
        return true;
      }
      if (k === 'back' && inp && document.activeElement === inp) { inp.blur(); return true; }
      return false;
    };
    v.error = function (m) { v.msg.textContent = m || ''; };
  }

  /* ======== 1. Adresse du serveur ======== */
  TVM.SetupView = function () {
    return new Form('Adresse de ton serveur', [
      { name: 'url', label: 'Serveur Jellyfin', value: A.server || 'http://192.168.1.', placeholder: 'http://192.168.1.10:8096' }
    ], [{
      label: 'Se connecter', act: function (v) {
        var url = A.setServer(v.inputs.url.value);
        v.error('Connexion…');
        A.get('/System/Info/Public').then(function (info) {
          TVM.toast('Connecté à ' + (info.ServerName || 'Jellyfin'));
          TVM.app.reset(new TVM.ProfilesView());
        }).catch(function () { v.error('Serveur injoignable : ' + url); });
      }
    }], 'OK sur le champ pour ouvrir le clavier. Exemple : 192.168.1.10:8096');
  };

  /* ======== 2. « Qui est-ce ? » — façon Netflix télé : profils à gauche, diaporama à droite ======== */
  TVM.ProfilesView = function () {
    var v = this;
    v.el = el('div', 'view profiles');
    v.el.innerHTML =
      '<div class="pshow"><div class="psl a"></div><div class="psl b"></div><div class="pfade"></div>' +
      '  <div class="pcap"><div class="pcl"></div><div class="pcg"></div></div></div>' +
      '<div class="pside">' + TVM.logoHtml() + '<div class="pwho">Qui est-ce ?</div><div class="plw"><div class="plist"></div></div></div>';
    var wrap = v.el.querySelector('.plist');
    v.list = new TVM.List([]);
    v.alive = true;
    function open(u, pinOk) {
      /* profil protégé par un code PIN (les enfants n'entrent pas dans les profils adultes) */
      if (!pinOk && !u.__server && !u.__manual && TVM.askPin && TVM.askPin(u, function () { open(u, true); })) return;
      if (!u.__server && !u.__manual && TVM.profileSwitch) TVM.profileSwitch.start(u);   /* l'icône s'affiche en grand, comme Netflix */
      if (u.__server) { TVM.app.push(TVM.SetupView()); return; }
      if (u.__manual) { TVM.app.push(new TVM.LoginView('')); return; }
      if (A.hasSession(u.Id)) {
        A.useSession(u.Id).then(goHome, function () { if (TVM.profileSwitch) TVM.profileSwitch.cancel(); TVM.app.push(new TVM.LoginView(u.Name, u)); });
        return;
      }
      if (!u.HasPassword) {
        A.login(u.Name, '').then(goHome, function () { if (TVM.profileSwitch) TVM.profileSwitch.cancel(); TVM.app.push(new TVM.LoginView(u.Name, u)); });
        return;
      }
      if (TVM.profileSwitch) TVM.profileSwitch.cancel();
      TVM.app.push(new TVM.LoginView(u.Name, u));
    }
    v.open = open;
    A.get('/Users/Public').catch(function () { return []; }).then(function (users) {
      users = (users || []).slice();
      /* profils masqués de l'écran de connexion Jellyfin : on reprend ceux déjà connectés sur cette télé */
      var sess = TVM.store.get('sessions', {}), have = {};
      users.forEach(function (u) { have[u.Id] = 1; });
      for (var sk in sess) if (sess.hasOwnProperty(sk) && sk.indexOf(A.server + '|') === 0) {
        var uid = sk.split('|')[1];
        if (!have[uid]) { have[uid] = 1; users.push({ Id: uid, Name: sess[sk].name || 'Profil', HasPassword: true }); }
      }
      users.push({ Name: 'Autre compte', __manual: true });
      var items = users.map(function (u) {
        var img = TVM.avatarFor ? TVM.avatarFor(u, 240) : A.userImg(u, 240), c = el('div', 'prof');
        var ico = u.__server ? '<svg viewBox="0 0 24 24" width="55%" height="55%" style="vertical-align:middle"><circle cx="12" cy="12" r="3.2" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>' : u.__manual ? '+' : esc((u.Name || '?').charAt(0));
        c.innerHTML = (u.Id ? '<div class="ped"><svg viewBox="0 0 24 24"><path d="M4 20l1-4L16 5l3 3L8 19z M14 7l3 3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg></div>' : '') +
          (img ? '<img src="' + img + '">' : '<div class="ini' + (u.__manual || u.__server ? ' alt' : '') + '">' + ico + '</div>') +
          '<span>' + esc(u.Name) + '</span>';
        c.addEventListener('click', function () { open(u); });
        c.__u = u;
        wrap.appendChild(c);
        return c;
      });
      v.list = new TVM.List(items);
      var last = TVM.store.get('lastUser'), idx = 0;
      users.forEach(function (u, i) { if (last && u.Id === last) idx = i; });
      v.list.set(idx);
    });
    v.slides();
  };
  /* diaporama (écran de veille) : grands fonds de tes titres, avec logo et genres */
  TVM.ProfilesView.prototype.slides = function () {
    var v = this, sess = TVM.store.get('sessions', {}), tok = '';
    for (var k in sess) if (sess.hasOwnProperty(k) && k.indexOf(A.server + '|') === 0) { tok = sess[k].token; break; }
    if (!tok) return;                                  /* premier lancement : pas encore de compte → fond sobre */
    var uid = k.split('|')[1], hdr = { 'Authorization': 'MediaBrowser Client="Jellyfin Maison TV", Device="' + TVM.deviceName + '", DeviceId="' + A.deviceId + '", Version="' + TVM.version + '", Token="' + tok + '"' };
    fetch(A.server + '/Items' + A.qs({ userId: uid, Recursive: true, IncludeItemTypes: 'Movie,Series', SortBy: 'Random', Limit: 24,
      ImageTypes: 'Backdrop', Fields: 'Genres', EnableImageTypes: 'Backdrop,Logo', ImageTypeLimit: 1 }), { headers: hdr })
      .then(function (r) { return r.ok ? r.json() : { Items: [] }; }).then(function (r) {
        var items = (r.Items || []).filter(function (it) { return it.BackdropImageTags && it.BackdropImageTags.length; });
        if (!items.length || !v.alive) return;
        var i = -1, layer = 0, layers = v.el.querySelectorAll('.psl');
        function next() {
          if (!v.alive) return;
          i = (i + 1) % items.length;
          var it = items[i], url = A.backdrop(it, TVM.config.backdropWidth), im = new Image();
          im.onload = im.onerror = function () {
            if (!v.alive) return;
            layer = 1 - layer;
            layers[layer].style.backgroundImage = 'url("' + url + '")';
            layers[layer].classList.add('on');
            layers[1 - layer].classList.remove('on');
            var logo = A.logo(it, 500);
            v.el.querySelector('.pcl').innerHTML = logo ? '<img src="' + logo + '">' : '<h2>' + esc(it.Name) + '</h2>';
            v.el.querySelector('.pcg').textContent = (it.Genres || []).slice(0, 3).map(TVM.genreFr || String).join(' • ');
            v.timer = setTimeout(next, 9000);
          };
          im.src = url;
        }
        next();
      }).catch(function () {});
  };
  TVM.ProfilesView.prototype.onShow = function () {
    if (TVM.profilesDirty) { TVM.profilesDirty = false; var nv = new TVM.ProfilesView(); TVM.app.stack.length > 1 ? (TVM.app.pop(), TVM.app.push(nv)) : TVM.app.reset(nv); return; }
    this.list.focus();
  };
  TVM.ProfilesView.prototype.destroy = function () { this.alive = false; clearTimeout(this.timer); };
  TVM.ProfilesView.prototype.onKey = function (k) {
    var v = this;
    var cur = v.list.current(), canEdit = cur && cur.__u && cur.__u.Id;
    /* profils en ligne, comme Netflix : ← → pour choisir, ↓ = crayon « modifier le profil », ↑ = retour au profil */
    if (k === 'left' || k === 'right') { v.el.classList.remove('editing'); v.list.step(k === 'left' ? -1 : 1); return true; }
    if (k === 'down' && canEdit) { v.el.classList.add('editing'); return true; }
    if (k === 'up') { v.el.classList.remove('editing'); return true; }
    if (k === 'ok') {
      if (!cur) return true;
      if (v.el.classList.contains('editing') && canEdit) { v.el.classList.remove('editing'); TVM.app.push(new TVM.ProfileEditView(cur.__u)); return true; }
      v.open(cur.__u); return true;
    }
    if (k === 'back') { if (v.el.classList.contains('editing')) { v.el.classList.remove('editing'); return true; } if (TVM.app.stack.length > 1) return false; var now = Date.now(); if (now - (v.lastBack || 0) < 2500) { TVM.exit(); return true; } v.lastBack = now; TVM.toast('Appuie encore sur Retour pour quitter'); return true; }
    return true;
  };

  function goHome() {
    /* Jeunesse est une interface de PROFIL (comme Netflix), pas une catégorie :
       un profil de moins de 12 ans (contrôle parental Jellyfin ≤ 12) s'ouvre directement sur l'interface Jeunesse */
    TVM.getViews().then(function (vs) {
      var pref = TVM.applyProfPrefs ? TVM.applyProfPrefs(A.userId) : {};
      TVM.homeScope = TVM.isKidsProfile(A.user, vs, pref) ? { type: 'kids', libs: TVM.kidsScopeLibs(vs) } : { type: 'home' };
    }, function () { TVM.homeScope = { type: 'home' }; }).then(function () {
      if (TVM.profileSwitch) TVM.profileSwitch.ready(TVM.homeScope.type === 'kids');
      TVM.app.reset(new TVM.HomeView(TVM.homeScope));
      /* première ouverture du profil : questionnaire des goûts, comme Netflix */
      if (TVM.taste && !TVM.taste.done()) (function wait() {
        if (document.getElementById('intro')) { setTimeout(wait, 500); return; }
        setTimeout(function () { var t = TVM.app.top(); if (t && /home/.test(t.el.className)) TVM.app.push(new TVM.TasteQuizView(true)); }, 600);
      })();
    });
    /* personnalisations du serveur, une fois par profil, après l'affichage de l'accueil */
    if (TVM.ext && TVM.ext.user !== A.userId) { TVM.ext.user = A.userId; setTimeout(function () { TVM.ext.load(true); }, 800); }
  }
  TVM.goHome = goHome;

  /* ======== 3. Mot de passe (une seule fois) ======== */
  TVM.LoginView = function (name, user) {
    var fields = [];
    if (!name) fields.push({ name: 'user', label: 'Nom d\'utilisateur', value: '' });
    fields.push({ name: 'pw', label: 'Mot de passe', type: 'password', value: '' });
    var f = new Form(name ? 'Bonjour ' + name : 'Connexion', fields, [{
      label: 'Valider', act: function (v) {
        var n = name || v.inputs.user.value;
        v.error('Connexion…');
        A.login(n, v.inputs.pw.value).then(goHome, function () { v.error('Mot de passe incorrect'); });
      }
    }], 'Le mot de passe est demandé une seule fois sur cette télé.');
    return f;
  };

  /* ======== 4. Réglages ======== */
  TVM.SettingsView = function () {
    var v = this;
    v.el = el('div', 'view settings');
    var rows = [
      { t: 'Changer de profil', a: function () { TVM.app.reset(new TVM.ProfilesView()); } },
      { t: 'Aperçus vidéo sur les jaquettes : ' + (TVM.config.preview ? 'oui' : 'non'), a: function () {
        TVM.config.preview = !TVM.config.preview; TVM.store.set('preview', TVM.config.preview);
        TVM.app.pop(); TVM.app.push(new TVM.SettingsView());
      } },
      { t: 'Écran de veille : ' + (TVM.config.saverMinutes ? 'après ' + TVM.config.saverMinutes + ' min' : 'désactivé'), a: function () {
        var m = TVM.config.saverMinutes, nm = m === 1 ? 3 : m === 3 ? 10 : m === 10 ? 0 : 1;
        TVM.config.saverMinutes = nm; TVM.store.set('saverMinutes2', nm); if (TVM.saverArm) TVM.saverArm();
        TVM.app.pop(); TVM.app.push(new TVM.SettingsView());
      } },
      { t: 'Intro du logo au démarrage : ' + (TVM.config.intro ? 'oui' : 'non'), a: function () {
        TVM.config.intro = !TVM.config.intro; TVM.store.set('intro', TVM.config.intro);
        TVM.app.pop(); TVM.app.push(new TVM.SettingsView());
      } },
      { t: 'Mes goûts (questionnaire)', a: function () { TVM.app.push(new TVM.TasteQuizView(false)); } },
      { t: 'Minuterie de sommeil' + (TVM.sleep ? ' : activée' : ''), a: function () { TVM.openSleep(); } },
      { t: 'Recharger tes personnalisations (CSS / JS)', a: function () { TVM.ext.load(true).then(function (n) { TVM.toast(n + ' personnalisation(s) chargée(s)'); }); } },
      { t: 'Recharger l\'appli', a: function () { location.reload(); } },
      { t: 'Se déconnecter de ce profil', a: function () { A.forget(A.userId); TVM.app.reset(new TVM.ProfilesView()); } },
      { t: 'Changer de serveur', a: function () { TVM.app.push(TVM.SetupView()); } },
      { t: 'Quitter l\'appli', a: function () { TVM.exit(); } }
    ];
    if (TVM.subRows) {
      var sr = TVM.subRows(function () { var i = TVM.app.top().list.i; TVM.app.pop(); var nv = new TVM.SettingsView(); TVM.app.push(nv); nv.list.set(i); });
      rows.splice(4, 0, sr[0], sr[1]);
    }
    /* Android TV (Philips…) : mise à jour directe depuis GitHub, sans Downloader */
    if (window.TVMNative && window.TVMNative.update) {
      rows.splice(1, 0, { t: 'Mettre à jour l\'appli (dernière version)', a: function () {
        TVM.toast('Téléchargement de la mise à jour…');
        try { window.TVMNative.update(TVM.config.updateUrl); } catch (e) { TVM.toast('Mise à jour impossible'); }
      } });
    }
    if (A.user && A.user.Policy && A.user.Policy.IsAdministrator) {
      rows.splice(1, 0,
        { t: 'Classement des contenus par âge (administrateur)', a: function () { TVM.app.push(new TVM.AgesView()); } },
        { t: 'Contrôle parental des profils (administrateur)', a: function () { TVM.app.push(new TVM.ParentalView()); } },
        { t: 'Temps d\'écran des enfants (administrateur)', a: function () { TVM.app.push(new TVM.ScreenTimeView()); } });
    }
    var box = el('div', 'set-box', TVM.logoHtml() + '<h1>Réglages</h1>');
    var items = rows.map(function (r) {
      var d = el('div', 'set-row', esc(r.t)); d.__a = r.a; d.addEventListener('click', r.a); box.appendChild(d); return d;
    });
    box.appendChild(el('p', 'note', 'Jellyfin Maison ' + TVM.version + ' · ' + esc(A.server) + ' · ' + esc(A.user ? A.user.Name : '') +
      '<br>Personnalisations : ' + (TVM.ext ? TVM.ext.summary() : '—') +
      '<br>Touches de couleur : 🔴 Accueil · 🟢 Commande vocale · 🟡 Réglages · 🔵 Changer de profil'));
    v.el.appendChild(box);
    v.list = new TVM.List(items);
    /* longue liste : elle défile pour garder la ligne choisie à l'écran */
    function scroll() { var c = v.list.current(); if (!c) return; var y = Math.max(0, c.offsetTop - v.el.offsetHeight * .55); box.style.transform = 'translateY(' + (-y) + 'px)'; }
    box.style.transition = 'transform .2s ease-out';
    v.onShow = function () { v.list.focus(); scroll(); };
    v.list.set = (function (orig) { return function (i) { orig.call(this, i); scroll(); }; })(v.list.set);
    v.onKey = function (k) {
      if (k === 'up' || k === 'down') { v.list.step(k === 'up' ? -1 : 1); scroll(); return true; }
      if (k === 'ok') { v.list.current().__a(); return true; }
      return k !== 'back';
    };
  };

  /* ======== 5. Toutes les catégories (médiathèques) ======== */
  /* ---------- Catégories : mur d'affiches qui défile derrière la liste ---------- */
  var wallCache = {};
  function wallItems(lib) {
    var k = lib ? lib.Id : 'all';
    if (wallCache[k]) return wallCache[k];
    var q = { SortBy: 'Random', Limit: 48, IncludeItemTypes: 'Movie,Series', EnableImageTypes: 'Primary', ImageTypeLimit: 1, Fields: 'PrimaryImageAspectRatio', EnableUserData: false };
    if (lib) q.ParentId = lib.Id;
    wallCache[k] = A.items(q).then(function (l) {
      l = l.filter(function (it) { return it.ImageTags && it.ImageTags.Primary; });
      if (l.length < 12 && lib) return wallItems(null);
      return l;
    }).catch(function () { delete wallCache[k]; return []; });
    return wallCache[k];
  }
  function makeWall(list) {
    var w = el('div', 'cwall');
    if (!list.length) return w;
    var rows = 4, per = Math.max(12, Math.ceil(list.length / rows));
    for (var r = 0; r < rows; r++) {
      var h = '';
      for (var i = 0; i < per; i++) {
        var it = list[(r * per + i * 3 + r) % list.length];
        h += '<div class="cwp"><img src="' + A.poster(it, 220) + '" alt=""></div>';
      }
      var row = el('div', 'cwr cwr' + r, '<div class="cwt">' + h + h + '</div>');
      w.appendChild(row);
    }
    return w;
  }

  TVM.CategoriesView = function (views) {
    var v = this;
    v.el = el('div', 'view cats');
    v.el.innerHTML = '<div class="cbg"></div><div class="cshade"></div>' +
      '<div class="cside">' + TVM.logoHtml() + '<h1>Catégories</h1><div class="clistw"><div class="clist"></div></div></div>' +
      '<div class="chint">OK pour ouvrir · Retour pour revenir</div>';
    var bg = v.el.querySelector('.cbg'), box = v.el.querySelector('.clist');
    var libs = views.slice().sort(function (x, y) { return String(x.Name).localeCompare(String(y.Name), 'fr'); });
    var items = libs.map(function (lib) {
      var d = el('div', 'crow', '<span>' + esc(lib.Name) + '</span>');
      d.__lib = lib;
      d.__a = function () { TVM.app.reset(new TVM.HomeView({ type: 'lib', lib: lib })); };
      d.addEventListener('click', d.__a);
      box.appendChild(d);
      return d;
    });
    var shown = null;
    function paintWall(lib) {
      var key = lib ? lib.Id : 'all';
      if (shown === key) return;
      shown = key;
      wallItems(lib).then(function (l) {
        if (shown !== key || !l.length) return;
        var w = makeWall(l), old = bg.querySelectorAll('.cwall');
        bg.appendChild(w);
        setTimeout(function () { w.classList.add('on'); }, 60);
        setTimeout(function () { for (var i = 0; i < old.length; i++) if (old[i].parentNode) bg.removeChild(old[i]); }, 1400);
      });
    }
    v.list = new TVM.List(items, { onMove: function (i) {
      var it = items[i], H = box.parentNode.clientHeight || TVM.rem(40), y = it.offsetTop + it.offsetHeight / 2;
      TVM.move(box, 0, -Math.max(0, Math.min(box.scrollHeight - H, y - H / 2)));
      clearTimeout(v.wallT);
      v.wallT = setTimeout(function () { paintWall(it.__lib); }, 700);
    } });
    paintWall(null);
    v.onShow = function () { v.el.classList.remove('still'); v.list.focus(); };
    v.onHide = function () { v.el.classList.add('still'); };
    v.destroy = function () { clearTimeout(v.wallT); };
    v.onKey = function (k) {
      if (k === 'up' || k === 'down') { v.list.step(k === 'up' ? -1 : 1); return true; }
      if (k === 'ok') { v.list.current().__a(); return true; }
      return k !== 'back';
    };
  };
})();
