# Jellyfin Maison — Android TV / Google TV (Philips, Google TV Streamer…)

La même appli que sur la LG (dossier `web/app`), emballée dans un APK pour Android TV.

## Construire l'APK (gratuit, sur GitHub)
1. Crée un nouveau dépôt GitHub (ex. `jellyfin-maison-tv`).
2. Envoie TOUT le contenu de ce dossier dans le dépôt (bouton « Add file → Upload files », glisser-déposer).
3. Onglet **Actions** : la construction démarre toute seule (≈ 5 min).
4. Onglet **Releases** → « Dernière version » → `jellyfin-maison-tv.apk`.

## Installer sur la télé
- Sur la télé : Paramètres → Système → À propos → appuyer 7 fois sur « Build du système d'exploitation » (mode développeur).
- Installer l'appli **Downloader** (Play Store), autoriser « Sources inconnues » pour Downloader.
- Dans Downloader, taper l'adresse du lien de l'APK (onglet Releases), puis Installer.

## Mettre à jour l'appli
Remplacer le dossier `web/app` par la nouvelle version (le contenu du zip webOS : index.html, css, js, img, snd),
augmenter `versionCode` dans `app/build.gradle`, puis renvoyer sur GitHub.
